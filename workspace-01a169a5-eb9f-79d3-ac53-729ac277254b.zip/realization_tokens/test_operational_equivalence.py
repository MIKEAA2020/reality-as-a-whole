"""WP3 v0.4 finite checks of operational equivalence and its limits.

The test suite never infers consciousness or observer multiplicity from a
state quotient. Explicit duplicate-preservation remains a project condition,
not a discovered psychophysical fact about the toy machines.
"""
from itertools import product, combinations
import unittest

from operational_equivalence import (
    MooreMachine, input_words, isomorphic, padded, parallel,
    realization_morphism, sample,
)
from realization_tokens import (
    Block, Description, FiniteFrame, Verdict, classify, partition_code,
)


def toggle():
    return MooreMachine((0, 1), ("tick",), lambda s, u: 1 - s, lambda s: s, "toggle")


def controlled_bit():
    return MooreMachine((0, 1), (0, 1), lambda s, u: s ^ u, lambda s: s, "controlled bit")


class OperationalEquivalenceTests(unittest.TestCase):
    def test_01_hidden_static_memory_is_operationally_removable(self):
        base = toggle()
        implementation = padded(base, (0, 1), lambda z, u: z, name="static hidden bit")
        self.assertEqual(len(implementation.states), 4)
        self.assertEqual(len(implementation.quotient()[0].states), 2)
        self.assertTrue(isomorphic(base.quotient()[0], implementation.quotient()[0]))

    def test_02_hidden_full_duplicate_has_same_selected_interface_minimum(self):
        base = toggle()
        duplicate = parallel(base, base)
        self.assertTrue(isomorphic(base.quotient()[0], duplicate.quotient()[0]))

    def test_03_both_hidden_memory_and_duplicate_are_valid_interface_morphisms(self):
        base = toggle()
        memory = padded(base, (0, 1), lambda z, u: z)
        duplicate = parallel(base, base)
        self.assertTrue(realization_morphism(memory, base, lambda state: state[0]))
        self.assertTrue(realization_morphism(duplicate, base, lambda state: state[0]))

    def test_04_quotient_fiber_sizes_do_not_distinguish_padding_from_replicas(self):
        base = toggle()
        memory = padded(base, (0, 1), lambda z, u: z)
        duplicate = parallel(base, base)
        sizes = []
        for machine in (memory, duplicate):
            minimum, projection = machine.quotient()
            sizes.append(sorted(sum(v == block for v in projection.values()) for block in minimum.states))
        self.assertEqual(sizes, [[2, 2], [2, 2]])
        # Fibers are sets of alternative states, not simultaneous observers.

    def test_05_joint_observation_restores_four_distinct_state_behaviors(self):
        base = toggle()
        joint = parallel(base, base, joint_observation=True)
        self.assertEqual(len(joint.quotient()[0].states), 4)
        # Four state behaviors are not a four-subject conclusion.

    def test_06_constant_observation_collapses_without_changing_dynamics(self):
        base = toggle()
        uninformative = MooreMachine(base.states, base.inputs, base.transition, lambda s: "same")
        self.assertEqual(len(uninformative.quotient()[0].states), 1)

    def test_07_decoder_choice_can_change_behavior_type_at_equal_minimum_size(self):
        base = toggle()
        joint = parallel(base, base)
        parity = MooreMachine(joint.states, joint.inputs, joint.transition, lambda s: s[0] ^ s[1])
        self.assertEqual(len(parity.quotient()[0].states), 2)
        self.assertEqual(len(joint.quotient()[0].states), 2)
        self.assertFalse(isomorphic(parity.quotient()[0], joint.quotient()[0]))

    def test_08_synchronized_reachable_states_do_not_count_duplicate_occurrences(self):
        base = controlled_bit()
        duplicate = parallel(base, base, joint_observation=True)
        reachable = duplicate.reachable((0, 0))
        self.assertEqual(set(reachable.states), {(0, 0), (1, 1)})
        self.assertEqual(len(reachable.quotient()[0].states), 2)

    def test_09_microstep_and_logical_step_minima_can_differ(self):
        compiled = MooreMachine(
            tuple(product((0, 1), repeat=2)), ("tick",),
            lambda s, u: (s[0], 1) if s[1] == 0 else (1 - s[0], 0),
            lambda s: s[0], "two-microstep implementation",
        )
        self.assertEqual(len(compiled.quotient()[0].states), 4)
        logical = sample(compiled, 2)
        self.assertEqual(len(logical.quotient()[0].states), 2)
        self.assertTrue(realization_morphism(logical, toggle(), lambda s: s[0]))

    def test_10_nested_interface_morphisms_compose(self):
        base = controlled_bit()
        middle = padded(base, (0, 1), lambda z, u: 1 - z)
        host = padded(middle, (0, 1, 2), lambda z, u: (z + 1) % 3)
        self.assertTrue(realization_morphism(host, middle, lambda s: s[0]))
        self.assertTrue(realization_morphism(middle, base, lambda s: s[0]))
        self.assertTrue(realization_morphism(host, base, lambda s: s[0][0]))
        self.assertTrue(isomorphic(host.quotient()[0], base.quotient()[0]))

    def test_11_observation_mismatch_invalidates_a_projection(self):
        base = toggle()
        memory = padded(base, (0, 1), lambda z, u: z)
        self.assertFalse(realization_morphism(memory, base, lambda s: s[0] ^ s[1]))

    def test_12_delayed_distinction_requires_future_inputs(self):
        chain = MooreMachine((0, 1, 2, 3), ("tick",), lambda s, u: min(s + 1, 3),
                             lambda s: int(s == 3), "delayed distinction")
        self.assertEqual(chain.behavior(0, ("tick",)), chain.behavior(1, ("tick",)))
        self.assertNotEqual(chain.behavior(0, ("tick", "tick")), chain.behavior(1, ("tick", "tick")))
        self.assertEqual(len(chain.quotient()[0].states), 4)

    def test_13_morphism_preserves_every_checked_interface_history(self):
        base = controlled_bit()
        host = padded(base, (0, 1, 2), lambda z, u: (z + u) % 3)
        for initial in host.states:
            for word in input_words(base.inputs, 4):
                self.assertEqual(host.behavior(initial, word), base.behavior(initial[0], word))

    def test_14_minimization_is_idempotent_up_to_isomorphism(self):
        base = toggle()
        implementation = padded(base, (0, 1, 2), lambda z, u: (z + 1) % 3)
        minimum = implementation.quotient()[0]
        self.assertTrue(isomorphic(minimum, minimum.quotient()[0]))

    def test_15_refinement_never_merges_previously_distinct_blocks(self):
        chain = MooreMachine((0, 1, 2, 3), (0,), lambda s, u: min(s + 1, 3), lambda s: int(s == 3))
        history = chain.refinement_history()
        for before, after in zip(history, history[1:]):
            for i, j in combinations(range(4), 2):
                if before[i] != before[j]:
                    self.assertNotEqual(after[i], after[j])

    def test_16_exhaustive_5832_three_state_binary_input_output_machines(self):
        states, inputs = (0, 1, 2), (0, 1)
        words = input_words(inputs, 2)
        checked = 0
        for transitions in product(states, repeat=6):
            for outputs in product((0, 1), repeat=3):
                machine = MooreMachine(
                    states, inputs,
                    lambda s, u, t=transitions: t[2 * s + u],
                    lambda s, o=outputs: o[s],
                )
                finite_word_partition = partition_code(
                    tuple(machine.behavior(s, word) for word in words) for s in states
                )
                self.assertEqual(machine.behavior_partition(), finite_word_partition)
                self.assertLessEqual(len(machine.refinement_history()) - 1, 2)
                checked += 1
        self.assertEqual(checked, 5832)

    def test_17_reachability_selection_is_explicit(self):
        base = toggle()
        static = padded(base, (0, 1), lambda z, u: z)
        self.assertEqual(len(static.states), 4)
        self.assertEqual(len(static.reachable((0, 0)).states), 2)
        self.assertTrue(isomorphic(static.quotient()[0], static.reachable((0, 0)).quotient()[0]))

    def test_18_actual_input_trace_fit_does_not_establish_interface_equivalence(self):
        base = controlled_bit()
        fake = MooreMachine((0, 1), (0, 1), lambda s, u: 1 - s, lambda s: s)
        self.assertEqual(base.behavior(0, (1, 1, 1)), fake.behavior(0, (1, 1, 1)))
        self.assertNotEqual(base.behavior(0, (0,)), fake.behavior(0, (0,)))
        self.assertFalse(realization_morphism(fake, base, lambda s: s))

    def test_19_same_operational_type_does_not_merge_anchored_execution_segments(self):
        states = tuple(product((0, 1), repeat=2))
        frame = FiniteFrame("two concrete copies", states, lambda s: (1-s[0], 1-s[1]),
                            frozenset({"a0", "a1", "b0", "b1"}))
        a = Description(frame, (Block(frozenset({"a0"})), Block(frozenset({"a1"}))),
                        ((0, 0), (1, 1), (0, 0)), lambda s: s[0])
        b = Description(frame, (Block(frozenset({"b0"})), Block(frozenset({"b1"}))),
                        ((0, 0), (1, 1), (0, 0)), lambda s: s[1])
        self.assertEqual(a.quotient_code(), b.quotient_code())
        self.assertEqual(classify(a, b), Verdict.DISTINCT_SEGMENTS)

    def test_20_state_renaming_preserves_minimum_up_to_isomorphism(self):
        host = padded(controlled_bit(), (0, 1), lambda z, u: 1-z)
        moved = host.transported(lambda s: f"state:{s[1]}:{s[0]}", reverse_enumeration=True)
        self.assertTrue(isomorphic(host.quotient()[0], moved.quotient()[0]))

    def test_21_arbitrary_finite_hidden_dynamics_does_not_change_selected_behavior(self):
        base = toggle()
        for size in range(1, 6):
            host = padded(base, tuple(range(size)), lambda z, u, n=size: (z+1) % n)
            self.assertTrue(isomorphic(host.quotient()[0], base.quotient()[0]))

    def test_22_state_fiber_cardinality_can_change_without_new_selected_behavior(self):
        base = toggle()
        for size in (2, 3, 5):
            host = padded(base, tuple(range(size)), lambda z, u: z)
            minimum, projection = host.quotient()
            self.assertEqual(len(minimum.states), 2)
            self.assertTrue(all(sum(v == block for v in projection.values()) == size for block in minimum.states))

    def test_23_distinct_minimal_states_have_distinguishing_words(self):
        chain = MooreMachine((0, 1, 2, 3), (0,), lambda s, u: min(s+1,3), lambda s: int(s==3))
        minimum = chain.quotient()[0]
        words = input_words(minimum.inputs, 3)
        for a, b in combinations(minimum.states, 2):
            self.assertTrue(any(minimum.behavior(a, w) != minimum.behavior(b, w) for w in words))

    def test_24_surjectivity_is_needed_to_recover_all_state_behaviors(self):
        specification = MooreMachine((0, 1, 2), (0,), lambda s, u: s, lambda s: s)
        implementation = MooreMachine((0, 1), (0,), lambda s, u: s, lambda s: s)
        self.assertTrue(realization_morphism(implementation, specification, lambda s: s, surjective=False))
        self.assertFalse(realization_morphism(implementation, specification, lambda s: s, surjective=True))
        self.assertFalse(isomorphic(implementation.quotient()[0], specification.quotient()[0]))


if __name__ == "__main__":
    unittest.main(verbosity=2)
