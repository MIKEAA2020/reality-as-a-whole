# Work Package 3 — Operational equivalence and multiplicity, v0.4

## A canonical predictive type is not an actual realization population

**Question:** can causal/operational equivalence distinguish constitutive organization from harmless implementation machinery without presupposing the relevant perspective?

**Result:** standard finite-state behavioral minimization gives a unique minimal predictive organization **relative to a supplied input/observation interface**. But invariance under every interface-preserving abstraction is incompatible with preserving the numerical multiplicity of hidden duplicate realizations. The equivalence is useful, but cannot by itself be a global constitutive or counting rule.

**Validation:** 24 new tests pass; the complete regression suite contains 112 tests. One new exhaustive check covers all 5,832 three-state, binary-input, binary-output Moore machines. These are finite algebraic checks, not observations of consciousness.

---

## 1. The candidate: interface-relative operational organization

Represent a finite process as a deterministic Moore machine

\[
A=(S,U,Y,T,O),
\]

where `S` is a selected state family, `U` an input alphabet, `T:S×U→S` the transition, and `O:S→Y` the observation map.

This does not add an independently justified fifth foundation. It makes existing inputs explicit:

- allowed inputs and input histories are part of the intervention/interface assumptions;
- `O` contains the target/decoder choice;
- the selected state family contains the counterfactual/reachability assumption;
- one application of `T` fixes the temporal grain.

The observations need not be public outputs. They could be proposed internal readouts. But if they are taken to be phenomenal facts, that significance must be supplied or derived; it does not follow from the machine definition.

For a finite input word `w`, let `Beh(s,w)` be the observation trace, including the initial observation.

Define

\[
s\sim_O t
\quad\Longleftrightarrow\quad
\forall w\in U^*,\;\operatorname{Beh}(s,w)=\operatorname{Beh}(t,w).
\]

This is equality of every distinction accessible through the **selected** interface.

## 2. A standard positive theorem, used with its limits intact

### 2.1 Behavioral quotient theorem

`~O` is the greatest observation-respecting transition congruence. The quotient `A/~O` is the unique minimal deterministic predictive machine, up to interface-preserving isomorphism, realizing exactly the selected family of state behaviors.

If a single initial condition is specified, first restrict to its input-reachable state family. That restriction is an explicit choice, not an observer-counting operation.

**Proof sketch.**

1. Equivalent states have the same immediate observation, by taking the empty input word.
2. Their successors under any common input are equivalent: otherwise a distinguishing continuation would distinguish the original states.
3. Conversely, any observation-respecting transition congruence preserves observations after every finite input word, by induction. It is contained in `~O`.
4. The quotient therefore realizes all and only the source state behaviors.
5. Any deterministic realization of the same behavior family needs distinct states for distinct behaviors. The quotient has exactly one per behavior, hence is minimal.
6. Two such minimal realizations identify their states through those behaviors, yielding an isomorphism. ∎

This is standard automata minimization, not a claimed new theorem about consciousness. Its role here is to test a specific candidate for canonical organization.

### 2.2 Effective construction

Start with equality of `O` and repeatedly refine by the classes of all input successors:

\[
P_{n+1}(s)=\big(P_n(s),\;(P_n(T(s,u)))_{u\in U}\big).
\]

On a finite machine the partition stabilizes. The stable partition is `~O`.

This uses no integration threshold or fitted parameter. It does use the state family, possible inputs, observation map and step protocol.

The exhaustive test compares refinement against finite-word behavior on all 5,832 three-state binary-input/output machines. Words of length at most two suffice in that finite case.

## 3. A precise implementation equivalence

Let an implementation `H` and a specification `A` have the same supplied input alphabet. A surjective map `p:S_H→S_A` is an interface-preserving realization morphism if

\[
O_H=O_Ap,
\qquad
p(T_H(h,u))=T_A(p(h),u).
\]

Induction on input words gives

\[
\operatorname{Beh}_H(h,w)=\operatorname{Beh}_A(p(h),w).
\]

Surjectivity ensures every selected specification behavior occurs in the implementation state family. The minimal predictive quotients are therefore isomorphic.

Such morphisms compose, so a host→emulator→target factorization can agree with its direct map. This establishes an operational correspondence, not the identity or number of experiential subjects.

## 4. The decisive counterexample: invisible memory versus an invisible execution

Let `A` have state `x∈{0,1}`, update `x'=1−x`, and observation `O(x)=x`.

### 4.1 Hidden static storage

Add a state bit `z`:

\[
H_{\mathrm{mem}}:\quad(x,z)'=(1-x,z),\qquad O(x,z)=x.
\]

The projection `p(x,z)=x` is a valid realization morphism. The minimum has two states, just like `A`.

This is a precise statement of operational irrelevance to the selected interface. It is not a general theorem that all hidden storage is phenomenally irrelevant.

### 4.2 Hidden complete duplicate

Instead add an independently updating copy:

\[
H_{\mathrm{dup}}:\quad(x,y)'=(1-x,1-y),\qquad O(x,y)=x.
\]

The same projection `p(x,y)=x` is again a valid realization morphism. Again the minimum is `A`.

If the component `A` were independently established to constitute an observer, and these were genuinely distinct executions, the charter's duplication condition would require two realizations. The selected local interface nevertheless cannot distinguish the added copy from arbitrary hidden dynamics that do not feed back into it.

The toy toggle is not asserted to be conscious. The argument is conditional on whatever observer-realizing process the duplicate-preservation requirement applies to.

### 4.3 General padding theorem

For any finite hidden dynamics `Z`, form `A×Z` with independent component updates and an observation that reads only `A`.

Projection onto `A` is a surjective realization morphism. Consequently

\[
\operatorname{Min}_{O_A}(A\times Z)\cong\operatorname{Min}(A).
\]

The theorem permits `Z=A`. Therefore the class of hidden dynamics cannot all be called ontologically harmless merely because they are invisible to `A`'s interface.

## 5. An incompatibility result, stated at the right strength

Suppose a proposed nonzero population count `N` has both properties:

1. **Unrestricted local-quotient invariance:** `N` depends only on the selected minimal predictive type, or is invariant under all the surjective realization morphisms above.
2. **Duplicate preservation:** for a genuine independent duplication of an observer-realizing `A`, `N(A×A)=2N(A)`.

The padding theorem gives `N(A×A)=N(A)`. Together these require `N(A)=0`.

Thus **no nonzero count can satisfy both properties**.

The conclusion is not that duplicate preservation is impossible. It is that unrestricted invariance of a global population under local interface abstraction is too strong.

The repair is to distinguish:

- **type:** what interface-relative organization an occurrence realizes;
- **token:** which concrete occurrence realizes it;
- **population:** which actual realization tokens are included.

A map from occurrences to types can have many distinct occurrences of one type. Quotienting organizational types must not silently quotient away those occurrences.

### 5.1 Why quotient fibers are not an easy repair

In both two-bit examples, each quotient state has two concrete states above it. Those fibers are alternative states of a single compound implementation, not two simultaneously existing subjects.

Increasing hidden storage to three or five possible values changes fiber cardinality without changing the selected observable behavior. Conversely, two synchronized executions may have only two jointly reachable states from a shared initial condition.

Neither number of abstract states, number of quotient fibers, fiber size, nor size of a reachable-state family is thereby a realization-token count.

## 6. A safe irrelevance claim, and an unsafe one

**Safe formal claim:** a variable or distinction can be removed without changing any permitted input/observation history of a specified interface.

**Not established:** the variable is phenomenally irrelevant, does not realize another perspective, or contributes nothing to a relevant population.

Likewise, type-preserving implementation changes can preserve one existing realization's organization while additional independently realized processes coexist in the new implementation. The fate of those other processes is not settled by the local equivalence.

This matters to Bostrom. If his conscious-realization and weighting premises hold, hidden additional realizations can affect the relevant demographic totals despite leaving one observer's interface behavior unchanged. A local abstraction cannot erase them by definition.

No epistemic norm is inferred here. The incompatibility result concerns conflating organizational quotienting with population invariance.

## 7. What the uniqueness theorem does not remove

### 7.1 Target/observation selection

Keep dynamics fixed and change `O`:

- observe the first copy;
- observe the joint pair;
- observe only parity;
- observe a constant.

These yield different predictive organizations. For the two toggling bits, joint observation gives four state behaviors; first-copy observation gives two; a constant gives one. Parity gives two constant-output behaviors rather than the alternating two-state type.

The minimization is canonical **after** the observation family is fixed. It does not select that family.

Four state behaviors are not four subjects, and a one-state predictive model is not proof of one subject.

### 7.2 Temporal protocol

Implement one toggle through two microphases:

\[
(x,0)\mapsto(x,1),\qquad(x,1)\mapsto(1-x,0),\qquad O(x,p)=x.
\]

At the microstep interface all four states are behaviorally distinguishable: phase affects the next observation. At a two-step protocol the phase becomes invisible and the quotient has two states.

No clock has been derived by minimization. The selected protocol decides which histories count as the relevant observations.

### 7.3 Public behavior versus intrinsic experience

Two machines can have the same selected input/output behavior without the report having established that they have the same intrinsic causal organization or phenomenal constitution.

If the observations are specified to include every relevant intrinsic or phenomenal distinction, that strengthens the premise but does not explain why the specification is correct. Calling the output map “self-presentation” would not supply the missing constitutive argument.

### 7.4 Actuality versus unique mathematical type

The quotient theorem establishes a unique minimal representation of a supplied behavior family. It does not establish why that family concretely occurs, why its realizations are conscious, or why any particular number of tokens exists.

This is regional mathematical uniqueness, not the unique maximally intelligible actuality sought by the project.

## 8. Input and assumptions audit

No substantive item among intervention structure, target, ports and event grain has been unconditionally eliminated.

What has been reduced is representational overhead *relative to those inputs*: extra predictive state is quotiented out uniquely when it makes no permitted interface difference.

The shared ledger adds A31–A38, covering:

- selection of input/observation histories;
- the scope of behavioral minimization;
- the possibility of additional hidden realizations;
- explicit temporal protocols;
- the distinction between state fibers and occurrence populations;
- the conditional nature of the duplication premise;
- the limit of regional uniqueness.

Every entry has an `actuality_argument_obligation`. Earlier archives remain unchanged historical snapshots.

## 9. Where this forces the next constitutive argument

There is now a more precise limit on the purely causal route:

> A canonical account of accessible distinctions does not by itself explain which distinctions are intrinsically presented, or how many concrete perspectives are realizing them.

A successful completion must therefore do at least one of the following with an independently justified argument:

1. derive the relevant intrinsic observation/presentation structure from concrete actuality;
2. begin with actual appearing and derive the organizational and implementation relations without leaving appearing as an exempt brute fact;
3. establish principled non-identifiability and restrict the observer/probability claims accordingly.

These are not three established theories. They identify where a substantive premise or derivation must enter. More finite-state minimization cannot substitute for that entry.

A candidate constitutive equivalence must be **local enough** to ignore merely descriptive implementation overhead, yet **discriminating enough** to retain actual additional realizations. The padding theorem shows why merely saying “same behavior” cannot do both jobs globally.

## 10. Files and reproducibility

New files:

- `operational_equivalence.py` — finite Moore machines, behavioral refinement, quotients and interface-preserving morphisms;
- `test_operational_equivalence.py` — 24 new tests;
- `operational_test_results.txt` — recorded new-suite run;
- `operational_scope_audit_v0_4.csv` — case-level distinctions;
- `combined_test_results_v0_4.txt` — complete regression run;
- `assumptions_ledger.csv` — shared updated ledger.

Run all four suites:

```bash
cd realization_tokens
python -m unittest -v \
  test_realization_tokens.py \
  test_intervention_selection.py \
  test_interface_derivation.py \
  test_operational_equivalence.py
```

**Acceptance judgment:** a standard conditional uniqueness theorem has been made executable; its exact failure as a global realization-counting principle is established; implementation type, concrete token and population measure are kept distinct. No phenomenal identity, epistemic measure, or complete actuality account is claimed.
