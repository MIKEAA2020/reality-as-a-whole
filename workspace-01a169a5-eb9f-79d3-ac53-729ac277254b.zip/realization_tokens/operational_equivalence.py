"""WP3 v0.4: interface-relative behavioral equivalence of finite Moore machines.

Standard finite-state minimization is used as a candidate organization rule.
Behavioral irrelevance is NOT asserted to imply phenomenal irrelevance,
absence of other realizations, or equality of realization-token numbers.
"""
from __future__ import annotations

from dataclasses import dataclass
from itertools import permutations, product
from typing import Callable, Hashable, Iterable

from realization_tokens import partition_code


@dataclass(frozen=True)
class MooreMachine:
    states: tuple[Hashable, ...]
    inputs: tuple[Hashable, ...]
    transition: Callable[[Hashable, Hashable], Hashable]
    observe: Callable[[Hashable], Hashable]
    name: str = ""

    def __post_init__(self):
        if not self.states or len(set(self.states)) != len(self.states):
            raise ValueError("Need a nonempty duplicate-free state family.")
        if not self.inputs or len(set(self.inputs)) != len(self.inputs):
            raise ValueError("Need a nonempty duplicate-free input alphabet.")
        for state in self.states:
            hash(self.observe(state))
            for value in self.inputs:
                if self.transition(state, value) not in self.states:
                    raise ValueError("Transition leaves the selected state family.")

    def behavior(self, initial: Hashable, word: Iterable[Hashable]):
        if initial not in self.states:
            raise ValueError("Initial state is outside the machine.")
        state = initial
        outputs = [self.observe(state)]
        for value in word:
            if value not in self.inputs:
                raise ValueError("Unknown interface input.")
            state = self.transition(state, value)
            outputs.append(self.observe(state))
        return tuple(outputs)

    def refinement_history(self):
        """Start with observation equality, refine by all input successors."""
        index = {state: i for i, state in enumerate(self.states)}
        code = partition_code(self.observe(s) for s in self.states)
        history = [code]
        while True:
            refined = partition_code(
                (code[i], tuple(code[index[self.transition(state, u)]] for u in self.inputs))
                for i, state in enumerate(self.states)
            )
            if refined == code:
                return tuple(history)
            history.append(refined)
            code = refined

    def behavior_partition(self):
        return self.refinement_history()[-1]

    def quotient(self):
        code = self.behavior_partition()
        projection = dict(zip(self.states, code))
        representatives = {}
        for state, block in projection.items():
            representatives.setdefault(block, state)
        table = {
            (block, value): projection[self.transition(state, value)]
            for block, state in representatives.items()
            for value in self.inputs
        }
        outputs = {block: self.observe(state) for block, state in representatives.items()}
        quotient = MooreMachine(
            tuple(range(len(representatives))),
            self.inputs,
            lambda block, value: table[(block, value)],
            lambda block: outputs[block],
            name=f"minimum({self.name})",
        )
        return quotient, projection

    def reachable(self, initial):
        seen, frontier = {initial}, [initial]
        if initial not in self.states:
            raise ValueError("Initial state outside machine.")
        while frontier:
            state = frontier.pop()
            for value in self.inputs:
                successor = self.transition(state, value)
                if successor not in seen:
                    seen.add(successor)
                    frontier.append(successor)
        return MooreMachine(
            tuple(s for s in self.states if s in seen),
            self.inputs, self.transition, self.observe,
            name=f"reachable({self.name})",
        )

    def transported(self, bijection, *, reverse_enumeration=False):
        mapping = {state: bijection(state) for state in self.states}
        if len(set(mapping.values())) != len(self.states):
            raise ValueError("Need a state bijection.")
        inverse = {image: source for source, image in mapping.items()}
        states = tuple(mapping[s] for s in self.states)
        if reverse_enumeration:
            states = states[::-1]
        return MooreMachine(
            states, self.inputs,
            lambda state, value: mapping[self.transition(inverse[state], value)],
            lambda state: self.observe(inverse[state]),
            name=f"transport({self.name})",
        )


def isomorphic(a: MooreMachine, b: MooreMachine):
    """Finite exact isomorphism, preserving this supplied input/output interface."""
    if len(a.states) != len(b.states) or a.inputs != b.inputs:
        return False
    for ordered_images in permutations(b.states):
        bijection = dict(zip(a.states, ordered_images))
        if not all(a.observe(s) == b.observe(bijection[s]) for s in a.states):
            continue
        if all(
            bijection[a.transition(s, u)] == b.transition(bijection[s], u)
            for s in a.states for u in a.inputs
        ):
            return True
    return False


def realization_morphism(
    implementation: MooreMachine,
    specification: MooreMachine,
    projection: Callable,
    *,
    surjective=True,
):
    """A stepwise input/output preserving map; no token-count conclusion."""
    if implementation.inputs != specification.inputs:
        return False
    try:
        images = {projection(s) for s in implementation.states}
    except (KeyError, TypeError, ValueError):
        return False
    if not images.issubset(specification.states):
        return False
    if surjective and images != set(specification.states):
        return False
    return all(
        implementation.observe(s) == specification.observe(projection(s))
        and all(
            projection(implementation.transition(s, u))
            == specification.transition(projection(s), u)
            for u in implementation.inputs
        )
        for s in implementation.states
    )


def padded(machine: MooreMachine, extra_states: tuple, extra_transition: Callable, *, name="padding"):
    """Independent hidden dynamics, unobserved by the SELECTED interface.

    The extra dynamics is not asserted to be ontologically harmless. It can
    itself implement another full machine. This is the main countermodel.
    """
    return MooreMachine(
        tuple(product(machine.states, extra_states)),
        machine.inputs,
        lambda state, value: (
            machine.transition(state[0], value),
            extra_transition(state[1], value),
        ),
        lambda state: machine.observe(state[0]),
        name=name,
    )


def parallel(a: MooreMachine, b: MooreMachine, *, joint_observation=False):
    if a.inputs != b.inputs:
        raise ValueError("Parallel machines need this shared input interface.")
    observe = (
        (lambda state: (a.observe(state[0]), b.observe(state[1])))
        if joint_observation else (lambda state: a.observe(state[0]))
    )
    return MooreMachine(
        tuple(product(a.states, b.states)),
        a.inputs,
        lambda state, value: (a.transition(state[0], value), b.transition(state[1], value)),
        observe,
        name="parallel",
    )


def sample(machine: MooreMachine, stride: int):
    """Hold a supplied input fixed during each block of microsteps.

    This explicit protocol is a grain assumption, not an intrinsic clock.
    """
    if stride <= 0:
        raise ValueError("Stride must be positive.")
    def transition(state, value):
        for _ in range(stride):
            state = machine.transition(state, value)
        return state
    return MooreMachine(machine.states, machine.inputs, transition, machine.observe,
                        name=f"sample[{stride}]({machine.name})")


def input_words(alphabet, max_length):
    return tuple(word for length in range(max_length + 1) for word in product(alphabet, repeat=length))
