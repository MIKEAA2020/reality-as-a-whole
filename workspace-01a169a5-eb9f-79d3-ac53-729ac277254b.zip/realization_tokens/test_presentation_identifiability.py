"""WP4 v0.5: three-option checks with explicitly limited interpretations.

Cross-role dependencies: formal epistemology limits q/tau and set-to-probability
inferences; computation supplies finite dynamics and padding; physics/credence
supplies observation, intervention and temporal protocols; project lead supplies
constitutive criteria and actuality obligations. These tests do not certify
consciousness, necessity, or actual existence of their models. See the shared
wp4_cross_role_dependencies_v0_5.csv audit for the deliverable-level record.
"""
from itertools import product
import unittest

from interface_derivation import EventGraph, admissible_interfaces
from intervention_selection import BitNetwork, action_partition, conjugate_map
from operational_equivalence import MooreMachine, input_words, isomorphic, realization_morphism
from presentation_identifiability import (
    ModalFrame, all_coordinate_subsets, coordinate_projection_partition,
    coordinate_reset_maps, identification_set, identification_status,
    network_map, performative_necessity_countermodel, recover_projection_support,
    replication_model, set_partition_codes, stable_partitions,
    transport_projection_in_three_ring,
)


class PresentationIdentifiabilityTests(unittest.TestCase):
    def setUp(self):
        self.ring = BitNetwork.from_function(3, lambda s: (s[1], s[2], s[0]))
        self.shared = BitNetwork.from_function(3, lambda s: (s[0] ^ s[2], s[1] ^ s[2], s[2]))
        self.resets = coordinate_reset_maps(3)

    def test_01_enumerates_all_4140_partitions_of_eight_states(self):
        partitions = tuple(set_partition_codes(8))
        self.assertEqual(len(partitions), 4140)
        self.assertEqual(len(set(partitions)), 4140)

    def test_02_reset_stable_congruences_are_exactly_coordinate_projections(self):
        actual = stable_partitions(8, self.resets)
        expected = frozenset(coordinate_projection_partition(3, subset) for subset in all_coordinate_subsets(3))
        self.assertEqual(actual, expected)
        self.assertEqual(len(actual), 8)

    def test_03_closed_shared_control_has_five_stable_presentations(self):
        actual = stable_partitions(8, self.resets | {network_map(self.shared)})
        supports = {recover_projection_support(3, p) for p in actual}
        self.assertEqual(supports, {frozenset(), frozenset({2}), frozenset({0, 2}),
                                    frozenset({1, 2}), frozenset({0, 1, 2})})

    def test_04_coarsest_nonconstant_and_finest_choices_are_different(self):
        actual = stable_partitions(8, self.resets | {network_map(self.shared)})
        informative = [p for p in actual if len(set(p)) > 1]
        coarsest = min(informative, key=lambda p: len(set(p)))
        finest = max(informative, key=lambda p: len(set(p)))
        self.assertEqual(recover_projection_support(3, coarsest), frozenset({2}))
        self.assertEqual(recover_projection_support(3, finest), frozenset({0, 1, 2}))
        self.assertNotEqual(coarsest, finest)

    def test_05_closed_ring_has_only_constant_and_full_fixed_presentations(self):
        actual = stable_partitions(8, self.resets | {network_map(self.ring)})
        supports = {recover_projection_support(3, p) for p in actual}
        self.assertEqual(supports, {frozenset(), frozenset({0, 1, 2})})

    def test_06_transported_presentations_follow_every_nonempty_lane_subset(self):
        for subset in all_coordinate_subsets(3):
            if not subset:
                continue
            for time in range(6):
                now = transport_projection_in_three_ring(subset, time)
                after = transport_projection_in_three_ring(subset, time + 1)
                for state in self.ring.states:
                    self.assertEqual(after(self.ring.step(state)), now(state))

    def test_07_seven_nonempty_transport_covariant_candidate_observations(self):
        candidates = {
            coordinate_projection_partition(3, subset)
            for subset in all_coordinate_subsets(3) if subset
        }
        self.assertEqual(len(candidates), 7)
        # This is a family of alternative targets, not seven subjects.

    def test_08_externalizing_control_changes_the_candidate_spectrum(self):
        network0 = BitNetwork.from_function(2, lambda s: s)
        network1 = BitNetwork.from_function(2, lambda s: (1-s[0], 1-s[1]))
        maps = coordinate_reset_maps(2) | {network_map(network0), network_map(network1)}
        actual = stable_partitions(4, maps)
        self.assertEqual(len(actual), 4)
        self.assertIn(coordinate_projection_partition(2, {0}), actual)
        self.assertIn(coordinate_projection_partition(2, {1}), actual)

    def test_09_structural_spectrum_is_covariant_under_passive_state_renaming(self):
        maps = self.resets | {network_map(self.shared)}
        permutation = tuple(reversed(range(8)))
        original = stable_partitions(8, maps)
        moved = stable_partitions(8, {conjugate_map(m, permutation) for m in maps})
        expected = frozenset(action_partition(p, permutation) for p in original)
        self.assertEqual(moved, expected)

    def test_10_temporal_protocol_changes_fixed_presentation_spectrum(self):
        micro = stable_partitions(8, self.resets | {network_map(self.ring)})
        macro = stable_partitions(8, self.resets | {network_map(self.ring.sampled(3))})
        self.assertEqual((len(micro), len(macro)), (2, 8))

    def test_11_performative_undeniability_does_not_entail_necessary_appearing(self):
        frame = performative_necessity_countermodel()
        self.assertTrue(frame.atom("actual", "appearing"))
        self.assertTrue(frame.atom("actual", "attempted_denial"))
        self.assertTrue(frame.box("actual", lambda w: not frame.atom(w, "attempted_denial") or frame.atom(w, "appearing")))
        self.assertFalse(frame.box("actual", lambda w: frame.atom(w, "appearing")))

    def test_12_same_actual_premises_do_not_entail_nonnecessity_either(self):
        first = performative_necessity_countermodel()
        second = ModalFrame(first.worlds, first.accessibility,
                            {"appearing": first.worlds, "attempted_denial": frozenset({"actual"})})
        for frame in (first, second):
            self.assertTrue(frame.atom("actual", "appearing"))
            self.assertTrue(frame.box("actual", lambda w: not frame.atom(w, "attempted_denial") or frame.atom(w, "appearing")))
        self.assertTrue(second.box("actual", lambda w: second.atom(w, "appearing")))
        # These are logical frames, not established possible physical worlds.

    def test_13_actual_appearing_history_does_not_select_counterfactual_dynamics(self):
        responsive = MooreMachine((0, 1), (0, 1), lambda s, u: s ^ u, lambda s: s)
        forced = MooreMachine((0, 1), (0, 1), lambda s, u: 1-s, lambda s: s)
        self.assertEqual(responsive.behavior(0, (1, 1, 1)), forced.behavior(0, (1, 1, 1)))
        self.assertNotEqual(responsive.behavior(0, (0,)), forced.behavior(0, (0,)))

    def test_14_complete_selected_interface_histories_do_not_select_global_copy_count(self):
        base = MooreMachine((0, 1), (0, 1), lambda s, u: s ^ u, lambda s: s)
        for copies in range(1, 7):
            model = replication_model(base, copies)
            self.assertTrue(realization_morphism(model, base, lambda state: state[0]))
            self.assertTrue(isomorphic(model.quotient()[0], base.quotient()[0]))
            for word in input_words(base.inputs, 3):
                self.assertEqual(model.behavior((0,) * copies, word), base.behavior(0, word))

    def test_15_conditional_copy_counts_form_an_identification_set_not_a_distribution(self):
        models = tuple(range(1, 7))
        values = identification_set(models, lambda copies: copies)
        self.assertEqual(values, frozenset(range(1, 7)))
        self.assertEqual(identification_status(values), "set_identified_not_point_identified")

    def test_16_identification_status_distinguishes_empty_single_and_family(self):
        self.assertEqual(identification_status(()), "inconsistent_or_empty_model_class")
        self.assertEqual(identification_status({3}), "point_identified_in_this_model_class")
        self.assertEqual(identification_status({1, 2}), "set_identified_not_point_identified")

    def test_17_shared_case_identifies_annotation_family_not_subject_count(self):
        family = admissible_interfaces(self.shared)
        self.assertEqual(len(family), 4)
        values = identification_set(family, lambda annotation: len(annotation.blocks))
        self.assertEqual(values, frozenset({1, 2}))

    def test_18_three_wire_paths_are_not_seven_observation_candidates(self):
        nodes = frozenset(f"{i}:{t}" for i in range(3) for t in range(4))
        edges = frozenset((f"{i}:{t}", f"{j}:{t+1}") for t in range(3) for i,j in self.ring.dependency_edges())
        graph = EventGraph(nodes, edges)
        self.assertEqual(len(graph.threads()), 3)
        self.assertEqual(len([s for s in all_coordinate_subsets(3) if s]), 7)

    def test_19_weak_weight_constraints_allow_distinct_numbers_without_warranting_them(self):
        compatible = []
        for base_weight in (0.001, 0.1, 0.5, 0.99):
            weights = [base_weight] + [(1-base_weight)/99] * 99
            self.assertAlmostEqual(sum(weights), 1)
            self.assertEqual(len(set(weights[1:])), 1)
            compatible.append(sum(weights[1:]))
        self.assertEqual(len(set(compatible)), 4)
        # Compatibility with these weak constraints is not proof of rational permission.

    def test_20_additional_calibration_can_narrow_relative_nonidentifiability(self):
        # Three individual readout candidates agree at 000.
        candidates = tuple(range(3))
        actual = (0, 0, 0)
        self.assertEqual({actual[i] for i in candidates}, {0})
        # IF an intervention and its experienced output are independently known,
        # resetting coordinate 0 to 1 with reported output 1 identifies that
        # readout among these three candidates. The phenomenal association is
        # additional data, not something this test derives.
        calibrated_state, reported_output = (1, 0, 0), 1
        surviving = {i for i in candidates if calibrated_state[i] == reported_output}
        self.assertEqual(surviving, {0})


    def _moving_lane_models(self):
        inputs = (None, 0, 1)
        states = tuple((state, phase) for state in self.ring.states for phase in range(3))
        def advance(value, control):
            state, phase = value
            changed = list(state)
            if control is not None:
                changed[(-phase) % 3] = control
            return (self.ring.step(tuple(changed)), (phase + 1) % 3)
        def read(value):
            state, phase = value
            return state[(-phase) % 3]
        moving = MooreMachine(states, inputs, advance, read)
        stationary = MooreMachine((0, 1), inputs,
                                  lambda state, control: state if control is None else control,
                                  lambda state: state)
        return moving, stationary, read

    def _shared_readout_models(self):
        inputs = ((None, None),) + tuple((i, value) for i in range(3) for value in (0, 1))
        def advance(state, control):
            changed = list(state)
            coordinate, value = control
            if coordinate is not None:
                changed[coordinate] = value
            return self.shared.step(tuple(changed))
        def reduced_advance(state, control):
            x, c = state
            coordinate, value = control
            if coordinate == 0:
                x = value
            elif coordinate == 2:
                c = value
            return (x ^ c, c)
        whole = MooreMachine(self.shared.states, inputs, advance, lambda state: state[0])
        reduced = MooreMachine(tuple(product((0, 1), repeat=2)), inputs,
                               reduced_advance, lambda state: state[0])
        return whole, reduced

    def test_21_appearing_data_at_lane_interface_does_not_select_storage_organization(self):
        moving, stationary, read = self._moving_lane_models()
        self.assertTrue(realization_morphism(moving, stationary, read))
        self.assertTrue(isomorphic(moving.quotient()[0], stationary.quotient()[0]))
        for state in moving.states:
            for word in input_words(moving.inputs, 3):
                self.assertEqual(moving.behavior(state, word), stationary.behavior(read(state), word))

    def test_22_complete_lane_interface_does_not_select_total_ring_multiplicity(self):
        moving, _, _ = self._moving_lane_models()
        replicated = replication_model(moving, 2)
        self.assertTrue(realization_morphism(replicated, moving, lambda state: state[0]))
        self.assertTrue(isomorphic(replicated.quotient()[0], moving.quotient()[0]))
        for word in input_words(moving.inputs, 3):
            self.assertEqual(replicated.behavior((((1, 0, 0), 0), ((1, 0, 0), 0)), word),
                             moving.behavior(((1, 0, 0), 0), word))

    def test_23_appearing_data_at_shared_x_interface_does_not_identify_sibling_process(self):
        whole, reduced = self._shared_readout_models()
        project = lambda state: (state[0], state[2])
        self.assertTrue(realization_morphism(whole, reduced, project))
        self.assertEqual(len(whole.quotient()[0].states), 4)
        self.assertTrue(isomorphic(whole.quotient()[0], reduced.quotient()[0]))
        for state in whole.states:
            for word in input_words(whole.inputs, 3):
                self.assertEqual(whole.behavior(state, word), reduced.behavior(project(state), word))

    def test_24_complete_shared_x_interface_does_not_identify_total_multiplicity(self):
        whole, _ = self._shared_readout_models()
        replicated = replication_model(whole, 2)
        self.assertTrue(realization_morphism(replicated, whole, lambda state: state[0]))
        self.assertTrue(isomorphic(replicated.quotient()[0], whole.quotient()[0]))
        for word in input_words(whole.inputs, 3):
            self.assertEqual(replicated.behavior(((0, 0, 1), (0, 0, 1)), word),
                             whole.behavior((0, 0, 1), word))


if __name__ == "__main__":
    unittest.main(verbosity=2)
