"""Executable finite checks and counterexamples for WP1 v0.1.

Passing these tests verifies the CONDITIONAL schema and the stated toy-model
counterexamples. It is not evidence that R0 individuates conscious subjects.
"""
from dataclasses import replace
from itertools import product
import unittest

from realization_tokens import (
    Block,
    Description,
    FiniteFrame,
    InvalidDescription,
    Verdict,
    classify,
    compose,
    kernel_refines,
    same_role_segment,
    transport_description,
    transport_frame,
)


class RealizationTokenTests(unittest.TestCase):
    def setUp(self):
        self.states = tuple(product((0, 1), repeat=2))
        phases = ("run", "replay", "fast", "left", "right", "merged")
        events = frozenset(
            f"{coordinate}:{phase}:{i}"
            for coordinate in ("x", "y")
            for phase in phases
            for i in range(6)
        )
        self.frame = FiniteFrame(
            "two synchronized but counterfactually separable bits",
            self.states,
            lambda s: (1 - s[0], 1 - s[1]),
            events,
        )

    def role(self, coordinate="x", phase="run", n=2, decode=None, stride=1):
        index = 0 if coordinate == "x" else 1
        return Description(
            self.frame,
            tuple(Block(frozenset({f"{coordinate}:{phase}:{i}"})) for i in range(n)),
            tuple(self.frame.advance((0, 0), i * stride) for i in range(n + 1)),
            (lambda s: s[index]) if decode is None else decode,
            stride,
            f"{coordinate}/{phase}",
        )

    def shared_support_roles(self, frame=None):
        frame = self.frame if frame is None else frame
        blocks = tuple(
            Block(frozenset({f"x:run:{i}", f"y:run:{i}"})) for i in range(2)
        )
        path = ((0, 0), (1, 1), (0, 0))
        return (
            Description(frame, blocks, path, lambda s: s[0], label="shared-support/x"),
            Description(frame, blocks, path, lambda s: s[1], label="shared-support/y"),
        )

    def test_01_state_label_renaming_is_same(self):
        a = self.role()
        b = replace(a, decode=lambda s: "off" if s[0] else "on")
        self.assertTrue(same_role_segment(a, b))

    def test_02_redundant_output_encoding_is_same(self):
        a = self.role()
        b = replace(a, decode=lambda s: (s[0], s[0]))
        self.assertTrue(same_role_segment(a, b))

    def test_03_equivalent_decoder_expression_is_same(self):
        a = self.role()
        b = replace(a, decode=lambda s: 1 - (1 - s[0]))
        self.assertTrue(same_role_segment(a, b))

    def test_04_identical_abstract_types_do_not_identify_copies(self):
        a, b = self.role("x"), self.role("y")
        self.assertEqual(a.quotient_code(), b.quotient_code())
        self.assertEqual(a.abstract_trace_code(), b.abstract_trace_code())
        self.assertFalse(same_role_segment(a, b))
        self.assertEqual(classify(a, b), Verdict.DISTINCT_SEGMENTS)

    def test_05_nested_mapping_and_flattening_are_same(self):
        a = self.role()
        host_to_virtual = lambda s: {"virtual_x": s[0], "virtual_y": s[1]}
        virtual_to_role = lambda v: v["virtual_x"]
        b = replace(
            a,
            decode=compose(host_to_virtual, virtual_to_role),
            derivation=("host -> virtual world", "virtual world -> role"),
        )
        self.assertTrue(same_role_segment(a, b))

    def test_06_nested_composition_with_nontrivial_clocks(self):
        frame = FiniteFrame(
            "12-cycle host",
            tuple(range(12)),
            lambda s: (s + 1) % 12,
            frozenset(f"h:{i}" for i in range(12)),
        )
        host_to_virtual = lambda s: s // 2
        virtual_to_role = lambda v: v % 3
        for s in frame.states:
            self.assertEqual(
                host_to_virtual(frame.advance(s, 2)),
                (host_to_virtual(s) + 1) % 6,
            )
        for v in range(6):
            self.assertEqual(virtual_to_role((v + 3) % 6), virtual_to_role(v))
        blocks = (
            Block(frozenset(f"h:{i}" for i in range(6))),
            Block(frozenset(f"h:{i}" for i in range(6, 12))),
        )
        direct = Description(frame, blocks, (0, 6, 0), lambda s: (s // 2) % 3, stride=6)
        composed = replace(direct, decode=compose(host_to_virtual, virtual_to_role))
        self.assertTrue(same_role_segment(direct, composed))

    def test_07_extra_internal_process_is_not_an_alias(self):
        a = self.role("x")
        alias = replace(a, decode=compose(lambda s: s, lambda s: s[0]))
        internal = self.role("y")
        self.assertTrue(same_role_segment(a, alias))
        self.assertEqual(classify(a, internal), Verdict.DISTINCT_SEGMENTS)

    def test_08_copying_source_text_adds_no_events(self):
        a = self.role()
        b = replace(a, label="second source listing", derivation=("copied text",))
        self.assertTrue(same_role_segment(a, b))

    def test_09_elapsed_time_redescription_is_same_at_this_grain(self):
        a = self.role()
        b = replace(a, blocks=tuple(replace(block, elapsed=1000.0) for block in a.blocks))
        self.assertTrue(same_role_segment(a, b))

    def test_10_certified_inert_pause_adds_no_active_block(self):
        a = self.role()
        b = replace(
            a,
            blocks=(a.blocks[0], Block(frozenset(), inert=True, elapsed=100.0), a.blocks[1]),
        )
        self.assertTrue(same_role_segment(a, b))

    def test_11_active_selfloop_cannot_be_erased_as_a_pause(self):
        frame = FiniteFrame("constant state, real updates", (0,), lambda s: s, frozenset({"u0", "u1"}))
        short = Description(frame, (Block(frozenset({"u0"})),), (0, 0), lambda s: s)
        long = Description(
            frame,
            (Block(frozenset({"u0"})), Block(frozenset({"u1"}))),
            (0, 0, 0),
            lambda s: s,
        )
        self.assertFalse(same_role_segment(short, long))
        self.assertEqual(classify(short, long), Verdict.OPEN)

    def test_12_pause_only_interval_is_explicitly_out_of_scope(self):
        a = self.role()
        pause = replace(a, blocks=(Block(frozenset(), inert=True),), path=((0, 0),))
        with self.assertRaises(InvalidDescription):
            pause.validate()

    def test_13_sequential_repetition_has_distinct_segment_anchors(self):
        a, replay = self.role("x", "run"), self.role("x", "replay")
        self.assertEqual(a.abstract_trace_code(), replay.abstract_trace_code())
        self.assertEqual(classify(a, replay), Verdict.DISTINCT_SEGMENTS)

    def test_14_separate_fast_execution_is_not_time_redescription(self):
        a = self.role("x", "run")
        fast = self.role("x", "fast")
        fast = replace(fast, blocks=tuple(replace(b, elapsed=0.001) for b in fast.blocks))
        self.assertEqual(classify(a, fast), Verdict.DISTINCT_SEGMENTS)

    def test_15_actual_path_fit_is_not_counterfactual_adequacy(self):
        a = self.role()
        bad = replace(a, decode=lambda s: s[0] & s[1])
        self.assertEqual([bad.decode(s) for s in bad.path], [a.decode(s) for s in a.path])
        with self.assertRaises(InvalidDescription):
            bad.validate()

    def test_16_same_event_support_does_not_establish_same_role(self):
        a, b = self.shared_support_roles()
        self.assertEqual(a.support, b.support)
        self.assertFalse(same_role_segment(a, b))
        self.assertEqual(classify(a, b), Verdict.OPEN)

    def test_17_coarse_and_fine_roles_are_not_automatically_same_or_two_subjects(self):
        coarse, _ = self.shared_support_roles()
        fine = replace(coarse, decode=lambda s: s)
        self.assertTrue(kernel_refines(fine, coarse))
        self.assertFalse(kernel_refines(coarse, fine))
        self.assertEqual(classify(coarse, fine), Verdict.OPEN)

    def test_18_counterfactual_domain_changes_role_identification(self):
        full_x, full_y = self.shared_support_roles()
        weak_frame = FiniteFrame(
            "diagonal-only domain",
            self.frame.states,
            self.frame.step,
            self.frame.events,
            domain=((0, 0), (1, 1)),
        )
        weak_x, weak_y = self.shared_support_roles(weak_frame)
        self.assertFalse(same_role_segment(full_x, full_y))
        self.assertTrue(same_role_segment(weak_x, weak_y))

    def test_19_passive_global_relabelling_preserves_verdicts(self):
        state_map = lambda s: (s[1], s[0])
        event_map = lambda e: "renamed/" + e
        new_frame, inverse = transport_frame(
            self.frame, state_map, event_map, reverse_enumeration=True
        )
        descriptions = [self.role("x"), self.role("y"), self.role("x", "replay")]
        descriptions.append(replace(descriptions[0], decode=lambda s: 1 - s[0]))
        transported = [
            transport_description(d, new_frame, state_map, inverse, event_map)
            for d in descriptions
        ]
        for i, a in enumerate(descriptions):
            for j, b in enumerate(descriptions):
                self.assertEqual(classify(a, b), classify(transported[i], transported[j]))

    def test_20_swapping_only_one_occurrence_is_not_passive_redescription(self):
        a, b = self.role("x"), self.role("y")
        self.assertEqual(a.quotient_code(), b.quotient_code())
        self.assertEqual(classify(a, b), Verdict.DISTINCT_SEGMENTS)

    def test_21_R0_is_an_equivalence_relation_in_fixed_frame(self):
        a = self.role("x")
        ds = [
            a,
            replace(a, decode=lambda s: 1 - s[0]),
            replace(a, decode=lambda s: (s[0], s[0])),
            self.role("y"),
            self.role("x", "replay"),
        ]
        for x in ds:
            self.assertTrue(same_role_segment(x, x))
            for y in ds:
                self.assertEqual(same_role_segment(x, y), same_role_segment(y, x))
                for z in ds:
                    if same_role_segment(x, y) and same_role_segment(y, z):
                        self.assertTrue(same_role_segment(x, z))

    def test_22_cross_frame_numerical_identity_is_not_silently_defined(self):
        a = self.role()
        other = FiniteFrame("another frame", self.frame.states, self.frame.step, self.frame.events)
        with self.assertRaises(ValueError):
            same_role_segment(a, replace(a, frame=other))

    def test_23_changing_sampling_grain_is_not_automatically_redescription(self):
        fine = self.role()
        coarse = Description(
            self.frame,
            (Block(frozenset({"x:run:0", "x:run:1"})),),
            ((0, 0), (0, 0)),
            lambda s: s[0],
            stride=2,
        )
        self.assertEqual(fine.support, coarse.support)
        self.assertFalse(same_role_segment(fine, coarse))
        self.assertEqual(classify(fine, coarse), Verdict.OPEN)

    def test_24_nonclosed_counterfactual_domain_is_rejected(self):
        frame = FiniteFrame(
            "3-cycle with insufficient domain",
            (0, 1, 2),
            lambda s: (s + 1) % 3,
            frozenset({"a"}),
            domain=(0, 1),
        )
        d = Description(frame, (Block(frozenset({"a"})),), (0, 1), lambda s: s)
        with self.assertRaises(InvalidDescription):
            d.validate()

    def test_25_uncertified_empty_active_block_is_rejected(self):
        with self.assertRaises(ValueError):
            Block(frozenset(), inert=False)

    def test_26_fork_cannot_be_encoded_as_identity_with_both_children(self):
        # p~left and p~right force left~right under any equivalence relation.
        parent = {"p": "p", "left": "left", "right": "right"}

        def find(x):
            while parent[x] != x:
                x = parent[x]
            return x

        def union(x, y):
            parent[find(x)] = find(y)

        union("p", "left")
        union("p", "right")
        self.assertEqual(find("left"), find("right"))
        left, right = self.role("x", "left"), self.role("x", "right")
        self.assertEqual(classify(left, right), Verdict.DISTINCT_SEGMENTS)

    def test_27_merge_has_the_dual_identity_problem(self):
        # Explicit equivalence closure of left~merged and right~merged.
        relation = {(x, x) for x in ("left", "right", "merged")}
        relation.update({("left", "merged"), ("merged", "left"),
                         ("right", "merged"), ("merged", "right")})
        changed = True
        while changed:
            additions = {(a, d) for a, b in relation for c, d in relation if b == c}
            changed = not additions.issubset(relation)
            relation.update(additions)
        self.assertIn(("left", "right"), relation)
        left, right = self.role("x", "left"), self.role("x", "right")
        self.assertFalse(same_role_segment(left, right))

    def test_28_support_overlap_is_not_an_equivalence_relation(self):
        a, b, c = {"e0"}, {"e0", "e1"}, {"e1"}
        self.assertTrue(a & b)
        self.assertTrue(b & c)
        self.assertFalse(a & c)

    def test_29_dynamics_alone_does_not_select_a_factorization(self):
        # x'=not x, y'=not y becomes u'=not u, v'=v for u=x, v=x XOR y.
        for x, y in self.states:
            u, v = x, x ^ y
            nx, ny = self.frame.step((x, y))
            nu, nv = nx, nx ^ ny
            self.assertEqual((nu, nv), (1 - u, v))

    def test_30_occurrence_symmetry_does_not_fix_cross_group_weights(self):
        for q in (0.01, 0.5, 0.9):
            weights = [q] + [(1 - q) / 99] * 99
            self.assertAlmostEqual(sum(weights), 1.0)
            self.assertEqual(len(set(weights[1:])), 1)
            self.assertAlmostEqual(sum(weights[1:]), 1 - q)
        # This is a counterexample check, not an implemented epistemic norm.

    def test_31_composition_associativity_does_not_add_tokens(self):
        a = self.role()
        f = lambda s: {"x": s[0]}
        g = lambda v: (v["x"],)
        h = lambda v: v[0]
        left = replace(a, decode=compose(compose(f, g), h))
        right = replace(a, decode=compose(f, compose(g, h)))
        self.assertTrue(same_role_segment(left, right))
        self.assertTrue(same_role_segment(a, left))

    def test_32_reusing_one_occurrence_event_is_not_a_second_update(self):
        a = self.role()
        bad = replace(a, blocks=(a.blocks[0], a.blocks[0]))
        with self.assertRaises(InvalidDescription):
            bad.validate()


if __name__ == "__main__":
    unittest.main(verbosity=2)
