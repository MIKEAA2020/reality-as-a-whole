# Work Package 4 — Three options, tested, v0.5

## Constitutive derivation not supplied; relative non-identifiability established

**Decision:** option 3 is a legitimate, positive result under the currently specified constraints. The two tested routes toward options 1 and 2 do not supply a constitutive completion. This is not a proof that either option is impossible in principle, that all possible evidence is insufficient, or that a unique maximally intelligible actuality does not exist.

**Scope:** concrete finite causal/intervention models as supplied in earlier stages; candidate presentation partitions; local first-person appearing as a starting datum; and explicitly delimited logical inference tests. No candidate partition is declared phenomenal merely by definition.

**Validation:** 24 new tests pass; 136 tests pass in the combined regression suite. The new presentation enumeration checks all 4,140 partitions of each eight-state test space. The logical modal examples test entailment from stated premises, not metaphysical possibility.

**Precision retained from v0.4:** the padding incompatibility excludes the proposed conjunction of unrestricted local-abstraction invariance and nonzero duplicate preservation. It does not exclude all population counts or all possible measures. This limitation is now explicit in the shared ledger.

---

## 1. Success criteria and limits

The work package tests:

1. whether causal actuality can select an intrinsic presentation structure;
2. whether actual appearing can yield organization and necessity without being exempted as brute;
3. what is identifiable, set-identifiable, or suspended on the two decisive cases.

A parameter-free derived family is an acceptable output. It is not to be averaged without a justified measure, interpreted as simultaneous observers, or reduced to one answer by an unexplained preference.

“Failure” below means failure of the explicit attempted derivation. It is not an exhaustive refutation of every possible constitutive metaphysics.

## 2. Option 1 attempt: intrinsic distinctions as stable congruences

### 2.1 Why this candidate is worth testing

A natural stronger candidate than raw behavioral minimization is the entire family of distinctions respected by the model's intrinsic operations: dynamics plus the supplied intervention algebra.

Let `S` be the concrete state space and `M` its selected transformations. An equivalence relation `~` is stable when

\[
s\sim t\Rightarrow m(s)\sim m(t)
\quad\text{for every }m\in M.
\]

The resulting quotient admits every selected transformation without depending on a particular output-state naming scheme. Its family is fully enumerable in the finite examples, with no integration threshold or numerical preference.

This gives candidate structural presentations, not yet experienced presentations.

### 2.2 Reset-congruence lemma

On a full finite product of binary coordinates, take all elementary coordinate-reset operations. The stable equivalence relations are exactly equality on some selected subset of coordinates, including the empty and complete subsets.

**Proof.** If equivalent states differ at coordinate `i`, reset all other coordinates to any common context. This gives equivalent states differing only at `i` in that context. Arbitrary resets of the other coordinates give the same equivalence in every context. Thus any coordinate ever differing within an equivalence class can be forgotten globally. Changing those forgotten coordinates one at a time gives the corresponding product equivalence. No pair can differ in a non-forgotten coordinate by definition. Conversely, equality on a selected coordinate subset is preserved by every coordinate reset. ∎

Adding the dynamics requires that the selected coordinates define an autonomous quotient. Thus the algebra derives a spectrum of stable distinctions rather than an externally named output map.

This is real conditional progress. The selected intervention algebra and its full-product variation remain inputs.

## 3. Option 1 on the moving-storage case

Use the three-register permutation

\[
F(x,y,z)=(y,z,x).
\]

### 3.1 Fixed presentation partitions

Requiring a fixed partition to respect every elementary reset and the primitive dynamics leaves only:

- the constant quotient;
- the full-state quotient.

No single fixed-location bit quotient is closed under the update. The supplied causal structure nevertheless has the three independent moving event threads established in v0.2/v0.3.

Therefore “choose a fixed autonomous presentation quotient” is too restrictive to recover those transported computational roles at the primitive grain.

### 3.2 Time-dependent presentations repair that restriction

For an initial lane index `i`, its value occupies site `(i−t) mod 3` at time `t`. Define

\[
\pi_t^J(s)=\big(s_{(i-t)\bmod3}\big)_{i\in J},
\]

for any nonempty set `J` of the three initial lanes. Then

\[
\pi_{t+1}^J(F(s))=\pi_t^J(s).
\]

All seven nonempty lane subsets yield transport-covariant presentation candidates. Individual lanes and joint lane collections are all mathematically well-defined.

The event graph canonically gives three computational threads; the observation construction gives seven alternative nonempty lane-subset readouts. These are different objects. Neither number is thereby an observer count.

One could select minimal nonempty presentations, maximal presentation, or another level of organization. The algebra does not establish which selection corresponds to experiential unity.

### 3.3 Sampling remains substantive

At stride three, `F³=id`. Relative to that endpoint protocol, all eight coordinate-subset partitions are stable, rather than only two. Retaining micro-path provenance repairs lineage loss but does not select the phenomenally relevant observation protocol.

### 3.4 Verdict

Option 1 derives candidate structures and traversal relations in this case. It fails at the step from **structurally admissible distinction** to **intrinsically presented distinction and contribution unit**.

No contradiction in the candidate structures has been found. No phenomenal selector has been derived.

## 4. Option 1 on the shared-control case

Use

\[
F(x,y,c)=(x\oplus c,y\oplus c,c).
\]

With the full reset algebra and closed-system dynamics, the stable coordinate supports are exactly

\[
\varnothing,\quad\{c\},\quad\{x,c\},\quad\{y,c\},\quad\{x,y,c\}.
\]

The unique smallest nonconstant stable presentation is the controller `c`; the finest is the whole state. The two intermediate presentations share the controller.

Both minimality and maximality can be imposed without a fitted coefficient. Neither is thereby established as the principle of experience.

If `c` is instead supplied as an external input, the remaining two-bit conditional system admits the independent `x` and `y` projections. This recovers their operational separability, but relies on the interface choice v0.3 showed to be underdetermined by causal adequacy.

### Verdict

The shared controller is identifiable as a structural role. Its enabling versus constitutive status, and the corresponding experienced presentation units, remain undetermined by this attempt.

The four finest source-autonomous interface annotations from WP2 remain admissible. Their computational block-count identification set is `{1,2}`. This is not an identification set for the number of subjects.

## 5. Option 2 attempt: begin with actual appearing

### 5.1 What is secured

Take the starting datum:

> An occurrence of appearing is actual.

For that occurrence, appearing and its actuality are not two events requiring a further act to connect them. Denial performed as an experience would not eliminate the occurrence.

This is an epistemic/constitutive starting point. It is not yet an explanation of why appearing exists or why its determinations must be as they are.

The datum is **not exempted** from the final demand for explanation. “Not yet explained” is not a proof that it is ultimately brute; equally, calling it undeniable does not explain it.

### 5.2 The necessity transition fails without another premise

Let `E` mean “there is appearing” and `D` mean “an attempted experiential denial occurs.” Consider the inference

\[
E,\qquad\Box(D\to E)
\quad\therefore\quad\Box E.
\]

It is invalid in ordinary normal modal semantics, including a simple S5 frame.

A two-world countermodel has appearing and attempted denial at the designated actual world; the other world has neither. Every world satisfies `D→E`, while the designated world does not satisfy `□E`.

Another model with the same actual facts and appearing at both worlds satisfies `□E`. Thus the stated premises do not decide necessity or nonnecessity.

**Scope warning:** these are logical countermodels to one inference. They are not established metaphysically possible total realities, do not purport to satisfy the zero-residue criterion, and do not refute a richer argument for necessary appearing.

What they establish is the missing step: performative undeniability alone does not supply ontological necessity. The requirement that a complete explanation exist is not itself a construction of that explanation.

### 5.3 Actual history does not select the organization

A finite appearing history can be matched by different causal update rules that diverge under unexperienced interventions. The executable example compares a responsive controlled bit with a forced toggler; their actual all-ones input history agrees, but a zero input distinguishes them.

This is not a general impossibility theorem about deriving organization from all possible first-person evidence. It shows why merely restating an actual trace does not determine counterfactual organization.

### 5.4 Even complete local operational evidence does not settle global multiplicity

Strengthen the datum to every permitted history of a selected local presentation. The padding result still permits a product extension containing hidden dynamics or additional candidate executions while preserving all those local histories.

For every finite `N≥1`, the `N`-copy construction observed through its first component has the same local behavior type.

If the base process is independently established to realize a subject and the copies meet the charter's genuine-duplication condition, the candidate population numbers are unbounded over this model class. No such consciousness premise is inferred from the toy automata. The class is explicitly closed under these hidden finite replications; additional actual global constraints could bound or exclude the extensions, and the construction does not override them.

### 5.5 Explicit organization tests on both decisive cases

**Moving storage:** a phase-indexed readout follows one lane of the rotating register. Its local protocol permits either waiting or writing zero/one to the current lane. A stationary memory bit with the same write protocol has exactly the same complete local behavior. This does not identify their physical storage organization from the selected appearing data. Adding a second whole rotating system behind the first readout is again locally invisible. The lane-following observation and intervention protocol is supplied for this comparison, not derived from appearing.

**Shared control:** take the local readout `x` and allow waiting plus every elementary reset of `x`, `y`, or `c` before the shared update. The full `(x,y,c)` model and a reduced `(x,c)` model have exactly the same local input/output behavior; resetting `y` becomes a no-op in the latter. Here the controller can be locally predictively relevant even though the sibling process remains unobserved. Duplicating the full shared-control model again preserves the first local readout's complete behavior.

In each case the commuting projection establishes equality for all allowed finite input histories, not only the bounded histories checked in the executable suite. The construction tests evidence sufficiency in the specified interface class; it asserts neither that the models are actually conscious nor that their candidate realities satisfy zero-residue closure.

### 5.6 Verdict

Option 2 secures the actuality of the starting occurrence and can constrain organization through additional evidence. It does not, from the tested starting premises, establish:

- its own necessity;
- a unique counterfactual causal organization;
- the total realization population;
- a canonical self-location measure.

The route is not refuted in principle. It has not supplied the requested non-brute closure.

## 6. Option 3: identify the set, do not force a point

For a specified class `K` of models or annotations compatible with the stated constraints, define

\[
\operatorname{Id}_K(Q)=\{Q(k):k\in K\}.
\]

- Empty set: the chosen model class/constraints are inconsistent or empty.
- Singleton: the quantity is point-identified **in that class**.
- Multiple values: it is set-identified but not point-identified.

An identification set is not a probability distribution over candidates. Its cardinality is not an observer count. Uniform weights over annotations would be a new unsupported rule and could depend on how alternatives were represented.

### 6.1 What is identifiable in the two decisive cases?

| Case | Identified under the supplied constraints | Not identified | Correct output |
|---|---|---|---|
| Moving storage | Three wire-linear event threads; their transport; faithful path correspondences | Which readouts constitute experience; whether/how threads form subjects; experiential unit and temporal protocol | Derived structural family plus suspension of subject and weight claims |
| Shared control | Dependency roles; controller identity; conditional factorizations; four finest source-autonomous interface annotations | Whether control is constitutive; which presentation is experienced; subject count | Interface/presentation family, not forced boundary |

### 6.2 The numerical probability limit

Even after supplying one base observer and 99 simulated observers, weights

\[
\mu(b)=q,\qquad\mu(s_i)=\frac{1-q}{99}
\]

satisfy normalization and permutation symmetry among simulated copies for every `q` in the permitted range. With strictly positive weights the resulting simulation probabilities span `(0,1)`; with nonnegative weights they span `[0,1]`.

This is compatibility with those **weak constraints**, not a proof that every such assignment is rationally permissible. Additional independently justified epistemic norms could narrow the set. No particular probability is established here.

Bostrom's ratio remains available conditional on an established realization population and justified weighting/indifference rule. It is not supplied by the current constitutive work.

### 6.3 More evidence could narrow the set

Relative non-identifiability is not a declaration that no further evidence could help.

For example, three individual readout candidates agree on state `000`. If a separately calibrated intervention resets coordinate zero and a known experiential response changes to one, that additional association can identify the first readout within those three candidates.

This would be empirical identification relative to a model and an experiential-intervention association. It would not explain concrete actuality or derive the association's intrinsic necessity.

## 7. Four-plus-one input audit, v0.5

The explicit classification record is `five_input_ledger_v0_5.csv`. The shared ledger adds `input_group_v0_5` and `constitutive_status_v0_5` columns as well as retaining every actuality obligation.

At the level relevant to the zero-residue project, the substantive status of all five inputs is **underdetermined**. This is compatible with clear mathematical roles:

| Input | Known formal role | Why no global classification is earned |
|---|---|---|
| Intervention algebra | Constitutes the chosen counterfactual/causal frame; map names are representational | Not shown to be intrinsically mandatory or to determine phenomenal organization |
| Target/observation | Defines preserved distinctions; output names may be representational | Stable structural distinctions have not been shown to be intrinsically experienced |
| Ports | Can specify enabling conditions relative to a role | Constitutive versus enabling status is not selected by adequacy alone |
| Event grain | Determines occurrence distinctions and path provenance | Some contractions preserve organization; others invent routes or erase multiplicity |
| Temporal protocol | Selects which histories/steps count in equivalence tests | Clock units can be representational, but changing sampling/input protocols changes the candidate spectrum |

No fifth boundary law has been used to declare an answer. Temporal protocol is shown separately as requested, without pretending that listing it separately makes it an explained primitive.

## 8. Ledger changes and scope protections

A39–A46 are added. They record:

- the exact limited scope of v0.4's counting incompatibility;
- stable congruences as candidates rather than phenomenal facts;
- actual appearing as a datum not exempt from explanation;
- the modal countermodel's logical rather than metaphysical status;
- model-relative identification versus in-principle impossibility;
- candidate families as neither populations nor probability distributions;
- the possible value and limits of additional experiential calibration;
- acceptance of principled suspension as a successful outcome under the charter.

The shared record has 46 entries. These are assumptions, conditions, results and non-inference guardrails—not 46 claimed fundamental ingredients of reality. Earlier ZIP bundles remain unchanged snapshots.

The two maps remain distinct:

\[
q:S_{\mathrm{implementation}}\longrightarrow S_{\mathrm{minimal\ predictive\ model}},
\qquad
\tau:\Omega_{\mathrm{actual\ realizations}}\longrightarrow\mathcal T_{\mathrm{organizational\ types}}.
\]

`q` is precise relative to its supplied interface/protocol. Neither the actual realization domain `Omega` nor its occurrence-to-type map `tau` has been derived. Product state spaces and quotient fibers in the code do not supply them.

## 9. Acceptance verdict and project decision

### Option 1

The tested algebraic route derives a structural presentation spectrum. It has not derived intrinsic presentedness, a unique constitutive selection, or its own actuality.

### Option 2

The tested actuality-first route starts without a separate actualization bridge for the given appearance. It has not derived the datum's necessity or unique global organization/population.

### Option 3

Set-identification and suspension are justified relative to the explicit available constraints. The output contains precise structural facts, admissible families and unresolved claims. It does not conceal a probability assignment or multiply observers by counting descriptions.

**Free-parameter milestone:** no parameter-free constitutive completion has been obtained by the tested routes. Option 3 adds no selector, threshold or prior to force a point: it returns the full identification sets under the stated model class and constraints. This does not derive that model class or eliminate any of the five substantive inputs.

**WP4 recommendation: accept this as a principled suspension result, not as construction of the final unified principle.** No proof has been given that zero-residue completion is impossible or that the uniqueness hunch is false. Neither has been established by the work so far.

The present formal route should not be extended by another unexplained optimizer merely to produce a point answer. Reopening the constitutive derivation requires new, independently defended content: a principle connecting actuality and intrinsic presentation that demonstrably excludes the alternatives, or additional calibrated evidence whose limited role is recorded.

The supported Bostromian remainder is conditional: once the actual relevant realizations and a justified weighting rule are supplied, the appropriate ratio follows. Neither the population nor the rule has been derived from a complete metaphysics here.

## 10. Reproducibility

New files:

- `presentation_identifiability.py` — stable partition enumeration, transported readouts, modal entailment checks and identification-set bookkeeping;
- `test_presentation_identifiability.py` — 24 tests;
- `presentation_test_results.txt` — recorded new-suite run;
- `five_input_ledger_v0_5.csv` — explicit four-plus-one classification;
- `wp4_option_results.csv` — attempt-level decisions and scope;
- `wp4_cross_role_dependencies_v0_5.csv` — binding cross-role dependency record for every WP4 deliverable;
- `combined_test_results_v0_5.txt` — complete regression run;
- `assumptions_ledger.csv` — shared record with new classification columns.

Run all suites:

```bash
cd realization_tokens
python -m unittest -v \
  test_realization_tokens.py \
  test_intervention_selection.py \
  test_interface_derivation.py \
  test_operational_equivalence.py \
  test_presentation_identifiability.py
```

These checks establish finite facts and consistency/entailment examples at the stated scope. They are not an empirical test of which models are conscious and not a proof that abstract models are concretely actual.


## 11. Shared cross-role dependencies

No module treats its inputs as clean or independent. These are conceptual responsibilities within this execution, not reports or endorsements from external collaborators.

- **Formal epistemology:** supplies the distinction between state quotient `q` and occurrence-to-type map `tau`, the exact counting-incompatibility scope, and the limits on moving from set-identification to probability or rational permission. It borrows the executable case models, the physical interface/protocol audit, and the lead's constitutive and actuality criteria.
- **Computation:** supplies the partition enumeration, traversal models, case-specific commuting projections and padding generalization. It borrows the formal limits on interpreting quotients, the physical account of supplied transformations/protocols, and the lead's distinction between computational adequacy and experience.
- **Physics/credence stress test:** supplies scrutiny of observation, intervention, description, interface and sampling choices. It borrows the formal q/tau and measure distinctions, the computational counterexamples, and the lead's requirement not to exempt actuality or appearing as brute.
- **Project lead / constitutive criterion:** supplies the non-brute actuality obligation and the acceptance of principled suspension without forcing uniqueness. This assessment borrows the formal non-entailment limits, computational candidate families and projections, and the physical protocol-dependence audit. It does not replace them with a unified label.

Every new or revised WP4 deliverable has an entry in `wp4_cross_role_dependencies_v0_5.csv`. The source/test docstrings and result headers record these dependencies; each CSV assessment and shared-ledger row carries the four role-dependency fields. The ZIP includes this audit as part of the delivery rather than treating the reports as independent modules.
