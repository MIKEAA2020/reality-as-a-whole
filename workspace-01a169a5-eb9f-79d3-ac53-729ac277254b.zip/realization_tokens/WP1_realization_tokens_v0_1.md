# Work Package 1 — Realization tokens, v0.1

## A frame-relative equivalence of anchored computational role-segments

**Status:** first formal construction and adversarial test report. This is not a theory of consciousness, a subject counter, a probability rule, or a zero-residue metaphysics. It is a conditional account of when specified implementation descriptions represent the same anchored informational-dynamical role over a specified segment.

**Result:** a candidate equivalence relation `R0`, six elementary propositions, an executable finite-model checker, 32 passing toy-model tests, and an explicit assumptions ledger. The general milestone remains open because target-event carriers, counterfactual structure, and temporal grain are not yet intrinsically derived.

**Unit throughout:** a finite computational **role-segment** at a declared grain. Do not substitute “subject,” “life,” “experience,” or “observer-moment” for this unit without another argument.

---

## 1. Executive findings

1. Abstract computation type and actual state trajectory do not determine numerical execution multiplicity.
2. A conditional, description-invariant quotient is available if concrete event occurrences, target carriers, a counterfactual domain, and a logical grain are supplied.
3. Nested implementation descriptions can be flattened without creating extra role tokens. A genuinely additional internal process is not the same thing as another factorization of the first process's implementation map.
4. Symmetric copies must not be identified merely because their process graphs are isomorphic. Passive relabelling transports the entire comparison; it does not replace one occurrence with another.
5. Identity of descriptions cannot also encode unrestricted branching continuity. Fission and merger require a separate continuation relation.
6. Neither the number of equivalence classes of all possible role descriptions nor the number of concrete update events is thereby an observer count.
7. The choice of counterfactual domain can change whether two projections express the same role. Dynamics alone can also leave subsystem factorization noncanonical.
8. No epistemic measure is produced by this work. The finite noncontextuality lemma remains conditional on a separately justified interpretation and norm.

These results are compatible with the project's priority ordering: explanatory closure first; Bostromian continuity only where justified. They do not privilege computationalism as the final metaphysics.

## 2. Formal domain

### 2.1 Concrete frame

Work relative to a finite frame

\[
\mathcal F=(S,F,D,V),
\]

where:

- `S` is a finite, nonempty concrete state space;
- `F:S→S` is a total deterministic transition;
- `D⊆S` is a nonempty declared counterfactual domain;
- `V` is a set of concrete occurrence-event nodes.

The numerical plurality of events is supplied, not derived. Their written identifiers are representational names, not proposed metaphysical serial numbers. A passive renaming cannot create or destroy nodes.

A supplied witness anchors update blocks to events in `V`. The checker tests event membership and nonreuse, but does **not** discover causal carriers, prove their minimality, or establish event-to-state causal incidence from raw hardware. Correct anchoring is an explicit premise.

The frame does not already contain execution-token or subject IDs. Nevertheless, beginning with concrete event occurrences is a substantial ontological assumption that the actuality account must eventually discharge.

### 2.2 Implementation description

An adequate description is

\[
d=(\alpha,h,k,\pi),
\]

in a fixed frame, where:

- `α=(B₀,…,Bₙ₋₁)` is an ordered sequence of nonempty, pairwise disjoint sets of target-event occurrences;
- `h=(s₀,…,sₙ)` is the actual concrete path at logical cuts;
- `k>0` is a declared sampling stride;
- `π:D→P` maps concrete states to abstract states, with `P=π(D)`.

Required finite adequacy conditions:

1. `Fᵏ(D)⊆D`.
2. `sᵢ∈D` and `sᵢ₊₁=Fᵏ(sᵢ)`.
3. There is a deterministic quotient transition `Q:P→P` satisfying

\[
\pi\circ F^k=Q\circ\pi\quad\text{on }D.
\]

Condition 3 is checked on the declared counterfactual domain, not only on the actual path. Equivalently,

\[
\pi(s)=\pi(t)\Rightarrow\pi(F^k(s))=\pi(F^k(t)).
\]

This is a candidate computational adequacy requirement. It is not a sufficient condition for consciousness. Many trivial and nonexperiential quotients satisfy it.

### 2.3 Certified inert scheduling

A description may include an explicitly certified scheduling block in which no target update occurs. Such a block is omitted from `α` and does not add an active cut to `h`.

**Equal consecutive state values do not certify inactivity.** A genuine update can leave the logical state unchanged. The checker preserves such active self-loops.

No claim follows about whether a paused system experiences anything, how long an experience lasts, or how pauses contribute to epistemic measure. A pause-only interval is outside this model.

## 3. Candidate relation R0

### 3.1 Remove abstract state names, not concrete multiplicity

Define the decoder kernel

\[
K_\pi=\{(s,t)\in D^2:\pi(s)=\pi(t)\}.
\]

This records the informational partition induced by `π`, without retaining arbitrary abstract-state labels.

Define the normal form

\[
N_{\mathcal F}(d)=(\alpha,h,k,K_\pi).
\]

Then

\[
d\;R_0^{\mathcal F}\;d'\quad\Longleftrightarrow\quad
N_{\mathcal F}(d)=N_{\mathcal F}(d').
\]

`R0` is defined only within one fixed concrete frame and declared grain. Cross-frame numerical identity is not silently supplied.

### 3.2 Meaning and limits

`R0` certifies sameness of an anchored informational-dynamical role-segment. It identifies state-label changes, redundant injective encodings, and implementation factorizations that flatten to the same normal form.

It does not identify every adequate coarse-graining of a carrier with every other coarse-graining. Different decoder kernels can describe different informational roles on the same events. Whether those roles belong to one subject, several subjects, or no subject is open.

**Failure of R0 is not automatically evidence of two observers.** The operational report distinguishes:

- `SAME_ROLE_SEGMENT`: equal normal forms;
- `DISTINCT_SEGMENTS`: nonempty, disjoint concrete event supports;
- `OPEN`: overlapping or otherwise nonidentical descriptions whose subject-level interpretation is not determined.

Even `DISTINCT_SEGMENTS` is not a subject-count result: two successive segments could belong to one continuing subject.

The quotient of *all possible segment descriptions* is not a canonical partition of reality. An execution admits many overlapping windows and adequate roles. Counting all resulting equivalence classes would be unjustified.

## 4. Propositions and proofs

### P1. Abstract-trajectory insufficiency

**Claim.** If redescription does not create another realization while genuine duplicate executions do, abstract computational trajectory alone cannot determine token identity.

**Proof.** Let two descriptions refer to one execution. Their abstract trajectory is `τ`, and the required token verdict is sameness. Let another pair describe two distinct executions of `τ`. Its trajectory inputs are again `(τ,τ)`, but the required verdict is distinctness. A relation determined only by those trajectory inputs cannot return both verdicts. Therefore the trajectory does not suffice. ∎

This excludes abstract-type-only individuation, not computational realization theories generally. It assumes the stipulated duplication and redescription judgments.

### P2. R0 is an equivalence relation

On the adequate descriptions of a fixed frame, `R0` is reflexive, symmetric, and transitive because it is equality of normal forms. ∎

The nontrivial interpretive issue is whether the normal form captures the intended realization role—not whether equality is an equivalence relation.

### P3. State-name invariance

**Claim.** For decoders with the same domain, `Kπ=Kπ′` iff a bijection `β:π(D)→π′(D)` exists with `π′=β∘π`.

**Proof.** If kernels agree, set `β(π(s))=π′(s)`. Kernel equality makes this well-defined and injective; using the images as codomains makes it surjective. The converse follows immediately from injectivity. If both decoders are adequate, the induced transitions are conjugate: `Q′β=βQ`. ∎

Thus arbitrary abstract state names and redundant injective output encodings do not manufacture another role. A genuinely lossy abstraction changes the kernel and requires separate treatment.

### P4. Implementation composition does not multiply a target role

Suppose

\[
\pi F^m=G\pi,
\qquad
\theta G^n=Q\theta.
\]

Then

\[
(\theta\pi)F^{mn}=Q(\theta\pi).
\]

**Proof.** Iterate the first equation `n` times and substitute the second. ∎

If a chained description and a direct description have the same expanded target-event anchor and actual path, they therefore have the same composite decoder kernel and clock, and are `R0`-equivalent.

This is conditional on correct expansion of target support. One must not count every stage in `host→emulator→observer` as another observer. But one also must not collapse an additional, separately anchored process merely because it runs within the same emulator.

### P5. Passive covariance preserves multiplicity

Let `f:S→S′` and `g:V→V′` be bijections. Transport the dynamics, domain, paths, event anchors and decoders together:

\[
F'=fFf^{-1},\qquad \pi'=\pi f^{-1}.
\]

Equality of anchors, paths, strides and kernels is preserved. Hence

\[
dR_0^{\mathcal F}e\iff f_*g_*d\;R_0^{\mathcal F'}\;f_*g_*e.
\]

This is covariance of the complete comparison. It does **not** authorize applying a symmetry to just one occurrence and declaring it identical to another. Symmetric duplicate carriers remain numerically distinct carriers. ∎

### P6. An identity equivalence cannot also encode unrestricted branching continuity

Let a past process `p` have distinct successors `a` and `b`. If an equivalence relation is required to satisfy both `pRa` and `pRb`, transitivity and symmetry imply `aRb`. Therefore it cannot simultaneously identify the past with both successors while retaining their distinctness. Merger gives the dual problem. ∎

This does not settle survival through fission. It shows that realization-description identity and branching continuation must be represented separately, unless some desired identity judgment is revised.

Use a directed continuation relation `C`, and a separate part/overlap relation, rather than forcing all three jobs into `R0`.

## 5. Transformation test suite

The executable suite has **32 tests, all passing**. These check the conditional schema and finite counterexamples. They are not empirical validation, proof of a general consciousness theory, or proof that the declared anchors are intrinsically correct.

| Transformation | v0.1 judgment | Qualification |
|---|---|---|
| Rename abstract states | Same role-segment | Kernel unchanged |
| Redundant injective encoding | Same role-segment | No added concrete execution |
| Copy source description | Same role-segment | No added events |
| Separate synchronized executions | Distinct segments | Separate carriers are supplied and checked conditionally |
| Factor host→emulator→target | Same after verified flattening | Target support must expand correctly |
| Add independently anchored internal process | Distinct segment | Only a candidate subject |
| Relabel all concrete states and events | Verdicts preserved | Complete passive transport |
| Replace one occurrence with its symmetric counterpart | Not the same segment | Do not quotient away multiplicity |
| Reparameterize elapsed-time metadata | Same at this computational grain | No claim about experienced time |
| Insert certified target-inert pause | Same active segment | Inactivity is a premise |
| Insert an active self-loop | Not silently deleted | Equal state values do not imply inactivity |
| Pause-only interval | Outside model | No conclusion about consciousness |
| Sequential replay or repeated window | Distinct segments | Not necessarily distinct subjects or lives |
| Physically separate faster run | Distinct segment | Not merely a time-label change |
| Split | Separate successors plus continuation arrows | No automatic identity-through-fission |
| Merge/reconnect | Continuation/overlap problem | No automatic subject union |
| Coarse/fine view on shared events | Open | Adequate quotients do not select observer grain |
| Change counterfactual domain | Verdict may change | Domain is substantive |
| Decoder fits only actual path | Can be rejected | Must satisfy counterfactual quotient condition |
| Reuse the same event as another update | Invalid certificate | Text cannot manufacture event multiplicity |

See `transformation_suite.csv` for test IDs and assumption dependencies.

## 6. Counterexamples and limits

### 6.1 Graph isomorphism alone merges genuine duplicates

Two disjoint cycles can implement exactly the same transition system and actual trajectory. Isomorphism recognizes shared type, not one numerical occurrence. Taking graph-isomorphism classes as observer tokens would collapse the very duplicates required by the charter.

Remedy in v0.1: retain concrete anchors while enforcing covariance under passive relabelling. Outstanding issue: justify concrete anchoring without unexplained substrate identity.

### 6.2 Overlap is not identity

Take supports `A={a}`, `B={a,b}`, `C={b}`. Then `A` overlaps `B` and `B` overlaps `C`, but `A` does not overlap `C`.

Overlap is not transitive. Taking its equivalence closure can merge a chain of distinct interacting or partially shared processes. Equality, overlap, and continuation must remain distinct relations.

### 6.3 Equal support does not select one informational role

On the same supplied carrier, `πx(x,y)=x`, `πy(x,y)=y`, and `πfull(x,y)=(x,y)` can all be adequate quotients. They do not have the same kernels.

The fine role can contain the information of a coarse role without constituting a second subject. Conversely, several roles on shared resources might belong to distinct subjects. `R0` leaves the subject judgment open.

This is why the number of all `R0` classes is not an observer census.

### 6.4 The counterfactual domain is not cosmetic

Let `F(x,y)=(1−x,1−y)` and actual history alternate between `(0,0)` and `(1,1)`.

On the full domain `{00,01,10,11}`, projections `πx` and `πy` have different kernels. On the diagonal-only domain `{00,11}`, they have the same kernel.

With a shared declared carrier, `R0` consequently treats them differently in the two frames. This does not merge event-disjoint copies: distinct anchors remain distinct. It shows that role identity cannot be read off from the actual path alone.

A necessitarian completion must also explain what these counterfactual states represent. They cannot simply be assumed to be metaphysically possible alternative total realities.

### 6.5 Dynamics alone need not select subsystem factorization

Again let

\[
x'=1-x,\qquad y'=1-y.
\]

Use coordinates `u=x`, `v=x XOR y`. The same dynamics becomes

\[
u'=1-u,\qquad v'=v.
\]

The transition map admits both a description with two changing factors and one with a changing factor plus a conserved factor. No claim about consciousness follows from either representation. But a rule that counts “active component processes” without additional intrinsic structure is not representation-independent.

A specified local intervention family or causal architecture may select a factorization. It then becomes a further assumption to justify, not something the transition map already supplies.

### 6.6 Actual-fit encodings can be spurious

For that same actual diagonal path, `π(x,y)=x AND y` has the same observed output sequence as `πx`. Yet it fails to define a deterministic quotient on the full domain: states assigned the same abstract value can have differently valued successors.

The executable checker rejects it. This illustrates why matching one observed trace is weaker than implementation adequacy.

### 6.7 Grain, duration and continuity remain open

Changing the sampling stride can change the abstract dynamics. Merely dropping intermediate cuts is not automatically an innocent redescription of an experiential process.

Likewise, sequential windows are distinct computational segments without thereby being distinct subjects. A pause can leave one segment's organization intact without settling experience during inactivity. Elapsed-time invariance of this checker is not a law of phenomenal or epistemic measure.

### 6.8 Event anchors are a remaining dependency, not an ultimate solution

The construction assumes distinct concrete event occurrences and correct target support. It does not derive them from abstract computational type. That is intentional and explicitly limited.

Thus v0.1 relocates the hard problem to an identifiable place: intrinsic justification of the concrete carrier, its causal/counterfactual structure, and its grain. It does not discharge that problem by naming the carrier “intrinsic.”

## 7. Epistemic quarantine

This package does not introduce a probability rule.

Even after granting one base observer and 99 simulated observers, the normalized family

\[
\mu(b)=q,\qquad\mu(s_i)=\frac{1-q}{99}
\]

respects permutation symmetry among the simulated copies for every `q∈[0,1]`. Equal per-instance weighting requires additional justification across those groups.

The finite counting lemma remains:

- given distinct compatible realizations;
- given a justified equal positive weight per relevant realization;
- given additivity and normalization;
- a subset of `k` of `N` realizations receives probability `k/N`.

`R0` establishes neither the equal-weight premise nor that its computational roles are the relevant experiential contribution units.

Exact intrinsic duplicates and heterogeneous observers sharing evidence remain separate bridge problems. Principled suspension or nonunique credence is an admissible final finding, not a failure to preserve Bostrom.

## 8. Shared assumptions ledger

The machine-readable record is `assumptions_ledger.csv`.

The main undischarged assumptions are:

- concrete event plurality;
- a finite deterministic state-transition background;
- admissible counterfactual states/interventions;
- correct target-specific causal support;
- logical sampling grain and role boundaries;
- certification of target-inert scheduling;
- the relevance of a role to experiential subjecthood;
- any eventual norm connecting realization identity to epistemic contribution.

The actuality argument must not simply endorse this entire frame after the fact. It must justify, reconstruct, or reject these ingredients. No assumption is protected because it makes the toy tests pass.

## 9. What has been supplied, and what the next milestone is

### Supplied

1. A precise domain of conditional finite implementation descriptions.
2. A clean trajectory-insufficiency proof.
3. An initial role-token equivalence with explicit admissible redescriptions.
4. A composition result handling nested implementation descriptions.
5. A passive/active symmetry distinction that preserves multiplicity.
6. A branching-continuity obstruction requiring relations other than identity.
7. An executable transformation suite and counterexample report.
8. A shared assumptions ledger.

### Not supplied

- an intrinsically privileged causal carrier;
- a unique decomposition into perspectives;
- a canonical temporal or experiential contribution unit;
- a constitutive identity between computational role and experience;
- a self-location norm;
- a derivation of concrete actuality or its necessity.

### Next concrete research target

Construct or refute a **carrier-and-grain selection principle** on an intervention-structured occurrence model that:

1. is covariant under passive representation changes;
2. preserves genuinely separate realizations;
3. does not count every adequate coarse-graining as another subject;
4. handles shared hardware, multiplexing and distributed realization;
5. gives a principled answer—or a principled nonuniqueness result—for split, merge and temporal grain;
6. does not introduce an arbitrary integration threshold or privileged coordinate system.

A principle that requires an additional intervention structure can still be useful, but that structure must enter the ledger and the actuality audit.

**Acceptance judgment:** this is a usable first pass at WP1, not completion of the general milestone. Its main positive result is a conditional quotient; its main negative result is a precise account of why equivalence, continuation, causal anchoring, and contribution measure cannot be silently identified.

## 10. Reproducibility

Files:

- `realization_tokens.py` — finite frame, implementation adequacy, kernel normal form, `R0`, limited verdicts and passive transport.
- `test_realization_tokens.py` — 32 tests, including deliberately exposed failures of naive criteria.
- `test_results.txt` — recorded successful test run.
- `transformation_suite.csv` — test-case judgments, limits and dependencies.
- `assumptions_ledger.csv` — shared record of supplied assumptions and remaining obligations.

Run with standard-library Python:

```bash
cd realization_tokens
python -m unittest -v test_realization_tokens.py
```

All 32 tests passed in the recorded run. The proofs above, rather than those finite test results, establish the general elementary claims. Neither the tests nor the proofs establish consciousness or zero-residue metaphysical closure.
