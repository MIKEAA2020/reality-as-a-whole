"""WP1 v0.1: conditional equivalence of anchored computational role-segments.

This is a finite-model certificate checker, NOT an observer detector.
It assumes a concrete occurrence frame and certified target-event anchors.
It does not infer consciousness, subject continuity, or epistemic weights.

Run the companion tests with:
    python -m unittest -v test_realization_tokens.py
"""
from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from itertools import combinations
from typing import Callable, Hashable, Iterable

State = Hashable
Label = Hashable


class InvalidDescription(ValueError):
    """The supplied finite implementation certificate is not adequate."""


@dataclass(eq=False, frozen=True)
class FiniteFrame:
    """A fixed background of concrete states, dynamics and occurrence events.

    `domain` specifies the counterfactual states against which an abstraction
    is checked. Its choice is a substantive assumption, not an inference.
    Events are occurrence nodes, not program labels or execution-token IDs.
    Their numerical plurality is assumed at this stage.
    """

    name: str
    states: tuple[State, ...]
    step: Callable[[State], State]
    events: frozenset[str]
    domain: tuple[State, ...] | None = None

    def __post_init__(self) -> None:
        if not self.states or len(set(self.states)) != len(self.states):
            raise ValueError("A frame needs a nonempty, duplicate-free state space.")
        if any(self.step(s) not in self.states for s in self.states):
            raise ValueError("The concrete transition must be total on the state space.")
        domain = self.states if self.domain is None else self.domain
        if not domain or len(set(domain)) != len(domain):
            raise ValueError("The counterfactual domain must be nonempty and duplicate-free.")
        if not set(domain).issubset(self.states):
            raise ValueError("The counterfactual domain must lie in the state space.")
        object.__setattr__(self, "domain", tuple(domain))

    def advance(self, state: State, steps: int) -> State:
        if steps < 0:
            raise ValueError("A transition count cannot be negative.")
        for _ in range(steps):
            state = self.step(state)
        return state


@dataclass(frozen=True)
class Block:
    """A declared block of target-relevant update occurrences.

    An inert block is a PRE-CERTIFIED scheduling pause at the selected
    computational grain. Equal consecutive state values do not certify it.
    Elapsed time is metadata, omitted from the computational normal form.
    This makes no assertion about experienced duration or temporal measure.
    """

    events: frozenset[str]
    inert: bool = False
    elapsed: float = 1.0

    def __post_init__(self) -> None:
        if self.elapsed < 0:
            raise ValueError("Elapsed time must be nonnegative.")
        if self.inert and self.events:
            raise ValueError("An inert block cannot contain target update occurrences.")
        if not self.inert and not self.events:
            raise ValueError("An active block needs an occurrence anchor.")


def partition_code(values: Iterable[Label]) -> tuple[int, ...]:
    """Encode a partition independently of its output-state names."""
    names: dict[Label, int] = {}
    result: list[int] = []
    for value in values:
        if value not in names:
            names[value] = len(names)
        result.append(names[value])
    return tuple(result)


@dataclass(frozen=True)
class Description:
    """An implementation description flattened into one concrete frame.

    The contribution unit is a computational ROLE-SEGMENT at a declared grain.
    It is not automatically a subject, life, experience or observer-moment.

    `path` lists concrete states at ACTIVE logical cuts. Certified inert
    scheduling blocks do not add entries. Target event support is supplied
    by the witness; this checker does not discover causal carriers in hardware.
    """

    frame: FiniteFrame
    blocks: tuple[Block, ...]
    path: tuple[State, ...]
    decode: Callable[[State], Label]
    stride: int = 1
    label: str = ""
    derivation: tuple[str, ...] = ()

    @property
    def active_blocks(self) -> tuple[Block, ...]:
        return tuple(block for block in self.blocks if not block.inert)

    @property
    def support(self) -> frozenset[str]:
        return frozenset(event for block in self.active_blocks for event in block.events)

    @property
    def anchor(self) -> tuple[frozenset[str], ...]:
        return tuple(block.events for block in self.active_blocks)

    def validate(self) -> None:
        if self.stride <= 0:
            raise InvalidDescription("The logical sampling stride must be positive.")
        if not self.active_blocks:
            raise InvalidDescription("Pause-only intervals are outside this role-segment model.")
        if not self.support.issubset(self.frame.events):
            raise InvalidDescription("The description cites events outside its frame.")
        anchored_events = [event for block in self.active_blocks for event in block.events]
        if len(anchored_events) != len(set(anchored_events)):
            raise InvalidDescription("One occurrence event cannot be reused as a second update.")
        if len(self.path) != len(self.active_blocks) + 1:
            raise InvalidDescription("The active-cut path has the wrong length.")
        domain = self.frame.domain
        assert domain is not None
        if any(s not in domain for s in self.path):
            raise InvalidDescription("An actual cut lies outside the declared domain.")
        for before, after in zip(self.path, self.path[1:]):
            if self.frame.advance(before, self.stride) != after:
                raise InvalidDescription("The declared path does not obey the sampled dynamics.")

        abstract_next: dict[Label, Label] = {}
        for s in domain:
            t = self.frame.advance(s, self.stride)
            if t not in domain:
                raise InvalidDescription("The counterfactual domain is not sampled-transition closed.")
            current = self.decode(s)
            successor = self.decode(t)
            if current in abstract_next and abstract_next[current] != successor:
                raise InvalidDescription(
                    "The decoder fits no deterministic quotient on the declared domain."
                )
            abstract_next[current] = successor

    def kernel_code(self) -> tuple[int, ...]:
        self.validate()
        assert self.frame.domain is not None
        return partition_code(self.decode(s) for s in self.frame.domain)

    def quotient_code(self) -> tuple[int, ...]:
        """Canonical quotient transition, within this frame's domain enumeration."""
        code = self.kernel_code()
        assert self.frame.domain is not None
        index = dict(zip(self.frame.domain, code))
        transition: dict[int, int] = {}
        for s, block_id in zip(self.frame.domain, code):
            transition[block_id] = index[self.frame.advance(s, self.stride)]
        return tuple(transition[i] for i in range(len(transition)))

    def abstract_trace_code(self) -> tuple[int, ...]:
        code = self.kernel_code()
        assert self.frame.domain is not None
        index = dict(zip(self.frame.domain, code))
        return tuple(index[s] for s in self.path)

    def normal_form(self) -> tuple:
        """Anchored informational-dynamical role, not a consciousness signature."""
        self.validate()
        return (self.anchor, self.path, self.stride, self.kernel_code())


def same_role_segment(a: Description, b: Description) -> bool:
    """R0: equality of normal forms in ONE fixed concrete frame.

    Transporting an entire frame gives covariance, not cross-world numerical
    identity. A permutation of only one anchor is not a passive redescription.
    """
    if a.frame is not b.frame:
        raise ValueError("R0 is frame-relative; cross-frame identity is not defined.")
    return a.normal_form() == b.normal_form()


class Verdict(str, Enum):
    SAME_ROLE_SEGMENT = "same_role_segment"
    DISTINCT_SEGMENTS = "distinct_segments_not_a_subject_count"
    OPEN = "unresolved"


def classify(a: Description, b: Description) -> Verdict:
    if same_role_segment(a, b):
        return Verdict.SAME_ROLE_SEGMENT
    if a.support.isdisjoint(b.support):
        return Verdict.DISTINCT_SEGMENTS
    return Verdict.OPEN


def kernel_refines(a: Description, b: Description) -> bool:
    """Whether a's informational partition is at least as fine as b's."""
    if a.frame is not b.frame:
        raise ValueError("Compare partitions only within a fixed frame.")
    ca, cb = a.kernel_code(), b.kernel_code()
    for i, j in combinations(range(len(ca)), 2):
        if ca[i] == ca[j] and cb[i] != cb[j]:
            return False
    return True


def compose(first: Callable, second: Callable) -> Callable:
    return lambda state: second(first(state))


def transport_frame(
    frame: FiniteFrame,
    state_map: Callable[[State], State],
    event_map: Callable[[str], str],
    *,
    reverse_enumeration: bool = False,
) -> tuple[FiniteFrame, dict[State, State]]:
    """Passive bijective relabelling of a complete frame."""
    mapped = {s: state_map(s) for s in frame.states}
    if len(set(mapped.values())) != len(frame.states):
        raise ValueError("State transport must be bijective.")
    event_images = {event: event_map(event) for event in frame.events}
    if len(set(event_images.values())) != len(frame.events):
        raise ValueError("Event transport must be bijective.")
    inverse = {v: k for k, v in mapped.items()}
    states = tuple(mapped[s] for s in frame.states)
    assert frame.domain is not None
    domain = tuple(mapped[s] for s in frame.domain)
    if reverse_enumeration:
        states, domain = states[::-1], domain[::-1]
    new_frame = FiniteFrame(
        name=f"transport({frame.name})",
        states=states,
        step=lambda s: mapped[frame.step(inverse[s])],
        events=frozenset(event_images.values()),
        domain=domain,
    )
    return new_frame, inverse


def transport_description(
    description: Description,
    target_frame: FiniteFrame,
    state_map: Callable[[State], State],
    inverse: dict[State, State],
    event_map: Callable[[str], str],
) -> Description:
    return Description(
        frame=target_frame,
        blocks=tuple(
            Block(frozenset(event_map(e) for e in block.events), block.inert, block.elapsed)
            for block in description.blocks
        ),
        path=tuple(state_map(s) for s in description.path),
        decode=lambda s: description.decode(inverse[s]),
        stride=description.stride,
        label=f"transport({description.label})",
        derivation=description.derivation,
    )
