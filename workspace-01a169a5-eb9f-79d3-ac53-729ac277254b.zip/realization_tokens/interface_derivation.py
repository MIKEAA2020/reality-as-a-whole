"""WP2 v0.3: admissible interfaces and conservative event traversal.

No criterion of phenomenal constitution or epistemic weight is implemented.
Interface assignments satisfy stated causal constraints; admitting a family
is not treating every annotation as a simultaneously actual observer.
"""
from __future__ import annotations

from dataclasses import dataclass
from itertools import combinations
from typing import Callable, Iterable

from intervention_selection import BitNetwork


@dataclass(frozen=True)
class InterfaceAssignment:
    ports: frozenset[int]
    blocks: frozenset[frozenset[int]]


def all_subsets(indices: Iterable[int]):
    indices = tuple(sorted(indices))
    for size in range(len(indices) + 1):
        for values in combinations(indices, size):
            yield frozenset(values)


def conditional_components(network: BitNetwork, ports: frozenset[int]):
    """Finest product blocks of internal updates, relative to declared ports.

    For a full product with exact intervention dependence, these are the weak
    components of the induced internal dependency graph. This is not a
    subject partition and says nothing about whether the port set is correct.
    """
    internal = set(range(network.n)) - set(ports)
    adjacency = {i: set() for i in internal}
    for a, b in network.dependency_edges():
        if a in internal and b in internal:
            adjacency[a].add(b)
            adjacency[b].add(a)
    remaining = set(internal)
    components = set()
    while remaining:
        start = next(iter(remaining))
        frontier, component = [start], {start}
        while frontier:
            a = frontier.pop()
            for b in adjacency[a]:
                if b not in component:
                    component.add(b)
                    frontier.append(b)
        remaining.difference_update(component)
        components.add(frozenset(component))
    return frozenset(components)


def admissible_interfaces(
    network: BitNetwork, *, autonomous_ports: bool = True
) -> frozenset[InterfaceAssignment]:
    """Enumerate all proper port sets and their finest conditional blocks.

    Optional source autonomy is an extra restriction, made explicit. The
    no-port assignment is permitted and has a substantive interpretation.
    """
    result = set()
    indices = frozenset(range(network.n))
    for ports in all_subsets(indices):
        if ports == indices:
            continue  # Require at least one internal coordinate.
        if autonomous_ports and not network.autonomous(ports):
            continue
        blocks = conditional_components(network, ports)
        if all(network.autonomous(block, ports=ports) for block in blocks):
            result.add(InterfaceAssignment(ports, blocks))
    return frozenset(result)


def minimal_externalization(assignments: Iterable[InterfaceAssignment]):
    assignments = frozenset(assignments)
    size = min(len(a.ports) for a in assignments)
    return frozenset(a for a in assignments if len(a.ports) == size)


def maximal_internal_factorization(assignments: Iterable[InterfaceAssignment]):
    assignments = frozenset(assignments)
    size = max(len(a.blocks) for a in assignments)
    return frozenset(a for a in assignments if len(a.blocks) == size)


def transport_network(network: BitNetwork, coordinate_permutation: tuple[int, ...]):
    """Passive relabelling: old coordinate i becomes coordinate p[i]."""
    n = network.n
    if set(coordinate_permutation) != set(range(n)):
        raise ValueError("Not a coordinate permutation.")
    def move(state):
        output = [0] * n
        for old, new in enumerate(coordinate_permutation):
            output[new] = state[old]
        return tuple(output)
    def inverse(state):
        return tuple(state[coordinate_permutation[old]] for old in range(n))
    return BitNetwork.from_function(n, lambda s: move(network.step(inverse(s))))


def transport_assignment(assignment: InterfaceAssignment, permutation: tuple[int, ...]):
    return InterfaceAssignment(
        frozenset(permutation[i] for i in assignment.ports),
        frozenset(frozenset(permutation[i] for i in block) for block in assignment.blocks),
    )


class NonlinearTraversal(ValueError):
    pass


@dataclass(frozen=True)
class EventGraph:
    """A finite DAG of supplied event occurrences.

    Edge semantics, event grain and intervention adequacy are background
    inputs. Graph subdivisions preserve thread organization only; they do
    not prove numerical identity across actual physical modifications.
    """
    nodes: frozenset[str]
    edges: frozenset[tuple[str, str]]

    def __post_init__(self):
        if not self.nodes:
            raise ValueError("Need at least one event.")
        if any(a not in self.nodes or b not in self.nodes for a, b in self.edges):
            raise ValueError("Edges must refer to supplied nodes.")
        indegree = {v: len(self.predecessors(v)) for v in self.nodes}
        queue = [v for v, degree in indegree.items() if degree == 0]
        visited = 0
        while queue:
            v = queue.pop()
            visited += 1
            for w in self.successors(v):
                indegree[w] -= 1
                if indegree[w] == 0:
                    queue.append(w)
        if visited != len(self.nodes):
            raise ValueError("The event graph must be acyclic.")

    def predecessors(self, v: str):
        return frozenset(a for a, b in self.edges if b == v)

    def successors(self, v: str):
        return frozenset(b for a, b in self.edges if a == v)

    def weak_components(self):
        remaining = set(self.nodes)
        components = set()
        while remaining:
            start = next(iter(remaining))
            frontier, component = [start], {start}
            while frontier:
                v = frontier.pop()
                for w in self.predecessors(v) | self.successors(v):
                    if w not in component:
                        component.add(w)
                        frontier.append(w)
            remaining.difference_update(component)
            components.add(frozenset(component))
        return frozenset(components)

    def wire_linear(self):
        return all(len(self.predecessors(v)) <= 1 and len(self.successors(v)) <= 1 for v in self.nodes)

    def threads(self):
        """Unique path-components on the restricted wire-linear class.

        Outside that class return no forced partition: branching and merging
        need explicit relations, not an arbitrary path-selection rule.
        """
        if not self.wire_linear():
            raise NonlinearTraversal("Branching/merging graph: no wire-thread partition certified.")
        return self.weak_components()

    def maximal_paths(self):
        paths = set()
        def walk(prefix):
            following = self.successors(prefix[-1])
            if not following:
                paths.add(tuple(prefix))
            else:
                for v in following:
                    walk(prefix + [v])
        for source in self.nodes:
            if not self.predecessors(source):
                walk([source])
        return frozenset(paths)

    def renamed(self, mapping: Callable[[str], str]):
        images = {v: mapping(v) for v in self.nodes}
        if len(set(images.values())) != len(self.nodes):
            raise ValueError("Passive renaming must be bijective.")
        return EventGraph(
            frozenset(images.values()),
            frozenset((images[a], images[b]) for a, b in self.edges),
        )

    def subdivide(self, edge: tuple[str, str], middle: str):
        if edge not in self.edges or middle in self.nodes:
            raise ValueError("Need an existing edge and a fresh intermediate node.")
        a, b = edge
        return EventGraph(
            self.nodes | {middle},
            (self.edges - {edge}) | {(a, middle), (middle, b)},
        )

    def quotient(self, projection: Callable[[str], str]):
        nodes = frozenset(projection(v) for v in self.nodes)
        edges = frozenset(
            (projection(a), projection(b))
            for a, b in self.edges if projection(a) != projection(b)
        )
        return EventGraph(nodes, edges)


def path_image(path: tuple[str, ...], projection: Callable[[str], str]):
    result = []
    for v in path:
        image = projection(v)
        if not result or result[-1] != image:
            result.append(image)
    return tuple(result)


def path_lifting_audit(graph: EventGraph, projection: Callable[[str], str]):
    """Compare quotient paths against images of genuine concrete paths."""
    coarse = graph.quotient(projection)
    genuine_images = frozenset(path_image(path, projection) for path in graph.maximal_paths())
    coarse_paths = coarse.maximal_paths()
    return {
        "coarse_graph": coarse,
        "genuine_images": genuine_images,
        "coarse_paths": coarse_paths,
        "unliftable_paths": coarse_paths - genuine_images,
        "bijective_on_maximal_paths": (
            coarse_paths == genuine_images
            and len(graph.maximal_paths()) == len(genuine_images)
        ),
    }
