"""WP2 v0.3: interface non-entailment and event-traversal checks.

Passing tests establish the reported finite facts, not subjecthood or a
unique metaphysical boundary. The same causal model admits multiple
annotations under the explicitly stated adequacy constraints.
"""
from itertools import permutations, product
import unittest

from intervention_selection import BitNetwork
from interface_derivation import (
    EventGraph,
    InterfaceAssignment,
    NonlinearTraversal,
    admissible_interfaces,
    all_subsets,
    conditional_components,
    maximal_internal_factorization,
    minimal_externalization,
    path_image,
    path_lifting_audit,
    transport_assignment,
    transport_network,
)


def set_partitions(items):
    items = tuple(sorted(items))
    if not items:
        return {frozenset()}
    first, rest = items[0], items[1:]
    output = set()
    for partition in set_partitions(rest):
        output.add(partition | {frozenset({first})})
        for block in partition:
            output.add((partition - {block}) | {block | {first}})
    return output


def two_wires():
    return EventGraph(
        frozenset({"a0", "a1", "a2", "b0", "b1", "b2"}),
        frozenset({("a0", "a1"), ("a1", "a2"), ("b0", "b1"), ("b1", "b2")}),
    )


class InterfaceDerivationTests(unittest.TestCase):
    def setUp(self):
        self.controlled = BitNetwork.from_function(3, lambda s: (s[0] ^ s[2], s[1] ^ s[2], s[2]))
        self.whole = InterfaceAssignment(frozenset(), frozenset({frozenset({0, 1, 2})}))
        self.separate = InterfaceAssignment(frozenset({2}), frozenset({frozenset({0}), frozenset({1})}))

    def test_01_shared_control_has_four_source_autonomous_finest_annotations(self):
        assignments = admissible_interfaces(self.controlled)
        self.assertEqual(len(assignments), 4)
        self.assertEqual({a.ports for a in assignments}, {
            frozenset(), frozenset({2}), frozenset({0, 2}), frozenset({1, 2})
        })

    def test_02_constituent_and_interface_readings_share_same_causal_reduct(self):
        assignments = admissible_interfaces(self.controlled)
        self.assertIn(self.whole, assignments)
        self.assertIn(self.separate, assignments)
        self.assertNotEqual(2 in self.whole.ports, 2 in self.separate.ports)

    def test_03_including_coarser_blocks_gives_five_source_autonomous_annotations(self):
        annotations = set()
        for ports in all_subsets(range(3)):
            internal = frozenset(range(3)) - ports
            if not internal or not self.controlled.autonomous(ports):
                continue
            for blocks in set_partitions(internal):
                if all(self.controlled.autonomous(block, ports=ports) for block in blocks):
                    annotations.add(InterfaceAssignment(ports, blocks))
        self.assertEqual(len(annotations), 5)

    def test_04_source_autonomy_is_an_extra_restriction(self):
        self.assertEqual(len(admissible_interfaces(self.controlled, autonomous_ports=False)), 7)
        self.assertEqual(len(admissible_interfaces(self.controlled, autonomous_ports=True)), 4)

    def test_05_c_is_structurally_distinguishable_without_being_declared_external(self):
        edges = self.controlled.dependency_edges()
        roots = {
            j for j in range(3)
            if not any(i != j and target == j for i, target in edges)
        }
        self.assertEqual(roots, {2})
        self.assertIn(self.whole, admissible_interfaces(self.controlled))

    def test_06_two_parameter_free_structural_objectives_disagree(self):
        assignments = admissible_interfaces(self.controlled)
        self.assertEqual(minimal_externalization(assignments), frozenset({self.whole}))
        self.assertEqual(maximal_internal_factorization(assignments), frozenset({self.separate}))

    def test_07_family_and_objectives_are_covariant_under_coordinate_renaming(self):
        base = admissible_interfaces(self.controlled)
        for permutation in permutations(range(3)):
            moved = admissible_interfaces(transport_network(self.controlled, permutation))
            self.assertEqual(moved, frozenset(transport_assignment(a, permutation) for a in base))
            self.assertEqual(
                minimal_externalization(moved),
                frozenset(transport_assignment(a, permutation) for a in minimal_externalization(base)),
            )
            self.assertEqual(
                maximal_internal_factorization(moved),
                frozenset(transport_assignment(a, permutation) for a in maximal_internal_factorization(base)),
            )

    def test_08_factor_counts_are_not_observer_counts(self):
        counts = {len(a.blocks) for a in admissible_interfaces(self.controlled)}
        self.assertEqual(counts, {1, 2})
        # Both are admissible annotations, not simultaneous sets of subjects.

    def test_09_two_block_requirement_selects_c_but_adds_a_requirement(self):
        candidates = {a for a in admissible_interfaces(self.controlled) if len(a.blocks) >= 2}
        self.assertEqual(candidates, {self.separate})

    def test_10_finest_conditional_partition_theorem_exhaustive_two_bit_check(self):
        states = tuple(product((0, 1), repeat=2))
        checked = 0
        for outputs in product(states, repeat=4):
            network = BitNetwork(2, outputs)
            for ports in (frozenset(), frozenset({0}), frozenset({1})):
                internal = frozenset(range(2)) - ports
                finest = conditional_components(network, ports)
                self.assertTrue(all(network.autonomous(block, ports=ports) for block in finest))
                for candidate in set_partitions(internal):
                    if all(network.autonomous(block, ports=ports) for block in candidate):
                        self.assertTrue(all(any(block.issubset(bigger) for bigger in candidate) for block in finest))
                checked += 1
        self.assertEqual(checked, 768)

    def test_11_actual_constant_control_does_not_remove_counterfactual_dependence(self):
        self.assertIn((2, 0), self.controlled.dependency_edges())
        self.assertIn((2, 1), self.controlled.dependency_edges())
        start = (0, 0, 1)
        following = self.controlled.step(start)
        self.assertEqual(following, (1, 1, 1))

    def test_12_dependency_graph_does_not_replace_gate_semantics(self):
        xor = BitNetwork.from_function(2, lambda s: (s[0] ^ s[1], s[1]))
        conjunction = BitNetwork.from_function(2, lambda s: (s[0] & s[1], s[1]))
        self.assertEqual(xor.dependency_edges(), conjunction.dependency_edges())
        self.assertNotEqual(xor.table, conjunction.table)

    def test_13_wire_linear_event_graph_has_canonical_thread_family(self):
        graph = two_wires()
        self.assertTrue(graph.wire_linear())
        self.assertEqual(graph.threads(), frozenset({frozenset({"a0", "a1", "a2"}), frozenset({"b0", "b1", "b2"})}))

    def test_14_thread_family_is_covariant_under_passive_event_renaming(self):
        graph = two_wires()
        rename = lambda v: "renamed:" + v
        moved = graph.renamed(rename)
        self.assertEqual(moved.threads(), frozenset(frozenset(rename(v) for v in thread) for thread in graph.threads()))

    def test_15_thread_organization_survives_unary_edge_subdivision(self):
        graph = two_wires()
        expanded = graph.subdivide(("a0", "a1"), "a0.5")
        self.assertEqual(len(graph.threads()), len(expanded.threads()))
        projection = lambda v: "a0" if v == "a0.5" else v
        audit = path_lifting_audit(expanded, projection)
        self.assertTrue(audit["bijective_on_maximal_paths"])

    def test_16_permutation_process_threads_move_through_storage_sites(self):
        ring = BitNetwork.from_function(3, lambda s: (s[1], s[2], s[0]))
        nodes = frozenset(f"{site}:{t}" for site in range(3) for t in range(7))
        edges = frozenset(
            (f"{source}:{t}", f"{destination}:{t+1}")
            for t in range(6) for source, destination in ring.dependency_edges()
        )
        graph = EventGraph(nodes, edges)
        self.assertEqual(len(graph.threads()), 3)
        for thread in graph.threads():
            self.assertEqual({int(v.split(':')[0]) for v in thread}, {0, 1, 2})

    def test_17_fork_is_not_forced_into_a_thread_partition(self):
        graph = EventGraph(frozenset({"p", "a", "b"}), frozenset({("p", "a"), ("p", "b")}))
        with self.assertRaises(NonlinearTraversal):
            graph.threads()
        self.assertEqual(graph.maximal_paths(), frozenset({("p", "a"), ("p", "b")}))
        self.assertEqual(set.intersection(*(set(p) for p in graph.maximal_paths())), {"p"})

    def test_18_merge_paths_overlap_the_output_occurrence(self):
        graph = EventGraph(frozenset({"a", "b", "q"}), frozenset({("a", "q"), ("b", "q")}))
        with self.assertRaises(NonlinearTraversal):
            graph.threads()
        self.assertEqual(set.intersection(*(set(p) for p in graph.maximal_paths())), {"q"})

    def test_19_diamond_path_count_duplicates_shared_occurrences(self):
        graph = EventGraph(
            frozenset({"p", "a", "b", "q"}),
            frozenset({("p", "a"), ("p", "b"), ("a", "q"), ("b", "q")}),
        )
        paths = graph.maximal_paths()
        self.assertEqual(len(paths), 2)
        self.assertEqual(sum(len(path) for path in paths), 6)
        self.assertEqual(len(graph.nodes), 4)

    def test_20_unlabelled_two_in_two_out_junction_has_no_fixed_routing_pairing(self):
        pairings = {
            frozenset({("a", "c"), ("b", "d")}),
            frozenset({("a", "d"), ("b", "c")}),
        }
        swap = {"a": "a", "b": "b", "c": "d", "d": "c"}
        for pairing in pairings:
            moved = frozenset((swap[a], swap[b]) for a, b in pairing)
            self.assertIn(moved, pairings)
            self.assertNotEqual(moved, pairing)

    def test_21_junction_graph_does_not_certify_independent_routed_threads(self):
        graph = EventGraph(
            frozenset({"a", "b", "j", "c", "d"}),
            frozenset({("a", "j"), ("b", "j"), ("j", "c"), ("j", "d")}),
        )
        self.assertEqual(len(graph.maximal_paths()), 4)
        with self.assertRaises(NonlinearTraversal):
            graph.threads()

    def test_22_added_disjoint_process_adds_one_computational_thread(self):
        graph = two_wires()
        expanded = EventGraph(graph.nodes | {"c0", "c1"}, graph.edges | {("c0", "c1")})
        self.assertEqual(len(expanded.threads()), len(graph.threads()) + 1)

    def test_23_coarsening_disconnected_fibres_creates_unliftable_paths(self):
        graph = two_wires()
        projection = lambda v: "middle" if v in {"a1", "b1"} else v
        audit = path_lifting_audit(graph, projection)
        self.assertEqual(len(audit["genuine_images"]), 2)
        self.assertEqual(len(audit["coarse_paths"]), 4)
        self.assertEqual(len(audit["unliftable_paths"]), 2)
        self.assertFalse(audit["bijective_on_maximal_paths"])

    def test_24_nested_path_faithful_contractions_compose(self):
        graph = EventGraph(
            frozenset(str(i) for i in range(6)),
            frozenset((str(i), str(i + 1)) for i in range(5)),
        )
        first = lambda v: str(int(v) // 2)
        second = lambda v: "L" if int(v) < 2 else "R"
        intermediate = graph.quotient(first)
        direct = lambda v: second(first(v))
        self.assertTrue(path_lifting_audit(graph, first)["bijective_on_maximal_paths"])
        self.assertTrue(path_lifting_audit(intermediate, second)["bijective_on_maximal_paths"])
        self.assertTrue(path_lifting_audit(graph, direct)["bijective_on_maximal_paths"])
        for path in graph.maximal_paths():
            self.assertEqual(path_image(path_image(path, first), second), path_image(path, direct))

    def test_25_coarsening_can_lose_multiplicity_without_creating_extra_paths(self):
        graph = two_wires()
        audit = path_lifting_audit(graph, lambda v: "one_macro_event")
        self.assertFalse(audit["unliftable_paths"])
        self.assertEqual(len(audit["genuine_images"]), 1)
        self.assertEqual(len(graph.maximal_paths()), 2)
        self.assertFalse(audit["bijective_on_maximal_paths"])

    def test_26_cycles_are_not_admitted_as_time_indexed_event_dags(self):
        with self.assertRaises(ValueError):
            EventGraph(frozenset({"a", "b"}), frozenset({("a", "b"), ("b", "a")}))

    def test_27_graph_thread_family_is_not_a_substrate_site_partition(self):
        graph = EventGraph(
            frozenset({"site0:t0", "site1:t1", "site1:t0", "site0:t1"}),
            frozenset({("site0:t0", "site1:t1"), ("site1:t0", "site0:t1")}),
        )
        self.assertEqual(len(graph.threads()), 2)
        sites = [{v.split(':')[0] for v in thread} for thread in graph.threads()]
        self.assertEqual(sites[0], sites[1])

    def test_28_branch_graph_records_structure_without_assigning_weights(self):
        graph = EventGraph(frozenset({"p", "a", "b"}), frozenset({("p", "a"), ("p", "b")}))
        self.assertEqual(len(graph.maximal_paths()), 2)
        self.assertFalse(hasattr(graph, "probability"))


if __name__ == "__main__":
    unittest.main(verbosity=2)
