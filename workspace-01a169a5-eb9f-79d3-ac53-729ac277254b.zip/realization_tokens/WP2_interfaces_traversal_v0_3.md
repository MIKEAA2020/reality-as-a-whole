# Work Package 2 — Interfaces and traversal, v0.3

## Derivation where possible; families and suspension where not

**Scope:** finite deterministic intervention-structured networks and finite time-indexed event DAGs. No phenomenal constitution, observer measure, or zero-residue actuality argument is assumed to follow from these models.

**Deliverables:** an interface-derivation theorem attempt; a restricted location-traversal theorem and nonlinear countermodels; a four-input reduction audit; and a shared assumptions ledger with an explicit `actuality_argument_obligation` column.

**Headline result:** the shared controller is structurally identifiable, but its constitutive/interface status is not entailed by the present causal constraints. A canonical family of admissible annotations is available. A unique family of traversing computational threads is derivable on wire-linear event graphs, but not by indiscriminately counting maximal paths in branching graphs.

**Validation:** 28 new tests pass. The complete project suite contains 88 tests. A new exhaustive subcheck covers all 256 deterministic two-bit update maps and all three proper port choices: 768 conditional-factorization cases. These are mathematical model checks, not consciousness experiments.

---

## 1. What counts as deriving an interface?

Three questions must remain distinct:

1. Can a node's causal role be identified without its written name?
2. Can an internal update factorization be derived **given** a port set?
3. Does the causal structure itself entail that a particular node is an external enabling condition rather than a constituent of a realization?

The answer can be yes to the first two while remaining underdetermined on the third.

A parameter-free algorithm is not automatically an intrinsically justified criterion. Two covariance-respecting algorithms without fitted coefficients can optimize different structural properties and return different answers.

## 2. Formal interface annotations

Take a full-product bit network with exact elementary-intervention dependency graph. Write `i→j` when changing only input `i` can change next output `j`.

An interface annotation consists of:

- a proper port set `P`, leaving at least one internal coordinate;
- a partition `C₁,…,Cₘ` of `V\\P` into nonempty internal blocks;
- conditional autonomy of each block:

\[
s|_{C_i\cup P}=t|_{C_i\cup P}
\quad\Rightarrow\quad
F(s)|_{C_i}=F(t)|_{C_i}.
\]

This expresses a conditional product factorization of the internal update. It does not express phenomenal unity.

We also test the **stronger optional condition** that ports evolve autonomously: `F_P` depends only on `P`. This is not silently built into the metaphysics of an interface; it is an explicit restriction used to make the countermodel stronger. Real interfaces can allow feedback.

### 2.1 Finest conditional-factorization theorem

For a fixed `P`, remove its nodes from the dependency graph. The weak connected components of the induced internal graph form the unique finest partition satisfying the conditional-autonomy condition.

**Proof.** An influence edge between two proposed blocks violates conditional autonomy: changing its source while holding the target block and ports fixed changes a target update. Therefore every valid block partition must keep the endpoints of every internal influence edge together. It must consequently keep each weak component together. Conversely, no influence edge enters one weak component from another internal component; on a full product its output depends only on itself and the declared ports. Thus the component partition is valid and refines every other valid partition. ∎

This is a useful theorem about conditional product structure. It is not a theorem that the finest partition gives the subjects.

## 3. The shared-control model: an explicit family

Use the unchanged model

\[
F(x,y,c)=(x\oplus c,\ y\oplus c,\ c).
\]

Here `c` is an enable/control bit, not a physical theory of clocks.

With the stronger autonomous-port restriction and the finest-block convention, all admissible annotations are:

| Ports | Finest internal blocks | Reading permitted by the causal constraints |
|---|---|---|
| `∅` | `{x,y,c}` | One internally specified causal whole |
| `{c}` | `{x}`, `{y}` | Two conditional streams with shared external control |
| `{x,c}` | `{y}` | One stream with the other coordinates externalized |
| `{y,c}` | `{x}` | The symmetric alternative |

There are four finest annotations. Allowing coarser valid internal partitions adds a fifth annotation: ports `{c}` with the joint block `{x,y}`. Dropping the autonomous-port restriction permits all seven proper port choices with their finest conditional blocks.

These are alternative annotations of one causal model, not assertions that all corresponding observers simultaneously exist.

### 3.1 Constituent and interface readings share the same causal model

Two annotations already suffice:

\[
A_0:\quad P=\varnothing,\quad\mathscr C=\{\{x,y,c\}\},
\]

\[
A_1:\quad P=\{c\},\quad\mathscr C=\{\{x\},\{y\}\}.
\]

Both satisfy the same background dynamics, intervention structure, full-product state assumptions, conditional adequacy and optional autonomous-port condition. They disagree on whether `c` is a port.

**Relative non-entailment result:** the current causal constraints do not entail `Interface(c)` or its negation. In model-theoretic terms, one causal reduct admits two adequate expansions of the interface annotation.

This is not a proof that every possible constitutive theory must be underdetermined. It is a proof that the present premises have not determined the constitutive interface.

### 3.2 c is nevertheless structurally identifiable

Ignoring self-edges, `c` is the unique upstream coordinate in this model, and it affects both other coordinates. A parameter-free formula can identify it.

Therefore there is **no symmetry obstruction to merely defining a selector for c here**. The obstruction is interpretive: why must this distinctive causal role count as external enabling rather than internal constitution?

Equating “upstream controller” with “external interface” would be an additional constitutive criterion, not a result already supplied by the causal graph.

### 3.3 Two coefficient-free objectives disagree

Among the admissible annotations:

- **Minimize externalization** (`|P|`): selects `A₀`.
- **Maximize the number of conditional internal factors**: selects `A₁`.

Both objectives are parameter-free and covariant under coordinate renaming. Their disagreement proves neither objective wrong. It demonstrates that “no fitted coefficient” does not mean “no unexplained selection principle.”

Requiring at least two internal factors also selects ports `{c}` uniquely in this toy model. But the two-factor requirement must be justified independently; it cannot be imported because two streams were the intended answer.

### 3.4 WP2 interface verdict

An interface is uniquely recoverable here **conditional on a stronger structural goal**. It is not uniquely recoverable as constitutive status from causal adequacy alone.

The correct output at this stage is the admissible family and the explicit conditions under which it collapses—not a forced choice and not an average over annotations.

## 4. Location traversal: a restricted positive theorem

### 4.1 Wire-linear event graphs

Let `G` be a finite directed acyclic graph of supplied event occurrences. Call it wire-linear if every node has at most one predecessor and at most one successor.

**Thread theorem.** Every weak component of a wire-linear finite event DAG is one directed path, possibly a singleton. The maximal paths therefore give a unique partition of its nodes into threads.

**Proof.** Unique predecessor and successor bounds prevent branching and merging. Acyclicity makes following either direction terminate. Starting from any event therefore determines one maximal directed path, and paths that meet must coincide. ∎

The result is covariant under passive event renaming. It does not select one thread as privileged and does not count threads as subjects.

### 4.2 Changing storage locations

The three-register permutation from v0.2 has three such event threads:

```text
x0 → z1 → y2 → x3 → ...
y0 → x1 → z2 → y3 → ...
z0 → y1 → x2 → z3 → ...
```

Each thread visits every hardware location while retaining distinct time-indexed occurrences. Thus its identity cannot be reduced to a set of storage sites.

This is a restricted carrier construction that does not need a separately named target for each wire: the graph returns the complete canonical family of paths. The restriction to wire-linear organization is essential.

### 4.3 Subdivision and faithful contraction

Subdividing a wire edge into a chain preserves its thread organization. Contracting connected linear segments can preserve a bijection of concrete and macro paths.

This is a statement about computational organization and description transport. An actual physical insertion of new events is not literally the same numerical occurrence merely because the path shape is preserved. Nor does every unary graph node lack experiential relevance.

For a projection `q` of event descriptions, retain the path images and check:

1. every reported coarse maximal path lifts to a genuine concrete maximal path;
2. distinct concrete maximal paths are not merged into one reported path.

These conditions give a finite path-faithfulness audit. When two admissible contractions induce bijections of maximal paths, their composition does too; direct and nested path-image maps agree.

This is the restricted nested-emulation correspondence established by the new tests. It does not justify arbitrary graph quotients or arbitrary virtual-machine abstractions.

## 5. Branch, merge and routing limits

### 5.1 Fork and merge

For a fork `p→a`, `p→b`, the two maximal paths both contain `p`. For a merge, both contain the output event. Maximal paths are therefore not a partition of occurrence events.

A diamond has two maximal paths with six total node incidences but only four distinct occurrence nodes. Counting paths as independently realized observer tokens would double-count shared occurrences unless another argument supplied the contribution unit.

The implementation returns suspension of the wire-thread criterion outside its domain. It retains the branching DAG rather than forcing a subject partition.

### 5.2 A routing ambiguity at a two-in/two-out junction

With two inputs and two outputs, a bare junction graph permits two one-to-one routings. Swapping the output names exchanges them. No routing is fixed by that symmetry if no transfer semantics distinguishes the outputs.

This establishes a restricted graph-level routing obstruction. Once adequate local state/transfer semantics is supplied, the ambiguity can disappear. A dependency graph cannot replace that semantics: an XOR gate and an AND gate can have the same dependency graph but different transition tables.

### 5.3 Nested descriptions can create false paths by forgetting provenance

Begin with two separate executions:

```text
a0 → a1 → a2
b0 → b1 → b2
```

Now identify `a1` and `b1` as one coarse node `M`, retaining the distinct endpoints:

```text
a0 ─┐     ┌─ a2
    M
b0 ─┘     └─ b2
```

The coarse graph has four maximal paths. Only two are images of real fine paths. The cross paths `a0→M→b2` and `b0→M→a2` have no lift to either original execution.

**A coarse graph can invent apparent causal trajectories merely by merging disconnected fibers.** The added paths are not additional realizations.

The opposite failure is also possible: collapsing both entire executions to one macro node produces no false extra path, but loses multiplicity. Thus absence of false paths alone is insufficient; the relevant distinct path images must also remain distinct.

Keeping provenance repairs these examples. It does not by itself supply a general phenomenal individuation criterion.

## 6. Four-input reduction audit

The machine-readable record is `input_reduction_audit_v0_3.csv`.

| Input | Merely representational part | Substantive remainder | v0.3 classification and outcome |
|---|---|---|---|
| Intervention algebra | Coordinate names and map labels | Distinguished admissible operations/composition | Causal organization relative to the model; not shown to be globally constitutive or merely enabling. Not eliminated. |
| Target decoder | Output-state names and injective recodings | Informational partition and role scope | Role-defining for a computational realization; not yet perspective-constituting. Not eliminated generally. |
| Ports | Names of selected ports | Internal/external annotation | Can designate enabling conditions relative to a chosen role. Its absolute constitutive status is not determined by causal adequacy. Family returned. |
| Event grain | Calendar units and passive event names | Event distinctions, grouping and path provenance | Not generally representational: coarse grouping can invent paths or erase multiplicity. Restricted faithful contractions certified. |

The intervention and decoder examples from v0.1/v0.2 establish why their substantive parts cannot simply be discarded. The present interface family and graph-coarsening counterexamples do the same for ports and event grain.

**Unconditional reduction scoreboard: zero of the four substantive inputs has been globally eliminated.** This is not a negative verdict on all progress. We have replaced forced choices with derived families, removed some naming choices, derived conditional finest factorizations, and obtained a canonical traversal construction on a restricted class.

Packaging all four ingredients into one “realization structure” would not reduce them unless their relationships were derived. No fifth universal boundary principle has been declared.

## 7. Shared ledger v0.3 and the actuality burden

The shared `assumptions_ledger.csv` now has 30 entries and an explicit `actuality_argument_obligation` column. It specifies, for every assumption, what a completed actuality account would have to establish, reconstruct, or make intelligibly nonunique.

Change record: A19's status now records the restricted traversal theorem; A20's status now records the derived interface family and remaining constitutive non-entailment. A24–A30 are added. Every entry receives the new actuality-obligation field. No earlier assumption is silently marked discharged.

New explicit commitments include:

- independently evolving ports are an optional stronger condition, not an unquestioned interface definition;
- finest computational factorization is not automatically phenomenal unity;
- wire-linear traversal is restricted and must suspend at unsupported branch/merge cases;
- coarse descriptions need numerical/provenance auditing, not only syntactic adequacy;
- parameter-free selection is not assumption-free selection;
- **uniqueness is an output to be earned, not an input to be assumed**.

Earlier ZIP bundles remain historical snapshots. The latest bundle includes the updated shared ledger and all three stages.

## 8. Consequence for the search toward maximal intelligibility

WP2 does not warrant the claim that constitutive boundaries can never be intrinsic. It establishes where the current formal premises stop.

Three distinctions must survive the next move:

1. A uniquely identifiable causal feature need not have uniquely determined constitutive status.
2. A unique complete actuality could support several equally valid local decompositions; those decompositions must not automatically be counted as additional subjects.
3. An unexplained preference among parameter-free algorithms is still an unexplained preference.

To go further, another causal heuristic is insufficient unless independently justified. The next substantive argument must either:

- derive constitutive/interface status from a richer intrinsically justified account;
- show that interface status is genuinely role-relative and explain why that relativity leaves actual experiential individuation determinate;
- or establish principled non-identifiability and state exactly which observer and probability claims must consequently remain suspended.

The formal work has not selected among these conclusions. It has given them different, testable burdens.

## 9. Files and reproduction

New files:

- `interface_derivation.py` — interface family enumeration, conditional factorization, conservative traversal and path-provenance audit;
- `test_interface_derivation.py` — 28 new tests;
- `interface_test_results.txt` — recorded new-suite run;
- `input_reduction_audit_v0_3.csv` — decomposition of the four inputs;
- `combined_test_results_v0_3.txt` — complete regression run;
- `assumptions_ledger.csv` — shared updated ledger.

Run:

```bash
cd realization_tokens
python -m unittest -v \
  test_realization_tokens.py \
  test_intervention_selection.py \
  test_interface_derivation.py
```

**Acceptance judgment:** the requested interface-derivation attempt yields conditional uniqueness and explicit constitutive underdetermination; location traversal succeeds on a sharply delimited class and suspends elsewhere; the four-input audit reports no hidden elimination; the actuality burden and uniqueness discipline are recorded explicitly. No consciousness criterion, measure, or complete metaphysics is claimed.
