# Work Package 1 — Carrier and grain selection, v0.2

## What intervention structure can determine, and what it cannot

**Status:** a conditional constructive theorem, a symmetry obstruction, and finite temporal/interface countermodels. No consciousness criterion, self-location measure, or zero-residue ontology has been established.

**New implementation:** `intervention_selection.py` and `test_intervention_selection.py`.

**Validation:** 28 new tests pass. One test exhaustively checks the minimal-envelope result for all 256 deterministic two-bit transition maps and all three nonempty targets: 768 target instances. These finite checks supplement, rather than replace, the proofs below.

**Main outcome:** a target-relative causal envelope is derivable once elementary interventions, full-product variation, a target, and a temporal grain are fixed. The derivation does not by itself choose a constitutive perspective, an interface boundary, or an observer-counting unit.

---

## 1. The exact question

Version 0.1 supplied a conditional equivalence of anchored computational role-segments. Its largest inputs were target-event support, counterfactual variation and logical grain.

Version 0.2 asks whether those inputs can be recovered from a structure of interventions rather than entered as named process boundaries.

We distinguish four achievements:

1. recover a coordinate/subsystem decomposition from an intervention algebra;
2. derive a minimal causal envelope for a specified target;
3. make that construction insensitive to merely representational choices of temporal sampling;
4. show that the resulting envelope is constitutive of a perspective.

The first two can be achieved conditionally in finite models. The third requires preserving causal-path provenance. The fourth does not follow from causal connectivity or autonomy.

## 2. A precise obstruction: no universal unique binary decomposition from bare dynamics

### 2.1 The four-state model

Let `S={0,1,2,3}` and let the dynamics be the identity map.

There are three balanced binary partitions:

- `A = 01 | 23`;
- `B = 02 | 13`;
- `C = 03 | 12`.

Any two distinct partitions give a two-bit product factorization: their block intersections are the four singleton states. Thus the three unordered factorizations are

\[
\{A,B\},\qquad\{A,C\},\qquad\{B,C\}.
\]

Every permutation of the four states preserves the identity dynamics. These permutations act transitively on the three factorizations, and no factorization is fixed by all of them.

### 2.2 Equivariance obstruction

A representation-independent rule selecting exactly one factorization from the bare structure `(S,F)` must commute with its automorphisms. On this model, its selected factorization would consequently have to be fixed by every state permutation. None is.

**Therefore no everywhere-defined, equivariant selector can choose one nontrivial two-bit factorization from bare finite dynamics in every such frame.**

This is a narrow no-go result, not a claim that rich actual systems cannot have privileged decompositions. Returning the family of all three candidates is covariant. Selecting the trivial whole state space is also possible. Neither produces the requested unique differentiated decomposition.

Also note what has NOT been shown: that the three alternative factorizations are three actual groups of observers. They are three possible decompositions of one mathematical frame.

### 2.3 Precision correction to v0.1

The earlier XOR coordinate example showed that a particular component-counting heuristic changes under refactorization. By itself it did not prove that no intrinsic selector could ever distinguish the alternatives. The automorphism argument here establishes the restricted universal-selector obstruction cleanly.

## 3. A constructive result: subsystem structure from an unlabelled intervention algebra

Use the conventional encoding `S={00,01,10,11}` only to describe this example. Supply four reset maps:

\[
R_{x0}(x,y)=(0,y),\quad R_{x1}(x,y)=(1,y),
\]
\[
R_{y0}(x,y)=(x,0),\quad R_{y1}(x,y)=(x,1).
\]

Now discard the written names `x`, `y`, `0`, `1` and retain only these maps and their composition.

- Opposite resets of one coordinate absorb one another: `R_a R_b=R_a`, `R_b R_a=R_b`.
- Resets of distinct coordinates commute.
- The images of the two resets in one family give that coordinate's value partition.

In this finite example the algebra therefore recovers the two coordinate partitions, up to exchanging factors and exchanging their value names. Exhaustive enumeration of the three candidates gives exactly one compatible factorization.

The result is covariant under all 24 passive permutations of the concrete state space.

### 3.1 The generators need not be separately labelled primitive

The four resets generate a nine-element transformation monoid:

- the identity;
- the four rank-two elementary resets;
- the four constant maps.

The resets are recoverable as the proper idempotents of maximal rank. Thus, in this example, the complete unlabelled intervention monoid suffices; a further list naming primitive generators is unnecessary.

### 3.2 What remains assumed

The particular intervention algebra is still supplied.

A different reset algebra on the same four states and identity dynamics selects a different factorization. An unstructured pool containing the reset families of all three candidates does not privilege one of them. The full transformation monoid likewise contains all three candidate families.

This is genuine conditional progress: coordinate names and separately declared factors can be removed. It is not an explanation of why this intervention algebra belongs to concrete actuality.

## 4. Deriving a target-relative minimal causal envelope

### 4.1 Scope and definitions

Let

\[
S=\prod_{i\in V}\{0,1\}
\]

be a full product with specified elementary coordinate interventions, and let `F:S→S` be deterministic.

Define an influence edge

\[
i\to j
\]

iff two states differing only in coordinate `i` can yield different values of output coordinate `j`.

For a target decoder `π`, define its essential support `Jπ` to contain `i` iff changing only `i` can change `π`.

On a full product, this essential support is the unique smallest coordinate set determining `π`: variables outside it can be changed one at a time without changing the output. This uniqueness need not survive restrictions to a correlated domain.

For a specified target set `J`, define

\[
C(J)=\operatorname{Anc}(J),
\]

including `J` itself: repeatedly add every predecessor of a coordinate already present.

Call `A` autonomous if `F_A(s)=F_A(t)` whenever `s` and `t` agree on `A`. Equivalently, its updates do not require variables outside `A`.

### 4.2 Minimal-envelope theorem

**Theorem.** On a finite full-product frame with the specified elementary interventions, `C(J)` is the unique least autonomous coordinate set containing `J`.

**Proof.**

1. On a full product, autonomy is equivalent to predecessor closure. An influence edge entering from outside directly violates autonomy. Conversely, if no such edge exists, varying outside coordinates one at a time cannot change the internal update.
2. Any predecessor-closed set containing `J` contains every ancestor of `J`.
3. The ancestor closure of `J` is itself predecessor-closed.
4. Hence `C(J)` is autonomous and contained in every autonomous set containing `J`. ∎

This supplies a concrete algorithm without an integration threshold or free weighting coefficient. It also gives a canonical carrier *relative to the supplied target and intervention frame*.

### 4.3 Full-product variation matters

On the restricted domain `{00,11}`, the function `π(x,y)=x` is determined by either singleton support `{x}` or `{y}`. Neither support contains the other, and their empty intersection does not determine the function.

Thus there can be two incomparable minimal supports. The full-product assumption is doing real work.

In a necessitarian completion, full-product counterfactual variation cannot simply be declared to consist of metaphysically possible alternative total realities. Its appropriate meaning must be justified.

### 4.4 Causal envelope is not constitutive carrier

The theorem identifies what is needed for a selected coordinate set to update autonomously. It does not establish that every upstream cause is part of a subject, or that autonomous coordinate sets are subjects.

For example, with

\[
F(a,b,c)=(a,a,b),
\]

the autonomous envelope of target `c` contains all three coordinates. That is a consequence of causal ancestry, not a discovery that all three constitute one perspective.

Nor does the theorem select its own target decoder. Different decoders can require singleton or joint envelopes. Target selection remains an independent obligation.

## 5. A temporal-grain counterexample, and a partial repair

### 5.1 Fixed-location autonomy changes under sampling

Consider the three-register permutation

\[
F(x,y,z)=(y,z,x).
\]

At stride one the location-dependency graph is a three-cycle. The minimal autonomous coordinate set containing any one register is the whole triple.

But

\[
F^3=\mathrm{id}.
\]

At stride three, each register is autonomous in the sampled endpoint dynamics. The number of minimal nonempty autonomous coordinate sets changes from one to three.

For strides one through six, the counts are

\[
1,1,3,1,1,3.
\]

This is not a count of subjects. It refutes a proposal to identify perspectives directly with minimal autonomous fixed-site sets without a justified grain principle.

### 5.2 Unroll the events rather than collapsing time into site labels

In the time-indexed dependency graph, the same permutation has three independent information paths:

```text
x0 → z1 → y2 → x3 → ...
y0 → x1 → z2 → y3 → ...
z0 → y1 → x2 → z3 → ...
```

These paths use every storage location over time but contain disjoint time-indexed occurrences.

For a six-step horizon, the graph has three weak components with seven nodes each. Sampling endpoints every three steps preserves their identification if each macro edge retains the micro-path it summarizes.

This improves the carrier proposal in a real way:

> A carrier must be capable of following an organized process through changing storage locations. A set of hardware sites is not, by itself, its numerical identity.

It also supports v0.1's insistence on event anchors rather than hardware names.

### 5.3 The repair is limited

This works cleanly for a permutation network. General computations can combine, branch and share causal paths. Weak connected components of an unrolled graph are not thereby a subject partition.

Retaining the full primitive event graph avoids some losses of endpoint-only sampling, but the privileged primitive event grain is still an assumption. A simulated process can also be implemented through many host updates, so “always use the fastest physical clock” is not an adequate general solution.

## 6. Shared control defeats causal-connectedness as a subject criterion

Let two candidate streams share a control/enable bit:

\[
F(x,y,c)=(x\oplus c,\ y\oplus c,\ c).
\]

The bit `c` controls whether each stream flips at a global step. It is a toy clock/control interface, not a physical theory of time.

Over the full intervention domain, `c` influences both streams. The unrolled weak causal graph is connected. Each stream's autonomous envelope includes the shared controller.

Yet conditional on a specified control input, the two internal state evolutions factor:

\[
x'=f(x,c),\qquad y'=g(y,c).
\]

Declaring `c` an interface port and excluding it from the internal carrier leaves two separate internal paths.

### 6.1 A relative version of the positive theorem

For a supplied port set `P`, require internal updates on `A` to depend only on `A∪P`. Add ancestors while stopping at ports. The same predecessor-closure proof gives the unique least *port-relative* autonomous envelope containing a target.

The theorem is valid. But the boundary decision is supplied: why is `c` an external interface rather than a constituent of one larger subject?

Therefore:

- “all causes belong to the subject” is too strong;
- “all weakly connected events form one subject” is too strong;
- a causal or informational role can be independent **relative to an interface** without an absolute causal separation.

These are structural cautions. The toy bits are not asserted to be conscious.

## 7. What R0 gains, and what it still cannot infer

`R0` can now be supplemented with a conditional support certificate derived from:

1. an intervention algebra selecting elementary variables;
2. a target decoder;
3. a temporal/event description;
4. an optional explicit interface-port set.

It need not always accept an arbitrary hand-written set of target variables.

But a derived causal envelope is not automatically the correct support of a perspectival realization. A certificate must continue to distinguish:

- internal organization;
- mediation by implementation machinery;
- external enabling/input conditions;
- actual concrete event multiplicity.

No change is made to the epistemic quarantine in v0.1. No equal-weight rule, probability normalization, or counting unit is inferred from these causal constructions.

## 8. Findings against the revised success condition

### Positive findings

- In a finite model, intervention algebra can recover an unlabelled subsystem decomposition uniquely and covariantly.
- With that structure and a target, the minimal autonomous causal envelope is uniquely derivable.
- A time-indexed path account can preserve distinct information streams despite complete overlap in their storage-location support over time.
- Port-relative conditional autonomy is mathematically well-defined and admits the same least-envelope result.

### Negative findings

- No universal unique nontrivial binary factorization follows from bare finite dynamics alone.
- Restricted counterfactual domains can defeat uniqueness of minimal support.
- Fixed-site autonomy is not invariant under endpoint sampling.
- Weak causal connectivity merges streams through shared control and therefore does not itself establish subject unity.
- The intervention algebra, target, interface ports and event grain remain substantive inputs.

### Relation to the uniqueness hunch

These countermodels do not refute a unique maximally intelligible account of actual reality. Such an account might exclude these frames, derive their extra structure, or make their nonuniqueness intelligible.

They do show that the current general constraints do not determine a unique local perspective decomposition in arbitrary admissible toy models. A demand for uniqueness is not a substitute for the missing selection argument.

The correct outcome on an underdetermined frame is a family or suspension—not a label-based choice and not a count of all alternative decompositions as actual observers.

## 9. Updated next obligation

The next problem is sharper than “find causal integration”:

> Derive a distinction between constitutive organization and enabling/mediating conditions, without assuming the target perspective or selecting its boundary by a free parameter.

The two decisive cases are now:

1. a process moving through different physical locations, whose identity should not be tied to fixed hardware;
2. two internally separate processes sharing an implementation/control interface, whose common causes should not automatically identify them.

A proposed boundary principle must handle both. Pure spatial support fails the first; unrestricted causal closure fails the second.

This gives a more precise candidate direction: **realization-relative organization with an explicitly justified interface**, rather than either raw physical locality or total causal ancestry. It remains a proposal to construct, not the final principle.

## 10. Reproducibility and shared record

New files:

- `intervention_selection.py` — finite factorization/intervention algebra and causal-envelope constructions;
- `test_intervention_selection.py` — 28 tests;
- `intervention_test_results.txt` — recorded run;
- `carrier_grain_suite.csv` — case-level findings;
- `assumptions_ledger.csv` — shared ledger, extended for v0.2.

Run both work-package suites:

```bash
cd realization_tokens
python -m unittest -v test_realization_tokens.py test_intervention_selection.py
```

The combined suite contains 60 tests. The 256-map exhaustive subcheck is one of those tests, not an additional claim of 768 independent theories or empirical experiments.

**Acceptance judgment:** v0.2 derives a conditional causal-envelope rule and rejects several proposed unconditional selectors. It does not complete description-independent perspective individuation or demonstrate that actuality, experience and probability have one ultimate explanation.
