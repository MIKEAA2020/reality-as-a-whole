"""WP4 v0.5: presentation candidates, modal scope, identification sets.

No partition is declared phenomenal. Stable congruences are candidate
structural presentations only. Kripke countermodels test entailment from
specified premises; they do not establish metaphysical possibility.

Cross-role dependencies (binding audit: wp4_cross_role_dependencies_v0_5.csv):
- Formal epistemology supplies the q/tau distinction and limits on counting.
- Computation supplies finite-model semantics and the conditional padding lemma.
- Physics/credence supplies the interface, sampling, and evidence scope audit.
- Project lead supplies constitutive adequacy and the non-brute actuality demand.
These are shared conceptual responsibilities, not external reviewer endorsements.
"""
from __future__ import annotations

from dataclasses import dataclass
from itertools import combinations, product
from typing import Callable, Hashable, Iterable

from intervention_selection import BitNetwork
from operational_equivalence import MooreMachine
from realization_tokens import partition_code


def set_partition_codes(n: int):
    """All set partitions as restricted-growth strings, with no duplicates."""
    if n < 1:
        raise ValueError("Need at least one state.")
    def extend(prefix, maximum):
        if len(prefix) == n:
            yield tuple(prefix)
            return
        for label in range(maximum + 2):
            yield from extend(prefix + [label], max(maximum, label))
    yield from extend([0], 0)


def stable_under(partition: tuple[int, ...], transformations: Iterable[tuple[int, ...]]):
    """An equality class has a well-defined successor under every map."""
    for transformation in transformations:
        successor_class = {}
        for state, block in enumerate(partition):
            image = partition[transformation[state]]
            if block in successor_class and successor_class[block] != image:
                return False
            successor_class[block] = image
    return True


def stable_partitions(n: int, transformations: Iterable[tuple[int, ...]]):
    transformations = tuple(transformations)
    return frozenset(
        partition for partition in set_partition_codes(n)
        if stable_under(partition, transformations)
    )


def coordinate_reset_maps(n: int):
    states = tuple(product((0, 1), repeat=n))
    index = {state: i for i, state in enumerate(states)}
    result = set()
    for coordinate in range(n):
        for value in (0, 1):
            images = []
            for state in states:
                changed = list(state)
                changed[coordinate] = value
                images.append(index[tuple(changed)])
            result.add(tuple(images))
    return frozenset(result)


def network_map(network: BitNetwork):
    index = {state: i for i, state in enumerate(network.states)}
    return tuple(index[network.step(state)] for state in network.states)


def coordinate_projection_partition(n: int, coordinates: Iterable[int]):
    coordinates = tuple(sorted(coordinates))
    states = tuple(product((0, 1), repeat=n))
    return partition_code(tuple(state[i] for i in coordinates) for state in states)


def all_coordinate_subsets(n: int):
    return tuple(
        frozenset(indices)
        for size in range(n + 1)
        for indices in combinations(range(n), size)
    )


def recover_projection_support(n: int, partition: tuple[int, ...]):
    candidates = [
        subset for subset in all_coordinate_subsets(n)
        if coordinate_projection_partition(n, subset) == partition
    ]
    return candidates[0] if len(candidates) == 1 else None


def transport_projection_in_three_ring(coordinates: Iterable[int], time: int):
    """At time t, initial lane i occupies site (i-t) mod 3."""
    coordinates = tuple(sorted(coordinates))
    return lambda state: tuple(state[(i - time) % 3] for i in coordinates)


@dataclass(frozen=True)
class ModalFrame:
    """Finite logical countermodel only; no metaphysical possibility claim."""
    worlds: frozenset[Hashable]
    accessibility: frozenset[tuple[Hashable, Hashable]]
    valuation: dict[str, frozenset[Hashable]]

    def atom(self, world, name):
        return world in self.valuation.get(name, frozenset())

    def box(self, world, predicate: Callable[[Hashable], bool]):
        return all(predicate(target) for source, target in self.accessibility if source == world)


def performative_necessity_countermodel():
    return ModalFrame(
        frozenset({"actual", "alternative"}),
        frozenset(product(("actual", "alternative"), repeat=2)),
        {
            "appearing": frozenset({"actual"}),
            "attempted_denial": frozenset({"actual"}),
        },
    )


def replication_model(base: MooreMachine, copies: int):
    """N candidate executions, observed through the first component only.

    Calling them N perspectives remains conditional on the constitutive and
    duplicate-preservation premises. This function never infers consciousness.
    """
    if copies < 1:
        raise ValueError("Need at least one component.")
    return MooreMachine(
        tuple(product(base.states, repeat=copies)),
        base.inputs,
        lambda state, value: tuple(base.transition(component, value) for component in state),
        lambda state: base.observe(state[0]),
        name=f"{copies} candidate executions through first interface",
    )


def identification_set(models: Iterable, quantity: Callable):
    """Compatible values; not a distribution and not a rationality verdict."""
    return frozenset(quantity(model) for model in models)


def identification_status(values: Iterable):
    values = frozenset(values)
    if not values:
        return "inconsistent_or_empty_model_class"
    if len(values) == 1:
        return "point_identified_in_this_model_class"
    return "set_identified_not_point_identified"
