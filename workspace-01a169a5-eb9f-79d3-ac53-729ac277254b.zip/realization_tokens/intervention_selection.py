"""WP1 v0.2: intervention structure, target-relative carriers and grain tests.

No consciousness or probability rule is implemented. A recovered factorization
is conditional on a supplied intervention algebra. A causal envelope is not
asserted to be a constitutive carrier of a subject.
"""
from __future__ import annotations

from dataclasses import dataclass
from itertools import combinations, permutations, product
from typing import Callable, Iterable

from realization_tokens import partition_code

Partition = tuple[int, ...]
Factorization = frozenset[Partition]
MapTable = tuple[int, ...]
Bits = tuple[int, ...]


def balanced_binary_partitions(n: int = 4) -> tuple[Partition, ...]:
    if n < 2 or n % 2:
        raise ValueError("Need a positive even state-space size.")
    return tuple(
        values for values in product((0, 1), repeat=n)
        if values[0] == 0 and sum(values) == n // 2
    )


def binary_factorizations_four_states() -> frozenset[Factorization]:
    parts = balanced_binary_partitions(4)
    result = set()
    for a, b in combinations(parts, 2):
        if len({(a[s], b[s]) for s in range(4)}) == 4:
            result.add(frozenset((a, b)))
    return frozenset(result)


def action_partition(partition: Partition, permutation: MapTable) -> Partition:
    inverse = {image: source for source, image in enumerate(permutation)}
    return partition_code(partition[inverse[s]] for s in range(len(permutation)))


def action_factorization(factorization: Factorization, permutation: MapTable) -> Factorization:
    return frozenset(action_partition(p, permutation) for p in factorization)


def compose_maps(a: MapTable, b: MapTable) -> MapTable:
    """a after b."""
    return tuple(a[b[s]] for s in range(len(a)))


def conjugate_map(table: MapTable, permutation: MapTable) -> MapTable:
    inverse = {image: source for source, image in enumerate(permutation)}
    return tuple(permutation[table[inverse[s]]] for s in range(len(table)))


def elementary_resets(factorization: Factorization) -> frozenset[MapTable]:
    """All four one-bit reset maps for an unordered two-bit factorization."""
    a, b = sorted(factorization)
    inverse = {(a[s], b[s]): s for s in range(4)}
    resets = set()
    for value in (0, 1):
        resets.add(tuple(inverse[(value, b[s])] for s in range(4)))
        resets.add(tuple(inverse[(a[s], value)] for s in range(4)))
    return frozenset(resets)


def recover_factorizations(
    interventions: Iterable[MapTable], *, exact: bool = True
) -> frozenset[Factorization]:
    supplied = frozenset(interventions)
    return frozenset(
        fac for fac in binary_factorizations_four_states()
        if (elementary_resets(fac) == supplied if exact
            else elementary_resets(fac).issubset(supplied))
    )


def transformation_monoid(generators: Iterable[MapTable], n: int = 4) -> frozenset[MapTable]:
    closure = {tuple(range(n)), *generators}
    while True:
        additions = {compose_maps(a, b) for a in closure for b in closure}
        if additions.issubset(closure):
            return frozenset(closure)
        closure.update(additions)


def maximal_rank_proper_idempotents(monoid: Iterable[MapTable]) -> frozenset[MapTable]:
    tables = frozenset(monoid)
    if not tables:
        return frozenset()
    n = len(next(iter(tables)))
    candidates = {
        t for t in tables
        if len(set(t)) < n and compose_maps(t, t) == t
    }
    if not candidates:
        return frozenset()
    rank = max(len(set(t)) for t in candidates)
    return frozenset(t for t in candidates if len(set(t)) == rank)


def minimal_function_supports(
    domain: tuple[Bits, ...], decode: Callable[[Bits], object]
) -> frozenset[frozenset[int]]:
    """All inclusion-minimal coordinate supports on a supplied domain.

    Supports need not be unique on a correlated/restricted domain.
    """
    n = len(domain[0])
    supports = []
    for r in range(n + 1):
        for indices in combinations(range(n), r):
            candidate = frozenset(indices)
            if any(old.issubset(candidate) for old in supports):
                continue
            good = True
            for s in domain:
                for t in domain:
                    if all(s[i] == t[i] for i in candidate) and decode(s) != decode(t):
                        good = False
                        break
                if not good:
                    break
            if good:
                supports.append(candidate)
    return frozenset(supports)


@dataclass(frozen=True)
class BitNetwork:
    """A finite full-product network with selected elementary coordinate interventions.

    This coordinate/intervention structure is an input. The mathematical
    closure theorem does not establish its ontological fundamentality.
    """
    n: int
    table: tuple[Bits, ...]

    def __post_init__(self):
        states = self.states
        if self.n < 1 or len(self.table) != len(states):
            raise ValueError("Incorrect transition table size.")
        if any(value not in states for value in self.table):
            raise ValueError("Outputs must be states of the same full product.")

    @property
    def states(self) -> tuple[Bits, ...]:
        return tuple(product((0, 1), repeat=self.n))

    @classmethod
    def from_function(cls, n: int, function: Callable[[Bits], Bits]) -> "BitNetwork":
        states = tuple(product((0, 1), repeat=n))
        return cls(n, tuple(function(s) for s in states))

    def step(self, state: Bits) -> Bits:
        return self.table[self.states.index(state)]

    def sampled(self, stride: int) -> "BitNetwork":
        if stride <= 0:
            raise ValueError("Stride must be positive.")
        def transition(s):
            for _ in range(stride):
                s = self.step(s)
            return s
        return BitNetwork.from_function(self.n, transition)

    def dependency_edges(self) -> frozenset[tuple[int, int]]:
        """i -> j iff changing only input i can change output j."""
        edges = set()
        for state in self.states:
            current = self.step(state)
            for i in range(self.n):
                changed = list(state)
                changed[i] = 1 - changed[i]
                alternative = self.step(tuple(changed))
                for j in range(self.n):
                    if current[j] != alternative[j]:
                        edges.add((i, j))
        return frozenset(edges)

    def essential_support(self, decode: Callable[[Bits], object]) -> frozenset[int]:
        essential = set()
        for state in self.states:
            for i in range(self.n):
                changed = list(state)
                changed[i] = 1 - changed[i]
                if decode(state) != decode(tuple(changed)):
                    essential.add(i)
        return frozenset(essential)

    def ancestor_closure(
        self, target: Iterable[int], *, ports: frozenset[int] = frozenset()
    ) -> frozenset[int]:
        result = set(target)
        if not result.issubset(set(range(self.n)) - set(ports)):
            raise ValueError("Targets must be non-port network coordinates.")
        edges = self.dependency_edges()
        while True:
            expanded = result | {
                source for source, destination in edges
                if destination in result and source not in ports
            }
            if expanded == result:
                return frozenset(result)
            result = expanded

    def autonomous(
        self, carrier: Iterable[int], *, ports: frozenset[int] = frozenset()
    ) -> bool:
        """Internal updates depend only on carrier variables and declared ports."""
        carrier = frozenset(carrier)
        known = carrier | ports
        for s in self.states:
            for t in self.states:
                if all(s[i] == t[i] for i in known):
                    if any(self.step(s)[j] != self.step(t)[j] for j in carrier):
                        return False
        return True

    def autonomous_sets(self, *, ports: frozenset[int] = frozenset()) -> frozenset[frozenset[int]]:
        indices = sorted(set(range(self.n)) - set(ports))
        return frozenset(
            frozenset(candidate)
            for size in range(len(indices) + 1)
            for candidate in combinations(indices, size)
            if self.autonomous(candidate, ports=ports)
        )

    def minimal_nonempty_autonomous_sets(
        self, *, ports: frozenset[int] = frozenset()
    ) -> frozenset[frozenset[int]]:
        sets = self.autonomous_sets(ports=ports) - {frozenset()}
        return frozenset(a for a in sets if not any(b < a for b in sets))

    def unrolled_components(
        self, horizon: int, *, ports: frozenset[int] = frozenset()
    ) -> frozenset[frozenset[tuple[int, int]]]:
        """Weak components of the TIME-INDEXED dependency graph.

        This is a causal-wiring diagnostic, NOT a subject partition.
        Removing ports is an explicit interface assumption.
        """
        if horizon < 1:
            raise ValueError("A positive horizon is required.")
        indices = set(range(self.n)) - set(ports)
        adjacency = {(i, t): set() for i in indices for t in range(horizon + 1)}
        for t in range(horizon):
            for source, destination in self.dependency_edges():
                if source in indices and destination in indices:
                    a, b = (source, t), (destination, t + 1)
                    adjacency[a].add(b)
                    adjacency[b].add(a)
        remaining = set(adjacency)
        components = set()
        while remaining:
            frontier = [next(iter(remaining))]
            component = set(frontier)
            while frontier:
                a = frontier.pop()
                for b in adjacency[a]:
                    if b not in component:
                        component.add(b)
                        frontier.append(b)
            remaining.difference_update(component)
            components.add(frozenset(component))
        return frozenset(components)
