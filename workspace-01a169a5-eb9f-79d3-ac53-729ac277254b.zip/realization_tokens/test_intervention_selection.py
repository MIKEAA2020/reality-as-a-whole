"""WP1 v0.2 finite countermodels and conditional constructive results."""
from itertools import permutations, product
import unittest

from intervention_selection import (
    BitNetwork,
    action_factorization,
    balanced_binary_partitions,
    binary_factorizations_four_states,
    conjugate_map,
    elementary_resets,
    maximal_rank_proper_idempotents,
    minimal_function_supports,
    recover_factorizations,
    transformation_monoid,
)


class InterventionSelectionTests(unittest.TestCase):
    def setUp(self):
        self.factorizations = binary_factorizations_four_states()
        self.xy = frozenset(((0, 0, 1, 1), (0, 1, 0, 1)))
        self.ring = BitNetwork.from_function(3, lambda s: (s[1], s[2], s[0]))

    def test_01_three_balanced_binary_partitions(self):
        self.assertEqual(len(balanced_binary_partitions(4)), 3)

    def test_02_three_unordered_binary_product_factorizations(self):
        self.assertEqual(len(self.factorizations), 3)
        self.assertIn(self.xy, self.factorizations)

    def test_03_all_permutations_are_symmetries_of_identity_dynamics(self):
        identity = tuple(range(4))
        for p in permutations(range(4)):
            self.assertEqual(conjugate_map(identity, p), identity)

    def test_04_no_factorization_is_fixed_by_all_identity_symmetries(self):
        for fac in self.factorizations:
            self.assertTrue(any(action_factorization(fac, p) != fac for p in permutations(range(4))))

    def test_05_symmetry_action_is_transitive_on_factorizations(self):
        for fac in self.factorizations:
            orbit = {action_factorization(fac, p) for p in permutations(range(4))}
            self.assertEqual(orbit, set(self.factorizations))

    def test_06_label_based_lexicographic_selection_is_not_covariant(self):
        selected = min(self.factorizations, key=lambda fac: tuple(sorted(fac)))
        self.assertTrue(any(action_factorization(selected, p) != selected for p in permutations(range(4))))

    def test_07_set_of_all_candidates_is_covariant_but_not_a_unique_choice(self):
        for p in permutations(range(4)):
            transported = {action_factorization(fac, p) for fac in self.factorizations}
            self.assertEqual(transported, set(self.factorizations))
        self.assertNotEqual(len(self.factorizations), 1)

    def test_08_local_reset_family_selects_one_factorization(self):
        resets = elementary_resets(self.xy)
        self.assertEqual(len(resets), 4)
        self.assertEqual(recover_factorizations(resets), frozenset({self.xy}))

    def test_09_recovery_is_covariant_under_every_state_permutation(self):
        resets = elementary_resets(self.xy)
        for p in permutations(range(4)):
            moved_resets = {conjugate_map(r, p) for r in resets}
            self.assertEqual(
                recover_factorizations(moved_resets),
                frozenset({action_factorization(self.xy, p)}),
            )

    def test_10_different_intervention_families_select_different_products(self):
        for fac in self.factorizations:
            self.assertEqual(recover_factorizations(elementary_resets(fac)), frozenset({fac}))

    def test_11_unstructured_intervention_pool_does_not_privilege_a_product(self):
        pool = set().union(*(elementary_resets(fac) for fac in self.factorizations))
        self.assertEqual(recover_factorizations(pool, exact=False), self.factorizations)
        self.assertEqual(recover_factorizations(pool, exact=True), frozenset())

    def test_12_reset_monoid_has_nine_maps(self):
        monoid = transformation_monoid(elementary_resets(self.xy))
        self.assertEqual(len(monoid), 9)

    def test_13_reset_generators_recoverable_from_unlabelled_monoid(self):
        resets = elementary_resets(self.xy)
        monoid = transformation_monoid(resets)
        recovered = maximal_rank_proper_idempotents(monoid)
        self.assertEqual(recovered, resets)
        self.assertEqual(recover_factorizations(recovered), frozenset({self.xy}))

    def test_14_full_transformation_monoid_contains_all_candidate_reset_families(self):
        all_maps = set(product(range(4), repeat=4))
        self.assertEqual(len(all_maps), 256)
        self.assertEqual(recover_factorizations(all_maps, exact=False), self.factorizations)

    def test_15_essential_decoder_support_is_invariant_under_output_renaming(self):
        network = BitNetwork.from_function(2, lambda s: (1 - s[0], 1 - s[1]))
        self.assertEqual(network.essential_support(lambda s: s[0]), frozenset({0}))
        self.assertEqual(network.essential_support(lambda s: 1 - s[0]), frozenset({0}))
        self.assertEqual(network.essential_support(lambda s: (s[0], s[0])), frozenset({0}))

    def test_16_joint_decoder_can_require_a_joint_carrier(self):
        network = BitNetwork.from_function(2, lambda s: (1 - s[0], 1 - s[1]))
        support = network.essential_support(lambda s: s[0] ^ s[1])
        self.assertEqual(support, frozenset({0, 1}))
        self.assertEqual(network.ancestor_closure(support), frozenset({0, 1}))

    def test_17_feedforward_target_envelope_includes_ancestors(self):
        network = BitNetwork.from_function(3, lambda s: (s[0], s[0], s[1]))
        self.assertEqual(network.ancestor_closure({2}), frozenset({0, 1, 2}))
        self.assertTrue(network.autonomous({0, 1, 2}))
        self.assertFalse(network.autonomous({2}))

    def test_18_minimal_carrier_theorem_exhaustively_for_all_two_bit_dynamics(self):
        # Every one of the 4^4 = 256 deterministic full-product maps.
        # Three nonempty targets per map: 768 target instances.
        states = tuple(product((0, 1), repeat=2))
        targets = (frozenset({0}), frozenset({1}), frozenset({0, 1}))
        checked = 0
        for outputs in product(states, repeat=4):
            network = BitNetwork(2, outputs)
            autonomous = network.autonomous_sets()
            for target in targets:
                closure = network.ancestor_closure(target)
                supersets = [a for a in autonomous if target.issubset(a)]
                self.assertTrue(network.autonomous(closure))
                self.assertTrue(all(closure.issubset(a) for a in supersets))
                checked += 1
        self.assertEqual(checked, 768)

    def test_19_correlated_domain_can_have_two_incomparable_minimal_supports(self):
        domain = ((0, 0), (1, 1))
        supports = minimal_function_supports(domain, lambda s: s[0])
        self.assertEqual(supports, frozenset({frozenset({0}), frozenset({1})}))
        self.assertNotIn(frozenset(), supports)

    def test_20_full_product_restores_unique_minimal_function_support(self):
        domain = tuple(product((0, 1), repeat=2))
        self.assertEqual(
            minimal_function_supports(domain, lambda s: s[0]),
            frozenset({frozenset({0})}),
        )

    def test_21_autonomous_site_carrier_changes_under_sampling(self):
        self.assertEqual(self.ring.ancestor_closure({0}), frozenset({0, 1, 2}))
        self.assertEqual(self.ring.sampled(3).ancestor_closure({0}), frozenset({0}))

    def test_22_minimal_autonomous_site_counts_are_grain_sensitive(self):
        counts = [len(self.ring.sampled(k).minimal_nonempty_autonomous_sets()) for k in range(1, 7)]
        self.assertEqual(counts, [1, 1, 3, 1, 1, 3])

    def test_23_unrolled_permutation_network_retains_three_information_lanes(self):
        components = self.ring.unrolled_components(6)
        self.assertEqual(len(components), 3)
        self.assertEqual({len(c) for c in components}, {7})
        # Every stream visits every site; hardware-site overlap is not event identity.
        for component in components:
            self.assertEqual({site for site, time in component}, {0, 1, 2})

    def test_24_sampling_ring_endpoints_can_preserve_lane_count_with_provenance(self):
        micro_components = self.ring.unrolled_components(6)
        macro_components = self.ring.sampled(3).unrolled_components(2)
        self.assertEqual(len(micro_components), len(macro_components))
        for macro in macro_components:
            endpoints = {(site, 3 * time) for site, time in macro}
            containing = [micro for micro in micro_components if endpoints.issubset(micro)]
            self.assertEqual(len(containing), 1)

    def test_25_common_clock_merges_weak_causal_components(self):
        clocked = BitNetwork.from_function(3, lambda s: (s[0] ^ s[2], s[1] ^ s[2], s[2]))
        self.assertEqual(len(clocked.unrolled_components(3)), 1)
        self.assertEqual(clocked.ancestor_closure({0}), frozenset({0, 2}))
        self.assertEqual(clocked.ancestor_closure({1}), frozenset({1, 2}))

    def test_26_declared_clock_port_separates_conditional_internal_streams(self):
        clocked = BitNetwork.from_function(3, lambda s: (s[0] ^ s[2], s[1] ^ s[2], s[2]))
        ports = frozenset({2})
        self.assertEqual(len(clocked.unrolled_components(3, ports=ports)), 2)
        self.assertEqual(clocked.ancestor_closure({0}, ports=ports), frozenset({0}))
        self.assertTrue(clocked.autonomous({0}, ports=ports))
        self.assertFalse(clocked.autonomous({0}))

    def test_27_port_relative_closure_is_minimal_in_clock_example(self):
        clocked = BitNetwork.from_function(3, lambda s: (s[0] ^ s[2], s[1] ^ s[2], s[2]))
        ports = frozenset({2})
        closed = clocked.autonomous_sets(ports=ports)
        for target in (frozenset({0}), frozenset({1}), frozenset({0, 1})):
            closure = clocked.ancestor_closure(target, ports=ports)
            self.assertTrue(all(closure.issubset(a) for a in closed if target.issubset(a)))

    def test_28_causal_link_connectivity_is_not_automatically_subjecthood(self):
        coupled = BitNetwork.from_function(2, lambda s: (s[0] ^ s[1], s[0]))
        self.assertEqual(len(coupled.unrolled_components(2)), 1)
        self.assertEqual(coupled.ancestor_closure({0}), frozenset({0, 1}))
        # No assertion about consciousness follows; this is the documented boundary.


if __name__ == "__main__":
    unittest.main(verbosity=2)
