
# TRAINING ANALYSES

# figures will be saved here:
base_path <- "~/Library/CloudStorage/GoogleDrive-sshelat@ucsb.edu/My Drive/PhD/Project: MWAC final/figures/"

# view total number of training blocks per subject

master.df.learn.exp1 %>% 
  group_by(subjectID) %>% 
  summarize(max_block_number = max(block_number)) %>% 
  arrange(desc(max_block_number)) %>% 
  print(n=100)

master.df.learn.exp2 %>% 
  group_by(subjectID) %>% 
  summarize(max_block_number = max(block_number)) %>% 
  arrange(desc(max_block_number)) %>% 
  print(n=100)

# ANALYSIS: rt by reward condition and trial number [preregistered]

lmer.rt_reward_trial_exp1 <- lmer(rt ~ reward_condition * trial_number_all + (1 | subjectID),
                             data = master.df.learn.exp1)

lmer.rt_reward_trial_exp2 <- lmer(rt ~ reward_condition * trial_number_all + (1 | subjectID),
                                  data = master.df.learn.exp2)

summary(lmer.rt_reward_trial_exp1)
summary(lmer.rt_reward_trial_exp2)

preds_exp1 <- ggpredict(lmer.rt_reward_trial_exp1, terms = c("trial_number_all", "reward_condition"))
preds_exp2 <- ggpredict(lmer.rt_reward_trial_exp2, terms = c("trial_number_all", "reward_condition"))

rt_per_trial_exp1 <- master.df.learn.exp1 %>%              
  select(trial_number_all, reward_condition, rt) %>%
  group_by(trial_number_all, reward_condition) %>%    
  summarise(mean_RT = mean(rt, na.rm = TRUE),        
            .groups = "drop")

rt_per_trial_exp2 <- master.df.learn.exp2 %>%              
  select(trial_number_all, reward_condition, rt) %>%
  group_by(trial_number_all, reward_condition) %>%    
  summarise(mean_RT = mean(rt, na.rm = TRUE),        
            .groups = "drop")

plot_exp1 <- ggplot() +
  geom_line(
  data = preds_exp1,
  aes(x = x, y = predicted, color = group),
  linewidth = 1
) +
  geom_ribbon(
    data = preds_exp1,
    aes(x = x, ymin = conf.low, ymax = conf.high, fill = group),
    alpha = .15, colour = NA
  ) +
  geom_point(
  data = rt_per_trial_exp1,
  aes(x = trial_number_all, y = mean_RT, color = reward_condition),
  size = 1.4, alpha = .1
) +
  scale_colour_manual(
  values = c("0" = "#7E7E7E", "1" = "#29AB87"),
  labels = c("unrewarded", "rewarded")
) +
  scale_fill_manual(
    values = c("0" = "#7E7E7E", "1" = "#29AB87"),
    labels = c("unrewarded", "rewarded")
  ) +
  labs(
  title = "Experiment 1",
  x     = "Trial",
  y     = "RT (ms)"
) +
  theme_classic2() +
  cowplot::theme_cowplot(font_size = 12) +
  theme(
    legend.title        = element_blank(),
    legend.position     = c(0.02, 0.02),
    legend.justification = c(0, 0),
    legend.background   = element_rect(fill = NA),
    plot.title          = element_text(face = "plain")
  ) +
  ylim(480, 730)

plot_exp2 <- ggplot() +
  geom_line(
    data = preds_exp2,
    aes(x = x, y = predicted, color = group),
    linewidth = 1
  ) +
  geom_ribbon(
    data = preds_exp2,
    aes(x = x, ymin = conf.low, ymax = conf.high, fill = group),
    alpha = .15, colour = NA
  ) +
  geom_point(
    data = rt_per_trial_exp2,
    aes(x = trial_number_all, y = mean_RT, color = reward_condition),
    size = 1.4, alpha = .1
  ) +
  scale_colour_manual(
    values = c("0" = "#7E7E7E", "1" = "#29AB87"),
    labels = c("unrewarded", "rewarded")
  ) +
  scale_fill_manual(
    values = c("0" = "#7E7E7E", "1" = "#29AB87"),
    labels = c("unrewarded", "rewarded")
  ) +
  labs(
    title = "Experiment 2",
    x     = "Trial",
    y     = NULL
  ) +
  theme_classic2() +
  cowplot::theme_cowplot(font_size = 12) +
  theme(
    legend.position = "none",
    plot.title = element_text(face = "plain")
  ) +
  ylim(480, 730)

combined_plot <- cowplot::plot_grid(
  plot_exp1, plot_exp2,
  labels     = c("a", "b"),
  label_size = 14,
  ncol       = 2,
  align      = 'hv',
  axis       = 'tblr'
)

combined_plot

ggsave(
  filename = file.path(base_path, "training_task_performance.png"),
  plot     = combined_plot,
  width    = 6.4,
  height   = 4,
  dpi      = 700
)

# DECLUTTER!

rm(list = setdiff(ls(), c(
  "master.df.learn.exp1",
  "master.df.learn.exp2",
  "master.df.sart.exp1",
  "master.df.sart.exp2",
  "master.df.sart.exp1.firsthalf",
  "master.df.sart.exp2.firsthalf",
  "master.traits"
)))

