

# PREPPING: specify functions for later

extract_lmer_model_info <- function(model) {
  fixed_effects <- broom.mixed::tidy(model)
  ci <- as.data.frame(confint(model, method = "Wald"))
  ci <- tibble::rownames_to_column(ci, "term")
  
  fixed_effects <- fixed_effects %>%
    dplyr::filter(effect == "fixed") %>%
    dplyr::left_join(ci, by = "term") %>%
    dplyr::rename(conf.low = `2.5 %`, conf.high = `97.5 %`)
  
  r_squared <- MuMIn::r.squaredGLMM(model)
  
  r2_marginal <- r_squared[1, "R2m"]
  r2_conditional <- r_squared[1, "R2c"]
  
  table_df <- tibble::tibble(
    Term = fixed_effects$term,
    Est_Beta = as.character(round(fixed_effects$estimate, 4)),
    SE = as.character(round(fixed_effects$std.error, 4)),
    `95% CI` = paste0("[", round(fixed_effects$conf.low, 4), ", ", round(fixed_effects$conf.high, 4), "]"),
    t = as.character(round(fixed_effects$statistic, 4)),
    p = format.pval(fixed_effects$p.value, digits = 10)
  )
  
  dplyr::bind_rows(
    table_df,
    tibble::tibble(
      Term = "R² Marginal",
      Est_Beta = as.character(round(r2_marginal, 4)),
      SE = NA, `95% CI` = NA, t = NA, p = NA
    ),
    tibble::tibble(
      Term = "R² Conditional",
      Est_Beta = as.character(round(r2_conditional, 4)),
      SE = NA, `95% CI` = NA, t = NA, p = NA
    )
  )
}

extract_logit_model_info <- function(model) {
  fixed_effects <- broom.mixed::tidy(model)
  ci <- as.data.frame(confint(model, method = "Wald"))
  ci <- tibble::rownames_to_column(ci, "term")
  
  fixed_effects <- fixed_effects %>%
    dplyr::filter(effect == "fixed") %>%
    dplyr::left_join(ci, by = "term") %>%
    dplyr::rename(conf.low = `2.5 %`, conf.high = `97.5 %`)
  
  r_squared <- MuMIn::r.squaredGLMM(model)
  
  r2_marginal <- r_squared["theoretical", "R2m"]
  r2_conditional <- r_squared["theoretical", "R2c"]
  
  table_df <- tibble::tibble(
    Term = fixed_effects$term,
    Est_Beta = as.character(round(fixed_effects$estimate, 4)),
    SE = as.character(round(fixed_effects$std.error, 4)),
    `95% CI` = paste0("[", round(fixed_effects$conf.low, 4), ", ", round(fixed_effects$conf.high, 4), "]"),
    z = as.character(round(fixed_effects$statistic, 4)),
    p = format.pval(fixed_effects$p.value, digits = 10)
  )
  
  dplyr::bind_rows(
    table_df,
    tibble::tibble(
      Term = "R² Marginal",
      Est_Beta = as.character(round(r2_marginal, 4)),
      SE = NA, `95% CI` = NA, z = NA, p = NA
    ),
    tibble::tibble(
      Term = "R² Conditional",
      Est_Beta = as.character(round(r2_conditional, 4)),
      SE = NA, `95% CI` = NA, z = NA, p = NA
    )
  )
}

# EXTRA PROCESSING BEFORE YOU START ANALYSIS HERE:

# stack dfs for high powered combined analyses

master.df.sart.combined <- bind_rows(master.df.sart.exp1, master.df.sart.exp2)

# label exp1 data with same_day vs. week_later

same_day_subjects <- c("25", "26", "27", "28", "29", "30", "31", "32", "33", "34",
                       "35", "36", "37", "38", "39", "40", "41", "42", "43", "44",
                       "45", "46", "47", "48", "49", "52")
master.df.sart.exp1$delay_condition <- ifelse(master.df.sart.exp1$subjectID %in% same_day_subjects, 
                                      "same_day", "week_later")

# SART ANALYSES

# figures will be saved here:
base_path <- "~/Library/CloudStorage/GoogleDrive-sshelat@ucsb.edu/My Drive/PhD/Project: MWAC final/figures/"

# view total number of sart blocks per subject

master.df.sart.exp1 %>% 
  group_by(subjectID) %>% 
  summarize(max_block_number = max(block_number)) %>% 
  arrange(desc(max_block_number)) %>% 
  print(n=100)

master.df.sart.exp2 %>% 
  group_by(subjectID) %>% 
  summarize(max_block_number = max(block_number)) %>% 
  arrange(desc(max_block_number)) %>% 
  print(n=100)

# combine exp1 and exp2 into one table, then compute per‐subject counts and summary by experiment

trigger_counts <- bind_rows(
  master.df.sart.exp1 %>% mutate(experiment = "exp1"),
  master.df.sart.exp2 %>% mutate(experiment = "exp2")
  ) %>%
  group_by(experiment, subjectID, trigger, distractor_feature) %>%
  summarise(count = n(), .groups = "drop") %>%
  group_by(experiment, trigger, distractor_feature) %>%
  summarise(
    mean_count = mean(count, na.rm = TRUE),
    sd_count   = sd(count,   na.rm = TRUE),
    .groups    = "drop"
  )

print(trigger_counts)

write.csv(
  trigger_counts,
  file = "/Users/shibushelat/Library/CloudStorage/GoogleDrive-sshelat@ucsb.edu/My Drive/PhD/Project: MWAC final/tables/trigger_descriptives_by_distractor_type_by_experiment.csv",
  row.names = FALSE
)

# wide version of trigger counts table

trigger_counts_wide <- trigger_counts %>%
  arrange(trigger, distractor_feature) %>%
  pivot_wider(
    names_from  = experiment,
    values_from = c(mean_count, sd_count),
    names_glue  = "{.value}_{experiment}"  
  )

print(trigger_counts_wide)

write_csv(
  trigger_counts_wide,
  "/Users/shibushelat/Library/CloudStorage/GoogleDrive-sshelat@ucsb.edu/My Drive/PhD/Project: MWAC final/tables/trigger_descriptives_by_distractor_type_by_experiment_WIDE.csv"
)

# ANALYSIS: task code check - trailing window by trigger type [not preregistered]

# summarise performance by trigger for each experiment (for plotting)
performance_by_triggers_exp1 <- master.df.sart.exp1 %>%
  group_by(subjectID, trigger) %>%
  summarise(
    prop_accurate        = mean(accuracy, na.rm = TRUE),
    avg_trailing_rt_mean = mean(trailing_rt_mean, na.rm = TRUE),
    .groups = "drop"
  )

performance_by_triggers_exp2 <- master.df.sart.exp2 %>%
  group_by(subjectID, trigger) %>%
  summarise(
    prop_accurate        = mean(accuracy, na.rm = TRUE),
    avg_trailing_rt_mean = mean(trailing_rt_mean, na.rm = TRUE),
    .groups = "drop"
  )

model_trailrt_exp1 <- lmer(trailing_rt_mean ~ trigger + (1 | subjectID),
                           data = master.df.sart.exp1)
summary(model_trailrt_exp1)

model_trailrt_exp2 <- lmer(trailing_rt_mean ~ trigger + (1 | subjectID),
                           data = master.df.sart.exp2)
summary(model_trailrt_exp2)

# build the two plots
plot.trailrt_exp1 <- ggplot(performance_by_triggers_exp1,
                            aes(x = trigger, y = avg_trailing_rt_mean, fill = trigger)) +
  stat_summary(fun.data = mean_se, geom = "bar",
               position = position_dodge(0.3), width = 0.75) +
  stat_summary(fun.data = mean_se, geom = "errorbar",
               position = position_dodge(0.3), width = 0) +
  geom_line(aes(group = subjectID),
            position = position_dodge(0.3), alpha = 0.1) +
  labs(title = "Experiment 1",
       x = "Trigger",
       y = "Trailing Window RT Mean (ms)") +
  theme_classic2() +
  cowplot::theme_cowplot(font_size = 12) +
  scale_fill_manual(values = c("fast" = "#bdbdbd", "slow" = "#dfdfdf")) +
  theme(legend.position   = "none",
        plot.title        = element_text(face = "plain"))

plot.trailrt_exp2 <- ggplot(performance_by_triggers_exp2,
                            aes(x = trigger, y = avg_trailing_rt_mean, fill = trigger)) +
  stat_summary(fun.data = mean_se, geom = "bar",
               position = position_dodge(0.3), width = 0.75) +
  stat_summary(fun.data = mean_se, geom = "errorbar",
               position = position_dodge(0.3), width = 0) +
  geom_line(aes(group = subjectID),
            position = position_dodge(0.3), alpha = 0.1) +
  labs(title = "Experiment 2",
       x = "Trigger",
       y = NULL) +
  theme_classic2() +
  cowplot::theme_cowplot(font_size = 12) +
  scale_fill_manual(values = c("fast" = "#bdbdbd", "slow" = "#dfdfdf")) +
  theme(legend.position   = "none",
        plot.title        = element_text(face = "plain"))

combined_plot_trailrt <- cowplot::plot_grid(
  plot.trailrt_exp1, plot.trailrt_exp2,
  labels     = c("a", "b"),
  label_size = 14,
  ncol       = 2
)

combined_plot_trailrt

ggsave(
  filename = file.path(base_path, "trailing_rt_by_trigger.png"),
  plot     = combined_plot_trailrt,
  width    = 4,
  height   = 4,
  dpi      = 700
)

# ANALYSIS: accuracy by trigger type [preregistered]

logit.accuracy_trigger_exp1 <- glmer(
  accuracy ~ trigger + (1 | subjectID),
  family  = binomial(link = "logit"),
  data    = master.df.sart.exp1,
  control = glmerControl(optimizer = "bobyqa", optCtrl = list(maxfun = 1e5))
)
summary(logit.accuracy_trigger_exp1)

logit.accuracy_trigger_exp2 <- glmer(
  accuracy ~ trigger + (1 | subjectID),
  family  = binomial(link = "logit"),
  data    = master.df.sart.exp2,
  control = glmerControl(optimizer = "bobyqa", optCtrl = list(maxfun = 1e5))
)
summary(logit.accuracy_trigger_exp2)

# build the two accuracy‐by‐trigger plots
plot.accuracy_trigger_exp1 <- ggplot(performance_by_triggers_exp1,
                                     aes(x = trigger, y = prop_accurate, fill = trigger)) +
  stat_summary(fun.data = mean_se, geom = "bar",
               position = position_dodge(0.3), width = 0.75) +
  stat_summary(fun.data = mean_se, geom = "errorbar",
               position = position_dodge(0.3), width = 0) +
  geom_line(aes(group = subjectID),
            position = position_dodge(0.3), alpha = 0.1) +
  labs(title = "Experiment 1",
       x     = "Trigger",
       y     = "p(correct)") +
  theme_classic2() +
  cowplot::theme_cowplot(font_size = 12) +
  scale_fill_manual(values = c("fast" = "#bdbdbd", "slow" = "#dfdfdf")) +
  theme(
    legend.position = "none",
    plot.title      = element_text(face = "plain")
  )

plot.accuracy_trigger_exp2 <- ggplot(performance_by_triggers_exp2,
                                     aes(x = trigger, y = prop_accurate, fill = trigger)) +
  stat_summary(fun.data = mean_se, geom = "bar",
               position = position_dodge(0.3), width = 0.75) +
  stat_summary(fun.data = mean_se, geom = "errorbar",
               position = position_dodge(0.3), width = 0) +
  geom_line(aes(group = subjectID),
            position = position_dodge(0.3), alpha = 0.1) +
  labs(title = "Experiment 2",
       x     = "Trigger",
       y     = NULL) +
  theme_classic2() +
  cowplot::theme_cowplot(font_size = 12) +
  scale_fill_manual(values = c("fast" = "#bdbdbd", "slow" = "#dfdfdf")) +
  theme(
    legend.position = "none",
    plot.title      = element_text(face = "plain")
  )

combined_plot_accuracy <- cowplot::plot_grid(
  plot.accuracy_trigger_exp1, plot.accuracy_trigger_exp2,
  labels     = c("a", "b"),
  label_size = 14,
  ncol       = 2,
  align      = 'hv',
  axis       = 'tblr'
)

print(combined_plot_accuracy)

ggsave(
  filename = file.path(base_path, "accuracy_by_trigger.png"),
  plot     = combined_plot_accuracy,
  width    = 4,
  height   = 4,
  dpi      = 700
)

# ────────────────────────────────────────────────────────────────────────────────
# ANALYSIS: accuracy by block 
# exp1 prereg: Infrequent trial accuracy will not improve over time, and this will not depend on the distractor present during infrequent trials (test phase).
# exp2 prereg: (none)
# ────────────────────────────────────────────────────────────────────────────────

# EXP1
logit.accuracy_block_exp1 <- glmer(
  accuracy ~ block_number + (1 | subjectID),
  family  = binomial(link = "logit"),
  data    = master.df.sart.exp1,
  control = glmerControl(optimizer = "bobyqa", optCtrl = list(maxfun = 1e5))
)
summary(logit.accuracy_block_exp1)

# EXP2
logit.accuracy_block_exp2 <- glmer(
  accuracy ~ block_number + (1 | subjectID),
  family  = binomial(link = "logit"),
  data    = master.df.sart.exp2,
  control = glmerControl(optimizer = "bobyqa", optCtrl = list(maxfun = 1e5))
)
summary(logit.accuracy_block_exp2)

# BOTH
logit.accuracy_block_both <- glmer(
  accuracy ~ block_number + (1 | subjectID),
  family  = binomial(link = "logit"),
  data    = master.df.sart.combined,
  control = glmerControl(optimizer = "bobyqa", optCtrl = list(maxfun = 1e5))
)
summary(logit.accuracy_block_both)

# ────────────────────────────────────────────────────────────────────────────────
# ANALYSIS: accuracy by block × distractor_feature 
# exp1 prereg: Infrequent trial accuracy will not improve over time, and this will not depend on the distractor present during infrequent trials (test phase).
# exp2 prereg: (none)
# ────────────────────────────────────────────────────────────────────────────────

# EXP1
logit.acc_block_dist_exp1 <- glmer(
  accuracy ~ block_number * distractor_feature + (1 | subjectID),
  family  = binomial(link = "logit"),
  data    = master.df.sart.exp1,
  control = glmerControl(optimizer="bobyqa", optCtrl=list(maxfun=1e5))
)
summary(logit.acc_block_dist_exp1)

# EXP2
logit.acc_block_dist_exp2 <- glmer(
  accuracy ~ block_number * distractor_feature + (1 | subjectID),
  family  = binomial(link = "logit"),
  data    = master.df.sart.exp2,
  control = glmerControl(optimizer="bobyqa", optCtrl=list(maxfun=1e5))
)
summary(logit.acc_block_dist_exp2)

# BOTH
logit.acc_block_dist_both <- glmer(
  accuracy ~ block_number * distractor_feature + (1 | subjectID),
  family  = binomial(link = "logit"),
  data    = master.df.sart.combined,
  control = glmerControl(optimizer="bobyqa", optCtrl=list(maxfun=1e5))
)
summary(logit.acc_block_dist_both)

# ────────────────────────────────────────────────────────────────────────────────
# ANALYSIS: accuracy by block × distractor_feature × trigger
# exp1 prereg: (none)
# exp2 prereg: Infrequent trial accuracy across trigger types will be increased by value-associated distractors in early blocks, and this enhancement should decline over time (test phase).
# ────────────────────────────────────────────────────────────────────────────────

# EXP1
logit.acc_block_dist_trig_exp1 <- glmer(
  accuracy ~ block_number * distractor_feature * trigger + (1 | subjectID),
  family  = binomial(link = "logit"),
  data    = master.df.sart.exp1,
  control = glmerControl(optimizer="bobyqa", optCtrl=list(maxfun=1e5))
)
summary(logit.acc_block_dist_trig_exp1)

# EXP2
logit.acc_block_dist_trig_exp2 <- glmer(
  accuracy ~ block_number * distractor_feature * trigger + (1 | subjectID),
  family  = binomial(link = "logit"),
  data    = master.df.sart.exp2,
  control = glmerControl(optimizer="bobyqa", optCtrl=list(maxfun=1e5))
)
summary(logit.acc_block_dist_trig_exp2)

# BOTH
logit.acc_block_dist_trig_both <- glmer(
  accuracy ~ block_number * distractor_feature * trigger + (1 | subjectID),
  family  = binomial(link = "logit"),
  data    = master.df.sart.combined,
  control = glmerControl(optimizer="bobyqa", optCtrl=list(maxfun=1e5))
)
summary(logit.acc_block_dist_trig_both)

table.logit.acc_block_dist_trig_both <- extract_logit_model_info(logit.acc_block_dist_trig_both)  

write.csv(
  table.logit.acc_block_dist_trig_both,
  file = "~/Library/CloudStorage/GoogleDrive-sshelat@ucsb.edu/My Drive/PhD/Project: MWAC final/tables/table.logit.acc_block_dist_trig_both.csv",
  row.names = FALSE
)

# PLOT

pred_acc_block_dist_trig_exp1 <- ggpredict(
  logit.acc_block_dist_trig_exp1,
  terms = c("block_number", "distractor_feature", "trigger")
)

pred_acc_block_dist_trig_exp2 <- ggpredict(
  logit.acc_block_dist_trig_exp2,
  terms = c("block_number", "distractor_feature", "trigger")
)

plot.acc_block_dist_trig_exp1 <- ggplot(pred_acc_block_dist_trig_exp1, 
                                        aes(x = x, y = predicted,
                                            color = group, fill = group)) +
  geom_line(linewidth = 1) +
  geom_ribbon(aes(ymin = conf.low, ymax = conf.high),
              alpha = 0.15, color = NA) +
  facet_wrap(~ facet, scales = "free_x") +
  scale_y_continuous(
    limits = c(0.23, 0.91),
    breaks = seq(0.3, 0.9, by = 0.1)
  ) +
  scale_color_manual(values = c(
    neutral   = "#a2a2a2",
    selection = "#5A5A5A",
    novel     = "#FFB000",
    reward    = "#29AB87"
  )) +
  scale_fill_manual(values = c(
    neutral   = "#a2a2a2",
    selection = "#5A5A5A",
    novel     = "#FFB000",
    reward    = "#29AB87"
  )) +
  labs(title = "Experiment 1", x = "Block", y = "p(correct)") +
  theme_classic2() +
  cowplot::theme_cowplot(font_size = 12) +
  theme(
    plot.title        = element_text(face = "plain"),
    legend.title      = element_blank(),
    legend.position   = c(0.9, 0.1), 
    legend.justification = c(1, 0),
    legend.background = element_rect(fill = NA),
    strip.background  = element_rect(fill = "#F1F1F1", colour = "#F1F1F1")
  )

plot.acc_block_dist_trig_exp2 <- ggplot(pred_acc_block_dist_trig_exp2, 
                                        aes(x = x, y = predicted,
                                            color = group, fill = group)) +
  geom_line(linewidth = 1) +
  geom_ribbon(aes(ymin = conf.low, ymax = conf.high),
              alpha = 0.15, color = NA) +
  facet_wrap(~ facet, scales = "free_x") +
  scale_y_continuous(
    limits = c(0.23, 0.91),
    breaks = seq(0.3, 0.9, by = 0.1)
  ) +
  scale_color_manual(values = c(
    neutral   = "#a2a2a2",
    selection = "#5A5A5A",
    novel     = "#FFB000",
    reward    = "#29AB87"
  )) +
  scale_fill_manual(values = c(
    neutral   = "#a2a2a2",
    selection = "#5A5A5A",
    novel     = "#FFB000",
    reward    = "#29AB87"
  )) +
  labs(title = "Experiment 2", x = "Block", y = NULL) +
  theme_classic2() +
  cowplot::theme_cowplot(font_size = 12) +
  theme(
    plot.title        = element_text(face = "plain"),
    legend.position   = "none",
    strip.background  = element_rect(fill = "#F1F1F1", colour = "#F1F1F1")
  )

combined_plot_acc_block_dist_trig <- cowplot::plot_grid(
  plot.acc_block_dist_trig_exp1, plot.acc_block_dist_trig_exp2,
  labels     = c("a", "b"),
  label_size = 14,
  ncol       = 2,
  align      = 'hv',
  axis       = 'tblr'
)

print(combined_plot_acc_block_dist_trig)

ggsave(
  filename = file.path(base_path, "accuracy_by_block_distractor_trigger.png"),
  plot     = combined_plot_acc_block_dist_trig,
  width    = 7,
  height   = 4,
  dpi      = 700
)

# ────────────────────────────────────────────────────────────────────────────────
# ANALYSIS: accuracy by block × distractor_feature × trigger × delay_condition (exploratory)
# exp1 prereg: registered as exploratory
# exp2 prereg: not applicable since they were all same_day
# ────────────────────────────────────────────────────────────────────────────────

logit.acc_block_dist_trig_delay_exp1 <- glmer(
  accuracy ~ block_number * distractor_feature * trigger * delay_condition + (1 | subjectID),
  family  = binomial(link = "logit"),
  data    = master.df.sart.exp1,
  control = glmerControl(optimizer="bobyqa", optCtrl=list(maxfun=1e5))
)
summary(logit.acc_block_dist_trig_delay_exp1)

# ────────────────────────────────────────────────────────────────────────────────
# ANALYSIS: RT × distractor_feature × accuracy (capture suppression hypothesis)
# exp1 prereg: RT will differ when a reward‐associated distractor is present during inaccurate vs. accurate trials.
# exp2 prereg: (none)
# ────────────────────────────────────────────────────────────────────────────────

# EXP1
lmer.rt_dist_accuracy_exp1 <- lmer(
  rt ~ distractor_feature * accuracy + (1 | subjectID),
  data = master.df.sart.exp1
)
summary(lmer.rt_dist_accuracy_exp1)

# EXP2
lmer.rt_dist_accuracy_exp2 <- lmer(
  rt ~ distractor_feature * accuracy + (1 | subjectID),
  data = master.df.sart.exp2
)
summary(lmer.rt_dist_accuracy_exp2)

# BOTH
lmer.rt_dist_accuracy_both <- lmer(
  rt ~ distractor_feature * accuracy + (1 | subjectID),
  data = master.df.sart.combined
)
summary(lmer.rt_dist_accuracy_both)

# ────────────────────────────────────────────────────────────────────────────────
# ANALYSIS: RT × k × distractor_feature × accuracy (WM capacity moderation)
# exp1 prereg: Working memory capacity will affect RT differences based on distractor presence during inaccurate vs. accurate trials (test phase).
# exp2 prereg: (none)
# ────────────────────────────────────────────────────────────────────────────────

# EXP1
lmer.rt_dist_accuracy_k_exp1 <- lmer(
  rt ~ k * distractor_feature * accuracy + (1 | subjectID),
  data = master.df.sart.exp1
)
summary(lmer.rt_dist_accuracy_k_exp1)

# EXP2
lmer.rt_dist_accuracy_k_exp2 <- lmer(
  rt ~ k * distractor_feature * accuracy + (1 | subjectID),
  data = master.df.sart.exp2
)
summary(lmer.rt_dist_accuracy_k_exp2)

# BOTH
lmer.rt_dist_accuracy_k_both <- lmer(
  rt ~ k * distractor_feature * accuracy + (1 | subjectID),
  data = master.df.sart.combined
)
summary(lmer.rt_dist_accuracy_k_both)

# ────────────────────────────────────────────────────────────────────────────────
# ANALYSIS: first‑half accuracy ~ trigger × distractor_feature × magnitude_learning
# exp1 prereg: (none)
# exp2 prereg: The early capture-enhancement effect should be most pronounced for those with a strong color-reward association from the learning task during fast-triggered rare trials.
# ────────────────────────────────────────────────────────────────────────────────

# EXP1
logit.firsthalf.acc_trig_dist_mag_exp1 <- glmer(
  accuracy ~ trigger * distractor_feature * magnitude_learning + (1 | subjectID),
  family  = binomial(link = "logit"),
  data    = master.df.sart.exp1.firsthalf,
  control = glmerControl(optimizer="bobyqa", optCtrl=list(maxfun=1e5))
)
summary(logit.firsthalf.acc_trig_dist_mag_exp1)

# EXP2
logit.firsthalf.acc_trig_dist_mag_exp2 <- glmer(
  accuracy ~ trigger * distractor_feature * magnitude_learning + (1 | subjectID),
  family  = binomial(link = "logit"),
  data    = master.df.sart.exp2.firsthalf,
  control = glmerControl(optimizer="bobyqa", optCtrl=list(maxfun=1e5))
)
summary(logit.firsthalf.acc_trig_dist_mag_exp2)

# BOTH
logit.firsthalf.acc_trig_dist_mag_both <- glmer(
  accuracy ~ trigger * distractor_feature * magnitude_learning + (1 | subjectID),
  family  = binomial(link = "logit"),
  data    = bind_rows(
    master.df.sart.exp1.firsthalf  %>% mutate(experiment="exp1"),
    master.df.sart.exp2.firsthalf  %>% mutate(experiment="exp2")
  ),
  control = glmerControl(optimizer="bobyqa", optCtrl=list(maxfun=2e5))
)

isSingular(logit.firsthalf.acc_trig_dist_mag_both)

summary(logit.firsthalf.acc_trig_dist_mag_both)

table.logit.firsthalf.acc_trig_dist_mag_both <- extract_logit_model_info(logit.firsthalf.acc_trig_dist_mag_both)

write.csv(
  table.logit.firsthalf.acc_trig_dist_mag_both,
  file = "~/Library/CloudStorage/GoogleDrive-sshelat@ucsb.edu/My Drive/PhD/Project: MWAC final/tables/table.logit.firsthalf.acc_trig_dist_mag_both.csv",
  row.names = FALSE
)

# PLOT

pred_exp1 <- ggpredict(
  logit.firsthalf.acc_trig_dist_mag_exp1,
  terms = c("magnitude_learning", "distractor_feature", "trigger")
)
pred_exp2 <- ggpredict(
  logit.firsthalf.acc_trig_dist_mag_exp2,
  terms = c("magnitude_learning", "distractor_feature", "trigger")
)

plot_exp1 <- ggplot(pred_exp1, aes(x = x, y = predicted, color = group, fill = group)) +
  geom_line(linewidth = 1) +
  geom_ribbon(aes(ymin = conf.low, ymax = conf.high), alpha = 0.15, color = NA) +
  geom_vline(xintercept = 0, linetype = "dotted", color = "black") +
  facet_wrap(~ facet, scales = "free_x", strip.position = "top") +
  scale_y_continuous(
    limits = c(0.1, 1),
    breaks = seq(0.1, 1, by = 0.1),
    expand = expansion(mult = c(0, 0))
  ) +
  labs(
    title = "Experiment 1",
    x     = "Reward Learning Magnitude",
    y     = "p(correct)"
  ) +
  scale_color_manual(
    values = c(
      neutral   = "#a2a2a2",
      selection = "#5A5A5A",
      novel     = "#FFB000",
      reward    = "#29AB87"
    ),
    breaks = c("neutral", "selection", "novel", "reward")
  ) +
  scale_fill_manual(
    values = c(
      neutral   = "#a2a2a2",
      selection = "#5A5A5A",
      novel     = "#FFB000",
      reward    = "#29AB87"
    ),
    breaks = c("neutral", "selection", "novel", "reward")
  ) +
  theme_classic2() +
  cowplot::theme_cowplot(font_size = 12) +
  theme(
    plot.title         = element_text(face = "plain"),
    strip.background   = element_rect(fill = "#F1F1F1", colour = "#F1F1F1"),
    panel.spacing      = unit(1, "lines"),             
    legend.title       = element_blank(),
    legend.position    = c(0.95, 0.05),                
    legend.justification = c(1, 0),
    plot.margin        = margin(t = 5, r = 10, b = 5, l = 5) 
  )

# EXP2
plot_exp2 <- ggplot(pred_exp2, aes(x = x, y = predicted, color = group, fill = group)) +
  geom_line(linewidth = 1) +
  geom_ribbon(aes(ymin = conf.low, ymax = conf.high), alpha = 0.15, color = NA) +
  geom_vline(xintercept = 0, linetype = "dotted", color = "black") +
  facet_wrap(~ facet, scales = "free_x", strip.position = "top") +
  scale_y_continuous(
    limits = c(0.1, 1),
    breaks = seq(0.1, 1, by = 0.1),
    expand = expansion(mult = c(0, 0))
  ) +
  labs(
    title = "Experiment 2",
    x     = "Reward Learning Magnitude",
    y     = NULL
  ) +
  scale_color_manual(
    values = c(
      neutral   = "#a2a2a2",
      selection = "#5A5A5A",
      novel     = "#FFB000",
      reward    = "#29AB87"
    ),
    breaks = c("neutral", "selection", "novel", "reward")
  ) +
  scale_fill_manual(
    values = c(
      neutral   = "#a2a2a2",
      selection = "#5A5A5A",
      novel     = "#FFB000",
      reward    = "#29AB87"
    ),
    breaks = c("neutral", "selection", "novel", "reward")
  ) +
  theme_classic2() +
  cowplot::theme_cowplot(font_size = 12) +
  theme(
    plot.title         = element_text(face = "plain"),
    strip.background   = element_rect(fill = "#F1F1F1", colour = "#F1F1F1"),
    panel.spacing      = unit(1, "lines"),
    legend.position    = "none",
    plot.margin        = margin(t = 5, r = 10, b = 5, l = 5)
  )

# COMBINED
combined_plot <- cowplot::plot_grid(
  plot_exp1, plot_exp2,
  labels     = c("a", "b"),
  label_size = 14,
  ncol       = 2,
  align      = 'hv',
  axis       = 'tblr'
)

print(combined_plot)

ggsave(
  filename = file.path(base_path, "firsthalf_capture_enhancement.png"),
  plot     = combined_plot,
  width    = 8.5,
  height   = 4,
  dpi      = 700
)

