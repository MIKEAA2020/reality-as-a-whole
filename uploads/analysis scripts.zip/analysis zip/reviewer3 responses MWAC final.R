
library(simr)

# how do you know trial counts are adequate?
# precedent can be found in a previous PBR paper that used triggering: Roberts et al. 2024

df_roberts <- read.csv(
  "/Users/shibushelat/Library/CloudStorage/GoogleDrive-sshelat@ucsb.edu/My Drive/PhD/Project: MWAC final/writing/revision 1/roberts-2024-PBR-for-reanalysis-for-R3/roberts-2024-PBR-clean-data.csv",
  stringsAsFactors = FALSE,
  check.names = FALSE,
  fileEncoding = "UTF-8"
)

df_roberts <- df_roberts %>%
  dplyr::select(SubjectNum, MatchCond, nHighAttnTrials, nLowAttnTrials)

df_roberts %>%
  dplyr::group_by(MatchCond) %>%
  dplyr::summarise(
    slow_mean = mean(nHighAttnTrials, na.rm = TRUE),
    slow_sd   = sd(nHighAttnTrials,   na.rm = TRUE),
    fast_mean = mean(nLowAttnTrials,  na.rm = TRUE),
    fast_sd   = sd(nLowAttnTrials,    na.rm = TRUE),
    .groups = "drop"
  ) %>%
  tidyr::pivot_longer(
    cols = -MatchCond,
    names_to = c("trigger", ".value"),
    names_pattern = "(slow|fast)_(mean|sd)"
  ) %>%
  readr::write_csv("/Users/shibushelat/Library/CloudStorage/GoogleDrive-sshelat@ucsb.edu/My Drive/PhD/Project: MWAC final/writing/revision 1/roberts-2024-PBR-for-reanalysis-for-R3/roberts-2024-PBR-counts.csv")

# R3: check RT to make a more compelling case that attentional capture happened

lmer.rt_dist <- lmer(rt ~ distractor_feature * trigger + (1 | subjectID), data = master.df.sart.combined)
summary(lmer.rt_dist)

pred_rt_dist <- ggpredict(
  lmer.rt_dist,
  terms = c("distractor_feature", "trigger")
)

rt_by_subj_trig_dist <- master.df.sart.combined %>%
  group_by(subjectID, trigger, distractor_feature) %>%
  summarise(
    mean_rt = mean(rt, na.rm = TRUE),
    .groups = "drop"
  )

plot.rt_dist_pred <- ggplot(
  pred_rt_dist,
  aes(x = x, y = predicted, color = x)
) +
  geom_point(size = 2) +
  geom_errorbar(aes(ymin = conf.low, ymax = conf.high), width = 0) +
  geom_jitter(
    data = rt_by_subj_trig_dist %>% mutate(group = trigger, x = distractor_feature),
    aes(x = x, y = mean_rt, color = x),
    width = 0.12, height = 0,
    alpha = 0.1, size = 1.5,
    inherit.aes = FALSE
  ) +
  facet_wrap(~ group) +
  labs(
    x = "Distractor Feature",
    y = "RT (ms)"
  ) +
  theme_classic2() +
  cowplot::theme_cowplot(font_size = 12) +
  scale_color_manual(values = c(
    neutral   = "#a2a2a2",
    selection = "#5A5A5A",
    novel     = "#FFB000",
    reward    = "#29AB87"
  )) +
  theme(
    legend.title     = element_blank(),
    strip.background = element_rect(fill = "#F1F1F1", colour = "#F1F1F1"),
    plot.title       = element_text(face = "plain")
  )

print(plot.rt_dist_pred)

ggsave(
  filename = file.path(base_path, "rt_by_distractor_trigger.png"),
  plot     = plot.rt_dist_pred,
  width    = 7,
  height   = 4,
  dpi      = 700
)

# version with unique axes per panel + no jittered data

plot.rt_dist_pred_for_letter <- ggplot(
  pred_rt_dist,
  aes(x = x, y = predicted, color = x)
) +
  geom_point(size = 2) +
  geom_errorbar(aes(ymin = conf.low, ymax = conf.high), width = 0) +
  facet_wrap(~ group, scales = "free_y") +
  labs(x = "Distractor Feature", y = "RT (ms)") +
  theme_classic2() +
  cowplot::theme_cowplot(font_size = 12) +
  scale_color_manual(values = c(
    neutral   = "#a2a2a2",
    selection = "#5A5A5A",
    novel     = "#FFB000",
    reward    = "#29AB87"
  )) +
  theme(
    legend.title     = element_blank(),
    strip.background = element_rect(fill = "#F1F1F1", colour = "#F1F1F1"),
    plot.title       = element_text(face = "plain")
  )

print(plot.rt_dist_pred_for_letter)

ggsave(
  filename = file.path(base_path, "rt_by_distractor_trigger_for_letter.png"),
  plot     = plot.rt_dist_pred_for_letter,
  width    = 7,
  height   = 4,
  dpi      = 700
)


# did capture happen across trigger types? I will check accuracy and and RT separated by trigger

logit.acc_fast_trigs_only <- glmer(
  accuracy ~ distractor_feature + (1 | subjectID),
  family  = binomial(link = "logit"),
  data    = master.df.sart.combined %>% filter(trigger == "fast"),
  control = glmerControl(optimizer="bobyqa", optCtrl=list(maxfun=1e5))
)

summary(logit.acc_fast_trigs_only)

logit.acc_slow_trigs_only <- glmer(
  accuracy ~ distractor_feature + (1 | subjectID),
  family  = binomial(link = "logit"),
  data    = master.df.sart.combined %>% filter(trigger == "slow"),
  control = glmerControl(optimizer="bobyqa", optCtrl=list(maxfun=1e5))
)

summary(logit.acc_slow_trigs_only)

lmer.rt_dist_fast_trigs_only <- lmer(rt ~ distractor_feature + (1 | subjectID), 
                                     data = master.df.sart.combined %>% filter(trigger == "fast"))
summary(lmer.rt_dist_fast_trigs_only)

lmer.rt_dist_slow_trigs_only <- lmer(rt ~ distractor_feature + (1 | subjectID), 
                                     data = master.df.sart.combined %>% filter(trigger == "slow"))
summary(lmer.rt_dist_slow_trigs_only)

# mixed-effects models are too liberal. try starting with maximum random effects.

# first, let's do it for accuracy ~ block × trigger × distractor + (1 | subjectID) [test phase]
# in the code here, I'm calling it "TEST1"

# baseline model (what I originally used)
m_int_TEST1 <- glmer(
  accuracy ~ block_number * distractor_feature * trigger + (1 | subjectID),
  family = binomial(link="logit"),
  data   = master.df.sart.combined,
  control= glmerControl(optimizer="bobyqa", optCtrl=list(maxfun=1e5))
)
summary(m_int_TEST1)

# maximal model with random effects slopes by-subject (removed random effect correlations, which sometimes helps)
m_max_TEST1 <- glmer(
  accuracy ~ block_number * distractor_feature * trigger +
    (1 + block_number + distractor_feature + trigger || subjectID),
  family = binomial, data = master.df.sart.combined,
  control= glmerControl(optimizer="bobyqa", optCtrl=list(maxfun=1e5))
)
lme4::isSingular(m_max_TEST1, tol = 1e-4)  # TRUE = singular

# this helps us identify the most useless slopes in m_max_TEST1
VarCorr(m_max_TEST1)

# drop stuff
m_next_TEST1 <- glmer(
  accuracy ~ block_number * distractor_feature * trigger +
    (1 + block_number + distractor_feature || subjectID),
  family = binomial, data = master.df.sart.combined,
  control= glmerControl(optimizer="bobyqa", optCtrl=list(maxfun=1e5))
)
lme4::isSingular(m_next_TEST1, tol=1e-4)

summary(m_next_TEST1)

get_beta_p <- function(mod) {
  sm <- summary(mod)
  cf <- sm$coefficients
  data.frame(
    term = rownames(cf),
    beta = cf[, "Estimate"],
    p    = cf[, "Pr(>|z|)"],
    row.names = NULL,
    check.names = FALSE
  )
}

max_df  <- get_beta_p(m_max_TEST1)
next_df <- get_beta_p(m_next_TEST1)

compare <- merge(
  max_df, next_df,
  by = "term", all = TRUE,
  suffixes = c("_m_max_TEST1", "_m_next_TEST1")
)

add_stars <- function(p) cut(
  p,
  breaks = c(-Inf, .001, .01, .05, .1, Inf),
  labels = c("***", "**", "*", ".", "")
)

compare$stars_m_max_TEST1  <- add_stars(compare$p_m_max_TEST1)
compare$stars_m_next_TEST1 <- add_stars(compare$p_m_next_TEST1)

num_cols <- vapply(compare, is.numeric, logical(1))
compare[num_cols] <- lapply(compare[num_cols], function(x) round(x, 4))

# sort by m_next_TEST1 p-value (keeps NAs at end)
compare <- compare[order(is.na(compare$p_m_next_TEST1), compare$p_m_next_TEST1), ]

print(compare, row.names = FALSE)



# second, let's do it for accuracy ~ trigger × distractor × learning_magnitude + (1 | subjectID) [test phase; first two blocks]
# in the code here, I'm calling it "TEST2"

# make combined first-half dataset once (so models share identical rows)
df_TEST2 <- bind_rows(
  master.df.sart.exp1.firsthalf %>% mutate(experiment = "exp1"),
  master.df.sart.exp2.firsthalf %>% mutate(experiment = "exp2")
)

# baseline model (what I originally used)
m_int_TEST2 <- glmer(
  accuracy ~ trigger * distractor_feature * magnitude_learning + (1 | subjectID),
  family  = binomial(link="logit"),
  data    = df_TEST2,
  control = glmerControl(optimizer="bobyqa", optCtrl=list(maxfun=2e5))
)
summary(m_int_TEST2)

# maximal random slopes by-subject (start with uncorrelated REs)
m_max_TEST2 <- glmer(
  accuracy ~ trigger * distractor_feature * magnitude_learning +
    (1 + trigger + distractor_feature + magnitude_learning || subjectID),
  family  = binomial(link="logit"),
  data    = df_TEST2,
  control = glmerControl(optimizer="bobyqa", optCtrl=list(maxfun=1e5))
)
lme4::isSingular(m_max_TEST2, tol=1e-4)
VarCorr(m_max_TEST2)

# drop stuff
m_next_TEST2 <- glmer(
  accuracy ~ trigger * distractor_feature * magnitude_learning +
    (1 + distractor_feature + magnitude_learning || subjectID),
  family  = binomial(link="logit"),
  data    = df_TEST2,
  control = glmerControl(optimizer="bobyqa", optCtrl=list(maxfun=1e5))
)
lme4::isSingular(m_next_TEST2, tol=1e-4)
VarCorr(m_next_TEST2)

# drop more stuff
m_next_next_TEST2 <- glmer(
  accuracy ~ trigger * distractor_feature * magnitude_learning +
    (1 + distractor_feature || subjectID),
  family  = binomial(link="logit"),
  data    = df_TEST2,
  control = glmerControl(optimizer="bobyqa", optCtrl=list(maxfun=1e5))
)
lme4::isSingular(m_next_next_TEST2, tol=1e-4)
VarCorr(m_next_next_TEST2)

# drop even more stuff
m_next_next_next_TEST2 <- glmer(
  accuracy ~ trigger * distractor_feature * magnitude_learning +
    (1 || subjectID),
  family  = binomial(link="logit"),
  data    = df_TEST2,
  control = glmerControl(optimizer="bobyqa", optCtrl=list(maxfun=1e5))
)
lme4::isSingular(m_next_next_next_TEST2, tol=1e-4)
VarCorr(m_next_next_next_TEST2)

summary(m_next_next_next_TEST2)
