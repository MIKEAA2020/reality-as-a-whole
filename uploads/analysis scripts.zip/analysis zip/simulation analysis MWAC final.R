############################################################
# R3: Simulation-based sensitivity (power) checks
#
# the two models are the main ones from the test phase:
#   1) logit.acc_block_dist_trig_both
#      Formula: accuracy ~ block_number * distractor_feature * trigger + (1 | subjectID)
#   2) logit.firsthalf.acc_trig_dist_mag_both
#      Formula: accuracy ~ trigger * distractor_feature * magnitude_learning + (1 | subjectID)
############################################################

library(simr)

nsim_use <- 250
set.seed(123)

cat("\n================= STARTING POWER SIMS =================\n")
cat("nsim =", nsim_use, "\n\n")

cat("\n================= MODEL 1 =================\n")
cat("Model: logit.acc_block_dist_trig_both\n")
cat("Formula: accuracy ~ block_number * distractor_feature * trigger + (1 | subjectID)\n\n")

cat("\n--- Candidate A: distractor_featurereward (beta = 0.52) ---\n")
fixef(logit.acc_block_dist_trig_both)["distractor_featurereward"]

m_A_b052 <- logit.acc_block_dist_trig_both
fixef(m_A_b052)["distractor_featurereward"] <- 0.52
fixef(m_A_b052)["distractor_featurereward"]

pwr_A_b052 <- powerSim(m_A_b052, test = fixed("distractor_featurereward","z"), nsim = nsim_use)
sum_A_b052 <- summary(pwr_A_b052)
print(sum_A_b052)

cat("\n--- Candidate B: block_number:distractor_featurereward (beta = -0.19) ---\n")
fixef(logit.acc_block_dist_trig_both)["block_number:distractor_featurereward"]

m_B_bm019 <- logit.acc_block_dist_trig_both
fixef(m_B_bm019)["block_number:distractor_featurereward"] <- -0.19
fixef(m_B_bm019)["block_number:distractor_featurereward"]

pwr_B_bm019 <- powerSim(m_B_bm019, test = fixed("block_number:distractor_featurereward","z"), nsim = nsim_use)
sum_B_bm019 <- summary(pwr_B_bm019)
print(sum_B_bm019)

cat("\n--- Candidate C: distractor_featurereward:triggerslow (beta = -0.88) ---\n")
fixef(logit.acc_block_dist_trig_both)["distractor_featurereward:triggerslow"]

m_C_bm088 <- logit.acc_block_dist_trig_both
fixef(m_C_bm088)["distractor_featurereward:triggerslow"] <- -0.88
fixef(m_C_bm088)["distractor_featurereward:triggerslow"]

pwr_C_bm088 <- powerSim(m_C_bm088, test = fixed("distractor_featurereward:triggerslow","z"), nsim = nsim_use)
sum_C_bm088 <- summary(pwr_C_bm088)
print(sum_C_bm088)

cat("\n================= MODEL 2 =================\n")
cat("Model: logit.firsthalf.acc_trig_dist_mag_both\n")
cat("Formula: accuracy ~ trigger * distractor_feature * magnitude_learning + (1 | subjectID)\n\n")

cat("\n--- Candidate D: triggerslow:distractor_featurenovel:magnitude_learning (beta = -0.022) ---\n")
fixef(logit.firsthalf.acc_trig_dist_mag_both)["triggerslow:distractor_featurenovel:magnitude_learning"]

m_D_bm022 <- logit.firsthalf.acc_trig_dist_mag_both
fixef(m_D_bm022)["triggerslow:distractor_featurenovel:magnitude_learning"] <- -0.022
fixef(m_D_bm022)["triggerslow:distractor_featurenovel:magnitude_learning"]

pwr_D_bm022 <- powerSim(m_D_bm022, test = fixed("triggerslow:distractor_featurenovel:magnitude_learning","z"), nsim = nsim_use)
sum_D_bm022 <- summary(pwr_D_bm022)
print(sum_D_bm022)

cat("\n--- Candidate E: triggerslow:distractor_featurereward:magnitude_learning (beta = -0.0210) ---\n")
fixef(logit.firsthalf.acc_trig_dist_mag_both)["triggerslow:distractor_featurereward:magnitude_learning"]

m_E_bm0210 <- logit.firsthalf.acc_trig_dist_mag_both
fixef(m_E_bm0210)["triggerslow:distractor_featurereward:magnitude_learning"] <- -0.0210
fixef(m_E_bm0210)["triggerslow:distractor_featurereward:magnitude_learning"]

pwr_E_bm0210 <- powerSim(m_E_bm0210, test = fixed("triggerslow:distractor_featurereward:magnitude_learning","z"), nsim = nsim_use)
sum_E_bm0210 <- summary(pwr_E_bm0210)
print(sum_E_bm0210)

cat("\n--- Candidate F: distractor_featurereward:magnitude_learning (beta = 0.0130) ---\n")
fixef(logit.firsthalf.acc_trig_dist_mag_both)["distractor_featurereward:magnitude_learning"]

m_F_b00130 <- logit.firsthalf.acc_trig_dist_mag_both
fixef(m_F_b00130)["distractor_featurereward:magnitude_learning"] <- 0.0130
fixef(m_F_b00130)["distractor_featurereward:magnitude_learning"]

pwr_F_b00130 <- powerSim(m_F_b00130, test = fixed("distractor_featurereward:magnitude_learning","z"), nsim = nsim_use)
sum_F_b00130 <- summary(pwr_F_b00130)
print(sum_F_b00130)

cat("\n================= CONSOLIDATED SUMMARY =================\n")

cat("\nMODEL 1 (logit.acc_block_dist_trig_both)\n")
cat("A) distractor_featurereward                      beta= 0.52\n");  print(sum_A_b052)
cat("B) block_number:distractor_featurereward          beta=-0.19\n");  print(sum_B_bm019)
cat("C) distractor_featurereward:triggerslow           beta=-0.88\n");  print(sum_C_bm088)

cat("\nMODEL 2 (logit.firsthalf.acc_trig_dist_mag_both)\n")
cat("D) triggerslow:distractor_featurenovel:magnitude_learning   beta=-0.022\n"); print(sum_D_bm022)
cat("E) triggerslow:distractor_featurereward:magnitude_learning  beta=-0.0210\n"); print(sum_E_bm0210)
cat("F) distractor_featurereward:magnitude_learning              beta= 0.0130\n"); print(sum_F_b00130)

cat("\n================= DONE =================\n")

results_df <- data.frame(
  term = c(
    "distractor_featurereward",
    "block_number:distractor_featurereward",
    "distractor_featurereward:triggerslow",
    "triggerslow:distractor_featurenovel:magnitude_learning",
    "triggerslow:distractor_featurereward:magnitude_learning",
    "distractor_featurereward:magnitude_learning"
  ),
  
  model = c(
    "logit.acc_block_dist_trig_both",
    "logit.acc_block_dist_trig_both",
    "logit.acc_block_dist_trig_both",
    "logit.firsthalf.acc_trig_dist_mag_both",
    "logit.firsthalf.acc_trig_dist_mag_both",
    "logit.firsthalf.acc_trig_dist_mag_both"
  ),
  
  beta = c(0.52, -0.19, -0.88, -0.022, -0.0210, 0.0130),
  
  power = c(
    sum_A_b052$mean,
    sum_B_bm019$mean,
    sum_C_bm088$mean,
    sum_D_bm022$mean,
    sum_E_bm0210$mean,
    sum_F_b00130$mean
  ),
  
  lower_CI = c(
    sum_A_b052$lower,
    sum_B_bm019$lower,
    sum_C_bm088$lower,
    sum_D_bm022$lower,
    sum_E_bm0210$lower,
    sum_F_b00130$lower
  ),
  
  upper_CI = c(
    sum_A_b052$upper,
    sum_B_bm019$upper,
    sum_C_bm088$upper,
    sum_D_bm022$upper,
    sum_E_bm0210$upper,
    sum_F_b00130$upper
  )
)

print(results_df)

model_map <- list(
  "logit.acc_block_dist_trig_both"         = logit.acc_block_dist_trig_both,
  "logit.firsthalf.acc_trig_dist_mag_both" = logit.firsthalf.acc_trig_dist_mag_both
)

get_observed_stats <- function(mod, term) {
  cf <- summary(mod)$coefficients
  
  if (!term %in% rownames(cf)) {
    return(data.frame(
      observed_beta = NA_real_,
      observed_se   = NA_real_,
      observed_minus1SE = NA_real_,
      observed_plus1SE  = NA_real_
    ))
  }
  
  b  <- cf[term, "Estimate"]
  se <- cf[term, "Std. Error"]
  
  data.frame(
    observed_beta = b,
    observed_se   = se,
    observed_minus1SE = b - se,
    observed_plus1SE  = b + se
  )
}

obs_df <- do.call(rbind, lapply(seq_len(nrow(results_df)), function(i) {
  mod_name <- results_df$model[i]
  term     <- results_df$term[i]
  get_observed_stats(model_map[[mod_name]], term)
}))

results_with_obs <- cbind(results_df, obs_df)

print(results_with_obs)

write.csv(
  results_with_obs,
  file = "~/Library/CloudStorage/GoogleDrive-sshelat@ucsb.edu/My Drive/PhD/Project: MWAC final/tables/table.power_simulations.csv",
  row.names = FALSE
)

