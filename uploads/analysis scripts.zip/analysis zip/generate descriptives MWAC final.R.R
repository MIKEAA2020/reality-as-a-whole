
# Gender counts by experiment
cat("\nGender counts by experiment:\n")
print(table(master.traits$experiment, master.traits$gender))

# Handedness counts by experiment
cat("\nHandedness counts by experiment:\n")
print(table(master.traits$experiment, master.traits$handedness))

# Mean (SD) for selected numeric columns (excluding k and magnitude_learning) by experiment
numeric_cols <- c("age", "relative_fatigue", "ecs_total", "mwd_total", "mws_total", "mw_q_total")

cat("\nNumeric summaries (mean (SD)) by experiment:\n")
master.traits %>%
  group_by(experiment) %>%
  summarise(across(all_of(numeric_cols),
                   ~ sprintf("%.2f (%.2f)", mean(.x, na.rm = TRUE), sd(.x, na.rm = TRUE))
  )) %>%
  print()

# EXP1: unique subject‐k and print mean (SD)
k_summary_exp1 <- master.df.sart.exp1 %>%
  distinct(subjectID, k) %>%
  summarise(
    mean_k = mean(k, na.rm = TRUE),
    sd_k   = sd(k,   na.rm = TRUE)
  )
cat("EXP1 SART k: ", sprintf("%.2f (%.2f)", k_summary_exp1$mean_k, k_summary_exp1$sd_k), "\n")

# EXP2: unique subject‐k and print mean (SD)
k_summary_exp2 <- master.df.sart.exp2 %>%
  distinct(subjectID, k) %>%
  summarise(
    mean_k = mean(k, na.rm = TRUE),
    sd_k   = sd(k,   na.rm = TRUE)
  )
cat("EXP2 SART k: ", sprintf("%.2f (%.2f)", k_summary_exp2$mean_k, k_summary_exp2$sd_k), "\n")

# DECLUTTER!

rm(list = setdiff(ls(), c(
  "master.df.learn.exp1",
  "master.df.learn.exp2",
  "master.df.sart.exp1",
  "master.df.sart.exp2",
  "master.df.sart.exp1.firsthalf",
  "master.df.sart.exp2.firsthalf",
  "master.traits"
)))
