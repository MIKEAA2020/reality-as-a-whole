
# The scripts in this repository should be run in the following order:

# 1) process data MWAC final.R
# 2) check exclusion crit MWAC final.R
# 3) generate descriptives MWAC final.R
# 4) analyze training MWAC final.R
# 5) analyze test MWAC final.R

library(tidyverse)
library(dplyr)
library(lme4)
library(lmerTest)
library(ggpubr)
library(ggeffects)
library(cowplot)
library(MuMIn)

options(scipen=999, digits=10, pillar.sigfig = 10)
set.seed(123)

### SURVEYS ###

# SURVEYS: load in data and remove first two lines of fluff from Qualtrics export

survey_df_exp1 <- read.csv("~/Library/CloudStorage/GoogleDrive-sshelat@ucsb.edu/My Drive/PhD/Project: MWAC final/data/exp1 (MWAC2)/survey/exp1 MWAC2 survey.csv", header = TRUE, stringsAsFactors = FALSE)
survey_df_exp1 <- survey_df_exp1[-c(1, 2), ]
survey_df_exp1$experiment <- "exp1"

survey_df_exp2 <- read.csv("~/Library/CloudStorage/GoogleDrive-sshelat@ucsb.edu/My Drive/PhD/Project: MWAC final/data/exp2 (MWAC3)/survey/exp2 MWAC3 survey.csv", header = TRUE, stringsAsFactors = FALSE)
survey_df_exp2 <- survey_df_exp2[-c(1, 2), ]
survey_df_exp2$experiment <- "exp2"

# SURVEYS: combine dfs and rename/recode some columns

survey_df <- rbind(survey_df_exp1, survey_df_exp2)
names(survey_df)[names(survey_df) == "relative_fatigue_9"] <- "relative_fatigue"

survey_df <- survey_df %>%
  mutate(gender = recode(gender,
                         "1" = "male",
                         "2" = "female",
                         "3" = "non-binary/third gender",
                         "4" = "prefer not to say"))

survey_df <- survey_df %>%
  mutate(handedness = recode(handedness,
                             "1" = "right-handed",
                             "2" = "left-handed",
                             "3" = "ambidextrous"))

survey_df <- survey_df %>%
  mutate(across(c(age, relative_fatigue), as.numeric))

# SURVEYS: turn a bunch of columns in a range into numeric type, then check how many missing responses to any items (i.e., what % na under each column?)

col_range <- names(survey_df)[which(names(survey_df) == "MW_Q1"):which(names(survey_df) == "ecs_76_inhcon")] 
survey_df <- survey_df %>%
  mutate(across(all_of(col_range), ~as.numeric(as.character(.))))

colSums(is.na(survey_df[col_range])) %>% print()

# SURVEY: reverse scoring + overall scoring for all embedded surveys

ecs_column_names <- c("ecs_2r_actcon", "ecs_8r_actcon", "ecs_15_actcon",
                      "ecs_27_actcon", "ecs_47_actcon", "ecs_55_actcon",
                      "ecs_72r_actcon", "ecs_5r_attncon", "ecs_29r_attncon",
                      "ecs_35_attncon", "ecs_40r_attncon", "ecs_50r_attncon",
                      "ecs_11_inhcon", "ecs_26_inhcon", "ecs_43_inhcon",
                      "ecs_53r_inhcon", "ecs_60r_inhcon", "ecs_63r_inhcon",
                      "ecs_76_inhcon")
reverse_items <- grep("r_", ecs_column_names, value = TRUE) # to reverse score stuff with 'r_' indicator
survey_df[ , reverse_items] = 8 - survey_df[ , reverse_items]
survey_df$ecs_total <- rowMeans(survey_df[, ecs_column_names], na.rm = TRUE)

mwspontdelib_column_names <- c("mwd1", "mwd2", "mwd3", "mwd4",
                               "mws1", "mws2", "mws3", "mws4")
mwd_items <- grep("mwd", mwspontdelib_column_names, value = TRUE)
survey_df$mwd_total <- rowMeans(survey_df[, mwd_items], na.rm = TRUE)
mws_items <- grep("mws", mwspontdelib_column_names, value = TRUE)
survey_df$mws_total <- rowMeans(survey_df[, mws_items], na.rm = TRUE)

mwq_column_names <- c("MW_Q1", "MW_Q2", "MW_Q3", "MW_Q4", "MW_Q5")
survey_df$mw_q_total <- rowMeans(survey_df[, mwq_column_names], na.rm = TRUE)

survey_df <- survey_df %>%
  select(experiment, subjectID, age, gender, handedness, relative_fatigue, ecs_total, mwd_total, mws_total, mw_q_total) %>%
  mutate(subjectID = as.factor(subjectID))

rm(list = setdiff(ls(), "survey_df"))

### VWMC ###

# VWMC: gather data from relevant folder

vwmc_csvs_exp1 <- list.files(
  path = "~/Library/CloudStorage/GoogleDrive-sshelat@ucsb.edu/My Drive/PhD/Project: MWAC final/data/exp1 (MWAC2)/vWMC",
  pattern = "\\.csv$",
  full.names = TRUE
)

vwmc_csvs_exp2 <- list.files(
  path = "~/Library/CloudStorage/GoogleDrive-sshelat@ucsb.edu/My Drive/PhD/Project: MWAC final/data/exp2 (MWAC3)/vWMC",
  pattern = "\\.csv$",
  full.names = TRUE
)

vwmc_csvs_all <- c(vwmc_csvs_exp1, vwmc_csvs_exp2)

# VWMC: calculate Cowan's k per subjectID

vwmc_df <- c(vwmc_csvs_exp1, vwmc_csvs_exp2) %>%
  map_df(~ read_csv(.x, show_col_types = FALSE) %>%
           mutate(
             subjectID        = factor(subjectID),
             set_size         = factor(set_size),
             change_condition = factor(change_condition)
           )
  ) %>%
  group_by(subjectID, set_size, change_condition) %>%
  summarise(
    accuracy_prop = mean(accuracy, na.rm = TRUE),
    .groups       = "drop"
  ) %>%
  pivot_wider(
    names_from   = change_condition,
    values_from  = accuracy_prop,
    names_prefix = "accur_"
  ) %>%
  mutate(
    hit_rate       = accur_change,
    fa_rate        = 1 - accur_no_change,
    k_per_set_size = as.numeric(as.character(set_size)) * (hit_rate - fa_rate)
  ) %>%
  group_by(subjectID) %>%
  summarise(
    k = mean(k_per_set_size, na.rm = TRUE),
    .groups = "drop"
  )

# VWMC: merge to survey_df and call it master.traits

levels(vwmc_df$subjectID) <- c(levels(vwmc_df$subjectID), "79")
vwmc_df$subjectID[is.na(vwmc_df$subjectID)] <- "79"

master.traits <- survey_df %>%
  left_join(vwmc_df, by = "subjectID")

rm(list = setdiff(ls(), c("master.traits", "vwmc_df")))

# TRAINING (aka LEARNING)

# TRAINING: gather learn subfolders from each subject folder

behavior_data_exp1 <- "~/Library/CloudStorage/GoogleDrive-sshelat@ucsb.edu/My Drive/PhD/Project: MWAC final/data/exp1 (MWAC2)/behavior"
subject_folders_exp1 <- list.dirs(path = behavior_data_exp1, recursive = FALSE)
learn_folders_exp1 <- subject_folders_exp1 %>%
  map(~ list.dirs(path = .x, recursive = FALSE) %>% str_subset("learn")) %>%
  unlist()

behavior_data_exp2 <- "~/Library/CloudStorage/GoogleDrive-sshelat@ucsb.edu/My Drive/PhD/Project: MWAC final/data/exp2 (MWAC3)/behavior"
subject_folders_exp2 <- list.dirs(path = behavior_data_exp2, recursive = FALSE)
learn_folders_exp2 <- subject_folders_exp2 %>%
  map(~ list.dirs(path = .x, recursive = FALSE) %>% str_subset("learn")) %>%
  unlist()

learn_folders_all <- c(learn_folders_exp1, learn_folders_exp2)

# TRAINING: collect trial structure and response data file paths

trialstruc_files.learn   <- learn_folders_all %>% 
  map(~ list.files(path = .x, pattern = "^trialstruc_.*\\.csv$", full.names = TRUE)) %>% 
  unlist()
responsedata_files.learn <- learn_folders_all %>% 
  map(~ list.files(path = .x, pattern = "^data_.*\\.csv$",       full.names = TRUE)) %>% 
  unlist()

# TRAINING: read and combine all trial structure CSVs

trialstrucs_comb.learn <- trialstruc_files.learn %>%
  map_df(~ read_csv(.x, show_col_types = FALSE) %>% 
           mutate(block_num = as.character(block_num))
  )

# TRAINING: read and combine all response data CSVs

responsedata_comb.learn <- responsedata_files.learn %>%
  map_df(~ read_csv(.x, show_col_types = FALSE) %>% 
           mutate(block_num = as.character(block_num))
  )

# TRAINING: merge trial structure and response data into one master dataframe

master.df.learn <- trialstrucs_comb.learn %>%
  full_join(responsedata_comb.learn, 
            by = c("subjectID", "block_num", "trial_num"))

# TRAINING: due to experimenter error, subject 79 is NA here. so we manually replace NA with 79 under the subjectID column.

master.df.learn$subjectID[is.na(master.df.learn$subjectID)] <- 79

# TRAINING: rename variables for better readability

master.df.learn <- master.df.learn %>% 
  rename(
    block_number = block_num,
    trial_number = trial_num
  )

# TRAINING: note here that "reward_condition" is a flag that indicates whether the target in this trial was of the sometimes-rewarded color

master.df.learn$reward_condition <- ifelse(master.df.learn$target_ring_color == 1, 1, 0)

# TRAINING: remove all practice trials so block can be converted to numeric type

master.df.learn <- master.df.learn[master.df.learn$block_number != 'practice',] 

# TRAINING: convert data types to what they should be

master.df.learn <- master.df.learn %>%
  mutate(
    subjectID = as.factor(subjectID),
    block_number = as.numeric(block_number),
    trial_number = as.numeric(trial_number),
    reward_condition = as.factor(reward_condition),
    rt = as.numeric(rt)
  )

# TRAINING: compute cumulative trial number across blocks

master.df.learn$trial_number_all <- (72 * (master.df.learn$block_number - 1)) + master.df.learn$trial_number

# TRAINING: tag data with experiment identifier; need to manually add experiment ID to participants who didn't do post-task survey

exp_tag <- master.traits %>% 
  select(subjectID, experiment)

missing_ids <- c("22","36","65","80","82","98")
exp_tag <- bind_rows(
  exp_tag,
  tibble(subjectID = missing_ids, experiment = NA_character_)
)

exp_tag <- exp_tag %>%
  mutate(experiment = case_when(
    subjectID %in% c("22","36")              ~ "exp1",
    subjectID %in% c("65","80","82","98")    ~ "exp2",
    TRUE                                     ~ experiment
  )) %>%
  mutate(experiment = factor(experiment, levels = c("exp1","exp2")))

master.df.learn <- master.df.learn %>%
  left_join(exp_tag, by = "subjectID")

# TRAINING: at this point, create a file with all trials before more trial trimming is conducted

master.df.learn.all <- master.df.learn

# TRAINING: clear environment before critical trimming begins

rm(list = setdiff(ls(), c("master.traits", "master.df.learn", "master.df.learn.all", 
                          "exp_tag", "vwmc_df")))

# TRAINING: create one learning df for each experiment

master.df.learn.all.exp1 <- master.df.learn.all %>%
  filter(experiment == "exp1")

master.df.learn.all.exp2 <- master.df.learn.all %>%
  filter(experiment == "exp2")

# TRAINING: print some descriptives of all data

cat("EXP1\n",
    "Total rows:",      nrow(master.df.learn.all.exp1), 
    "\nTotal inaccurate:", sum(master.df.learn.all.exp1$accuracy == 0, na.rm = TRUE), 
    "\n% Inaccurate:",   round(mean(master.df.learn.all.exp1$accuracy == 0, na.rm = TRUE) * 100, 2), 
    "\nTotal < 200ms:",  sum(master.df.learn.all.exp1$rt < 200, na.rm = TRUE), 
    "\n% < 200ms:",      round(mean(master.df.learn.all.exp1$rt < 200, na.rm = TRUE) * 100, 2),
    "\nTotal missing:",  sum(is.na(master.df.learn.all.exp1$accuracy)), 
    "\n% Missing:",      round(mean(is.na(master.df.learn.all.exp1$accuracy)) * 100, 2),
    "\n\n")

cat("EXP2\n",
    "Total rows:",      nrow(master.df.learn.all.exp2), 
    "\nTotal inaccurate:", sum(master.df.learn.all.exp2$accuracy == 0, na.rm = TRUE), 
    "\n% Inaccurate:",   round(mean(master.df.learn.all.exp2$accuracy == 0, na.rm = TRUE) * 100, 2), 
    "\nTotal < 200ms:",  sum(master.df.learn.all.exp2$rt < 200, na.rm = TRUE), 
    "\n% < 200ms:",      round(mean(master.df.learn.all.exp2$rt < 200, na.rm = TRUE) * 100, 2),
    "\nTotal missing:",  sum(is.na(master.df.learn.all.exp2$accuracy)), 
    "\n% Missing:",      round(mean(is.na(master.df.learn.all.exp2$accuracy)) * 100, 2))

# TRAINING: trim for RT analysis (keep only accurate, ≥200 ms, non‐missing)

master.df.learn <- master.df.learn.all[
  master.df.learn.all$accuracy == 1 &
    master.df.learn.all$rt >= 200 &
    !is.na(master.df.learn.all$accuracy),
]

master.df.learn.exp1 <- master.df.learn.all.exp1[
  master.df.learn.all.exp1$accuracy == 1 &
    master.df.learn.all.exp1$rt >= 200 &
    !is.na(master.df.learn.all.exp1$accuracy),
]

master.df.learn.exp2 <- master.df.learn.all.exp2[
  master.df.learn.all.exp2$accuracy == 1 &
    master.df.learn.all.exp2$rt >= 200 &
    !is.na(master.df.learn.all.exp2$accuracy),
]

# TRAINING: calculating learning magnitude ind diff

learn.magnitude.per.person <- master.df.learn %>%
  select(subjectID, target_ring_color, rt) %>%
  group_by(subjectID, target_ring_color) %>%
  summarise(
    avg_rt_trial = mean(rt, na.rm = TRUE)
  ) %>%
  spread(target_ring_color, avg_rt_trial) %>%
  mutate(magnitude_learning = `2` - `1`) %>% # where a higher number represents greater magnitude of learning
  select(subjectID, magnitude_learning)

master.traits <- master.traits %>%
  left_join(learn.magnitude.per.person, by = "subjectID")

# declutter environment

rm(list = setdiff(ls(), c("master.traits", "learn.magnitude.per.person", 
                          "master.df.learn.all",
                          "master.df.learn.all.exp1", "master.df.learn.all.exp2", 
                          "master.df.learn.exp1", "master.df.learn.exp2",
                          "exp_tag", "vwmc_df")))

### SART ###

# SART: gather SART subfolders from each subject folder

behavior_data_exp1 <- "~/Library/CloudStorage/GoogleDrive-sshelat@ucsb.edu/My Drive/PhD/Project: MWAC final/data/exp1 (MWAC2)/behavior"
subject_folders_exp1 <- list.dirs(path = behavior_data_exp1, recursive = FALSE)
sart_folders_exp1 <- subject_folders_exp1 %>%
  map(~ list.dirs(path = .x, recursive = FALSE) %>% str_subset("sart")) %>%
  unlist()

behavior_data_exp2 <- "~/Library/CloudStorage/GoogleDrive-sshelat@ucsb.edu/My Drive/PhD/Project: MWAC final/data/exp2 (MWAC3)/behavior"
subject_folders_exp2 <- list.dirs(path = behavior_data_exp2, recursive = FALSE)
sart_folders_exp2 <- subject_folders_exp2 %>%
  map(~ list.dirs(path = .x, recursive = FALSE) %>% str_subset("sart")) %>%
  unlist()

sart_folders_all <- c(sart_folders_exp1, sart_folders_exp2)

# SART: collect trial structure and response data file paths

trialstruc_files.sart   <- sart_folders_all %>% 
  map(~ list.files(path = .x, pattern = "^trialstruc_.*\\.csv$", full.names = TRUE)) %>% 
  unlist()
responsedata_files.sart <- sart_folders_all %>% 
  map(~ list.files(path = .x, pattern = "^data_.*\\.csv$",       full.names = TRUE)) %>% 
  unlist()

# SART: read and combine all trial structure CSVs

trialstrucs_comb.sart <- trialstruc_files.sart %>%
  map_df(~ read_csv(.x, show_col_types = FALSE) %>% 
           mutate(block_num = as.character(block_num))
  )

# SART: read and combine all response data CSVs

responsedata_comb.sart <- responsedata_files.sart %>%
  map_df(~ read_csv(.x, show_col_types = FALSE) %>% 
           mutate(block_num = as.character(block_num))
  )

# SART: merge trial struc and response data CSVs to create the master dataframe

master.df.sart <- merge(trialstrucs_comb.sart, responsedata_comb.sart, by = c('subjectID', 'block_num', 'trial_num'), all = T)

# SART: rename variables for better readability

master.df.sart <- master.df.sart %>% 
  rename(
    block_number = block_num,
    trial_number = trial_num,
    trigger = infreq_trigger
  )

# SART: remove all practice trials so block can be converted to numeric type

master.df.sart <- master.df.sart[master.df.sart$block_number != 'practice',] 

# SART: convert data types to what they should be

master.df.sart <- master.df.sart %>%
  mutate(
    subjectID = as.factor(subjectID),
    block_number = as.numeric(block_number),
    trial_number = as.numeric(trial_number),
    rt = as.numeric(rt),
    accuracy = as.numeric(accuracy)
  )

# SART: compute cumulative trial number across blocks

master.df.sart$trial_number_all <- (600 * (master.df.sart$block_number - 1)) + master.df.sart$trial_number

# SART: tag data with experiment ID

master.df.sart <- master.df.sart %>%
  left_join(exp_tag %>% select(subjectID, experiment), by = "subjectID")

# SART: at this point, create a file with all trials before more trial trimming is conducted

master.df.sart.all <- master.df.sart

# SART: keep only slow/fast triggered trials in master.df.sart

master.df.sart <- subset(master.df.sart, trigger == "slow" | trigger == "fast")

# SART: make a df for excl; trim other master.df.sart.all by removing < 200ms and missing response trials

master.df.sart.all.excl <- master.df.sart.all

master.df.sart.all <- master.df.sart.all[
  master.df.sart.all$rt >= 200 &
    !is.na(master.df.sart.all$accuracy),
]

# SART: create sart dfs for each experiment

master.df.sart.all.exp1 <- master.df.sart.all %>%
  filter(experiment == "exp1")
master.df.sart.all.exp2 <- master.df.sart.all %>%
  filter(experiment == "exp2")

master.df.sart.exp1 <- master.df.sart %>%
  filter(experiment == "exp1")
master.df.sart.exp2 <- master.df.sart %>% 
  filter(experiment == "exp2")

# SART: for the triggered-trials-only df, print some descriptives of the data (% inaccurate, % < 200ms, % missing response)

cat("EXP1\n",
    "Total rows:",      nrow(master.df.sart.exp1), 
    "\nTotal inaccurate:", sum(master.df.sart.exp1$accuracy == 0, na.rm = TRUE),
    "\n% Inaccurate:",   round(mean(master.df.sart.exp1$accuracy == 0, na.rm = TRUE) * 100, 2),
    "\nTotal missing:",  sum(is.na(master.df.sart.exp1$accuracy)), 
    "\n% Missing:",      round(mean(is.na(master.df.sart.exp1$accuracy)) * 100, 2),
    "\nTotal < 200ms:",  sum(master.df.sart.exp1$rt < 200, na.rm = TRUE), 
    "\n% < 200ms:",      round(mean(master.df.sart.exp1$rt < 200, na.rm = TRUE) * 100, 2),
    "\n\n")

cat("EXP2\n",
    "Total rows:",      nrow(master.df.sart.exp2), 
    "\nTotal inaccurate:", sum(master.df.sart.exp2$accuracy == 0, na.rm = TRUE),
    "\n% Inaccurate:",   round(mean(master.df.sart.exp2$accuracy == 0, na.rm = TRUE) * 100, 2),
    "\nTotal missing:",  sum(is.na(master.df.sart.exp2$accuracy)), 
    "\n% Missing:",      round(mean(is.na(master.df.sart.exp2$accuracy)) * 100, 2),
    "\nTotal < 200ms:",  sum(master.df.sart.exp2$rt < 200, na.rm = TRUE), 
    "\n% < 200ms:",      round(mean(master.df.sart.exp2$rt < 200, na.rm = TRUE) * 100, 2))

# SART: trim master.df.sart for both exps by removing < 200ms and missing response trials 

master.df.sart.exp1 <- master.df.sart.exp1[
  master.df.sart.exp1$rt >= 200 &
    !is.na(master.df.sart.exp1$accuracy),
]

master.df.sart.exp2 <- master.df.sart.exp2[
  master.df.sart.exp2$rt >= 200 &
    !is.na(master.df.sart.exp2$accuracy),
]

# SART: merge learning magnitude per person to sart data

master.df.sart.exp1 <- master.df.sart.exp1 %>%
  left_join(learn.magnitude.per.person, by = "subjectID")

master.df.sart.exp2 <- master.df.sart.exp2 %>%
  left_join(learn.magnitude.per.person, by = "subjectID")

# SART: merge vWMC per person to sart data

master.df.sart.exp1 <- master.df.sart.exp1 %>%
  left_join(vwmc_df, by = "subjectID")

master.df.sart.exp2 <- master.df.sart.exp2 %>%
  left_join(vwmc_df, by = "subjectID")

# SART: merge traits per person to sart data; some will be missing cuz some people didn't fill out the questionnaire

master.df.sart.exp1 <- master.df.sart.exp1 %>%
  left_join(
    master.traits %>%
      select(subjectID, age, gender, handedness, ecs_total, mwd_total, mws_total, mw_q_total),
    by = "subjectID"
  )

master.df.sart.exp2 <- master.df.sart.exp2 %>%
  left_join(
    master.traits %>%
      select(subjectID, age, gender, handedness, ecs_total, mwd_total, mws_total, mw_q_total),
    by = "subjectID"
  )

# FINAL STEPS: fill master.traits with experience-dependent tags

subjectinfo <- master.df.learn.all %>%
  select(subjectID, counterbalance_condition, condition_nonrew) %>%
  rename(rewarded_color = counterbalance_condition) %>%
  rename(unrewarded_color = condition_nonrew) %>%
  distinct() 

master.df.sart.exp1 <- left_join(master.df.sart.exp1, subjectinfo, by = "subjectID")
master.df.sart.exp2 <- left_join(master.df.sart.exp2, subjectinfo, by = "subjectID")

master.df.sart.exp1 <- master.df.sart.exp1 %>%
  mutate(distractor_feature = case_when(
    rewarded_color == 'r' & unrewarded_color == 'b' & triggered_colors == 'red'   ~ 'reward',
    rewarded_color == 'r' & unrewarded_color == 'b' & triggered_colors == 'blue'  ~ 'selection',
    rewarded_color == 'r' & unrewarded_color == 'b' & triggered_colors == 'green'  ~ 'novel',
    rewarded_color == 'r' & unrewarded_color == 'b' & triggered_colors == 'neutral'  ~ 'neutral',
    
    rewarded_color == 'r' & unrewarded_color == 'g' & triggered_colors == 'red'   ~ 'reward',
    rewarded_color == 'r' & unrewarded_color == 'g' & triggered_colors == 'blue'  ~ 'novel',
    rewarded_color == 'r' & unrewarded_color == 'g' & triggered_colors == 'green'  ~ 'selection',
    rewarded_color == 'r' & unrewarded_color == 'g' & triggered_colors == 'neutral'  ~ 'neutral',
    
    rewarded_color == 'b' & unrewarded_color == 'r' & triggered_colors == 'blue'   ~ 'reward',
    rewarded_color == 'b' & unrewarded_color == 'r' & triggered_colors == 'red'  ~ 'selection',
    rewarded_color == 'b' & unrewarded_color == 'r' & triggered_colors == 'green'  ~ 'novel',
    rewarded_color == 'b' & unrewarded_color == 'r' & triggered_colors == 'neutral'  ~ 'neutral',
    
    rewarded_color == 'b' & unrewarded_color == 'g' & triggered_colors == 'blue'   ~ 'reward',
    rewarded_color == 'b' & unrewarded_color == 'g' & triggered_colors == 'red'  ~ 'novel',
    rewarded_color == 'b' & unrewarded_color == 'g' & triggered_colors == 'green'  ~ 'selection',
    rewarded_color == 'b' & unrewarded_color == 'g' & triggered_colors == 'neutral'  ~ 'neutral',
    
    rewarded_color == 'g' & unrewarded_color == 'b' & triggered_colors == 'blue'   ~ 'selection',
    rewarded_color == 'g' & unrewarded_color == 'b' & triggered_colors == 'red'  ~ 'novel',
    rewarded_color == 'g' & unrewarded_color == 'b' & triggered_colors == 'green'  ~ 'reward',
    rewarded_color == 'g' & unrewarded_color == 'b' & triggered_colors == 'neutral'  ~ 'neutral',
    
    rewarded_color == 'g' & unrewarded_color == 'r' & triggered_colors == 'blue'   ~ 'novel',
    rewarded_color == 'g' & unrewarded_color == 'r' & triggered_colors == 'red'  ~ 'selection',
    rewarded_color == 'g' & unrewarded_color == 'r' & triggered_colors == 'green'  ~ 'reward',
    rewarded_color == 'g' & unrewarded_color == 'r' & triggered_colors == 'neutral'  ~ 'neutral',
    
    TRUE ~ NA_character_  # for any other cases (of which there should be none!)
  ))

master.df.sart.exp2 <- master.df.sart.exp2 %>%
  mutate(distractor_feature = case_when(
    rewarded_color == 'r' & unrewarded_color == 'b' & triggered_colors == 'red'   ~ 'reward',
    rewarded_color == 'r' & unrewarded_color == 'b' & triggered_colors == 'blue'  ~ 'selection',
    rewarded_color == 'r' & unrewarded_color == 'b' & triggered_colors == 'green'  ~ 'novel',
    rewarded_color == 'r' & unrewarded_color == 'b' & triggered_colors == 'neutral'  ~ 'neutral',
    
    rewarded_color == 'r' & unrewarded_color == 'g' & triggered_colors == 'red'   ~ 'reward',
    rewarded_color == 'r' & unrewarded_color == 'g' & triggered_colors == 'blue'  ~ 'novel',
    rewarded_color == 'r' & unrewarded_color == 'g' & triggered_colors == 'green'  ~ 'selection',
    rewarded_color == 'r' & unrewarded_color == 'g' & triggered_colors == 'neutral'  ~ 'neutral',
    
    rewarded_color == 'b' & unrewarded_color == 'r' & triggered_colors == 'blue'   ~ 'reward',
    rewarded_color == 'b' & unrewarded_color == 'r' & triggered_colors == 'red'  ~ 'selection',
    rewarded_color == 'b' & unrewarded_color == 'r' & triggered_colors == 'green'  ~ 'novel',
    rewarded_color == 'b' & unrewarded_color == 'r' & triggered_colors == 'neutral'  ~ 'neutral',
    
    rewarded_color == 'b' & unrewarded_color == 'g' & triggered_colors == 'blue'   ~ 'reward',
    rewarded_color == 'b' & unrewarded_color == 'g' & triggered_colors == 'red'  ~ 'novel',
    rewarded_color == 'b' & unrewarded_color == 'g' & triggered_colors == 'green'  ~ 'selection',
    rewarded_color == 'b' & unrewarded_color == 'g' & triggered_colors == 'neutral'  ~ 'neutral',
    
    rewarded_color == 'g' & unrewarded_color == 'b' & triggered_colors == 'blue'   ~ 'selection',
    rewarded_color == 'g' & unrewarded_color == 'b' & triggered_colors == 'red'  ~ 'novel',
    rewarded_color == 'g' & unrewarded_color == 'b' & triggered_colors == 'green'  ~ 'reward',
    rewarded_color == 'g' & unrewarded_color == 'b' & triggered_colors == 'neutral'  ~ 'neutral',
    
    rewarded_color == 'g' & unrewarded_color == 'r' & triggered_colors == 'blue'   ~ 'novel',
    rewarded_color == 'g' & unrewarded_color == 'r' & triggered_colors == 'red'  ~ 'selection',
    rewarded_color == 'g' & unrewarded_color == 'r' & triggered_colors == 'green'  ~ 'reward',
    rewarded_color == 'g' & unrewarded_color == 'r' & triggered_colors == 'neutral'  ~ 'neutral',
    
    TRUE ~ NA_character_  # for any other cases (of which there should be none!)
  ))

# SART: create a version of master.df.sart that's just the first two blocks (for later analyses)

master.df.sart.exp1.firsthalf <- subset(master.df.sart.exp1, block_number %in% c(1, 2))
master.df.sart.exp2.firsthalf <- subset(master.df.sart.exp2, block_number %in% c(1, 2))

# DECLUTTER!

rm(list = setdiff(ls(), c(
  "master.df.learn.all.exp1",
  "master.df.learn.all.exp2",
  "master.df.learn.exp1",
  "master.df.learn.exp2",
  "master.df.sart.all.exp1",
  "master.df.sart.all.exp2",
  "master.df.sart.exp1",
  "master.df.sart.exp2",
  "master.df.sart.exp1.firsthalf",
  "master.df.sart.exp2.firsthalf",
  "master.traits"
)))
