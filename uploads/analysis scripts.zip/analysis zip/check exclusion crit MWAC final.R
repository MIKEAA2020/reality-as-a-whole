
# TRAINING: check for accuracy outliers 3SD below sample mean [preregistered]

df.accuracy.exp1 <- master.df.learn.all.exp1 %>% 
  group_by(subjectID) %>% 
  summarise(prop_accuracy = mean(accuracy, na.rm = TRUE))

avg_accuracy_exp1 <- mean(df.accuracy.exp1$prop_accuracy)
sd_accuracy_exp1  <- sd(df.accuracy.exp1$prop_accuracy)

below_3sd_subjects_training_accuracy_exp1 <- df.accuracy.exp1 %>%
  filter(prop_accuracy < avg_accuracy_exp1 - 3 * sd_accuracy_exp1) %>%
  pull(subjectID)

cat("EXP1: Subjects with accuracy more than 3 SD below the mean:\n")
print(below_3sd_subjects_training_accuracy_exp1)

df.accuracy.exp2 <- master.df.learn.all.exp2 %>% 
  group_by(subjectID) %>% 
  summarise(prop_accuracy = mean(accuracy, na.rm = TRUE))

avg_accuracy_exp2 <- mean(df.accuracy.exp2$prop_accuracy)
sd_accuracy_exp2  <- sd(df.accuracy.exp2$prop_accuracy)

below_3sd_subjects_training_accuracy_exp2 <- df.accuracy.exp2 %>%
  filter(prop_accuracy < avg_accuracy_exp2 - 3 * sd_accuracy_exp2) %>%
  pull(subjectID)

cat("EXP2: Subjects with accuracy more than 3 SD below the mean:\n")
print(below_3sd_subjects_training_accuracy_exp2)

# SART: check for A-prime outliers 3SD below sample mean [preregistered]

a_prime_exp1 <- master.df.sart.all.exp1 %>%
  mutate(
    hit = case_when(
      is.na(trigger) & accuracy == 1 ~ 1,
      is.na(trigger) & accuracy == 0 ~ 0,
      TRUE                           ~ NA_real_
    ),
    false_alarm = case_when(
      !is.na(trigger) & accuracy == 0 ~ 1,
      !is.na(trigger) & accuracy == 1 ~ 0,
      TRUE                            ~ NA_real_
    )
  ) %>%
  group_by(subjectID) %>%
  summarise(
    hit_rate            = mean(hit, na.rm = TRUE),
    false_alarm_rate    = mean(false_alarm, na.rm = TRUE),
    .groups             = "drop"
  ) %>%
  mutate(
    a_prime = 0.5 +
      ((hit_rate - false_alarm_rate) * (1 + hit_rate - false_alarm_rate)) /
      (4 * hit_rate * (1 - false_alarm_rate))
  )

avg_ap_exp1 <- mean(a_prime_exp1$a_prime, na.rm = TRUE)
sd_ap_exp1  <- sd(a_prime_exp1$a_prime, na.rm = TRUE)

below_3sd_exp1 <- a_prime_exp1 %>%
  filter(a_prime < avg_ap_exp1 - 3 * sd_ap_exp1) %>%
  pull(subjectID)

cat("EXP1: Subjects with A-prime more than 3 SD below the mean:\n")
print(below_3sd_exp1)

a_prime_exp2 <- master.df.sart.all.exp2 %>%
  mutate(
    hit = case_when(
      is.na(trigger) & accuracy == 1 ~ 1,
      is.na(trigger) & accuracy == 0 ~ 0,
      TRUE                           ~ NA_real_
    ),
    false_alarm = case_when(
      !is.na(trigger) & accuracy == 0 ~ 1,
      !is.na(trigger) & accuracy == 1 ~ 0,
      TRUE                            ~ NA_real_
    )
  ) %>%
  group_by(subjectID) %>%
  summarise(
    hit_rate            = mean(hit, na.rm = TRUE),
    false_alarm_rate    = mean(false_alarm, na.rm = TRUE),
    .groups             = "drop"
  ) %>%
  mutate(
    a_prime = 0.5 +
      ((hit_rate - false_alarm_rate) * (1 + hit_rate - false_alarm_rate)) /
      (4 * hit_rate * (1 - false_alarm_rate))
  )

avg_ap_exp2 <- mean(a_prime_exp2$a_prime, na.rm = TRUE)
sd_ap_exp2  <- sd(a_prime_exp2$a_prime, na.rm = TRUE)

below_3sd_exp2 <- a_prime_exp2 %>%
  filter(a_prime < avg_ap_exp2 - 3 * sd_ap_exp2) %>%
  pull(subjectID)

cat("EXP2: Subjects with A-prime more than 3 SD below the mean:\n")
print(below_3sd_exp2)

# DECLUTTER!

rm(list = setdiff(ls(), c(
  "master.df.learn.exp1",
  "master.df.learn.exp2",
  "master.df.sart.exp1",
  "master.df.sart.exp2",
  "master.df.sart.exp1.firsthalf",
  "master.df.sart.exp2.firsthalf",
  "master.traits"
)))

