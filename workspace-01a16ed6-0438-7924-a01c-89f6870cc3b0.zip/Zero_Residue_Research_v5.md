# Toward zero residue — constructive round 5
## Reduce the reconstruction assumptions; expose their actual content

**24 October 2026**  
**Continues:** [Round 4](./Zero_Residue_Research_v4.md).  
**Status:** the explicit Jordan-algebra postulate is replaced by operational conditions with a known representation theorem; full contrast–generator reciprocity is replaced by a weaker condition or avoided through a composition route. Independent countermodels and exact calculations delimit the result. **The remaining principles have not been proved metaphysically necessary.**

## What changes in the account

Round 4 postulated a finite simple Jordan algebra and a bijective, covariant pairing between nonconstant contrasts and change generators. It derived complex quantum structure conditionally, but left both starting requirements unexplained.

This round improves that construction in three ways:

1. **Derive rather than directly postulate the Jordan representation.** A finite compact convex state space with spectrality and strong frame symmetry has the required Jordan form, or is classical. This uses the established Barnum–Hilgert theorem. [1](https://arxiv.org/abs/1904.03753)
2. **Remove full reciprocity as a starting requirement.** A weaker linear assignment of conserved observable values to dynamics suffices for the complex selection within the reconstructed class. This uses the energy-observability result of Barnum, Müller, and Ududec. [2](https://arxiv.org/html/1403.4147v4)
3. **Supply an alternative route without that conserved-value assignment.** Local tomography plus multiplicative distinguishability capacity, with ordinary independent composition and nontrivial continuous reversibility, selects the complex family by a rank-and-dimension argument.

The new countermodels show exactly why these conditions cannot simply be renamed “intelligibility” and assumed to follow automatically.

**Main revision:** contrast–generator reciprocity remains available in the resulting complex model, but is no longer treated as a required primitive for selecting that model. The round-4 conditional theorem remains valid; its assumptions were stronger than needed for that task.

---

# 1. Recover an operational state structure from comparisons and mixing

## 1.1 What an operational state is—and is not

Take a preparation procedure P and the probabilities it assigns to a specified set of possible comparisons or effects. Declare two preparations operationally equivalent when every admitted comparison gives the same probabilities.

An operational state is the resulting equivalence class.

This is already an abstraction. Two preparations can be equivalent on a selected subsystem while differing elsewhere, for example in a retained environmental record. It does not follow that they are the same complete concrete occurrence, or have the same phenomenal character.

Thus this construction primarily develops the **public structural interface Π**. Its interpretation as the full intrinsic nature of a presented episode remains unproved.

## 1.2 A limited derivation of affinity

Suppose an internal preparation procedure chooses P with probability λ and Q otherwise, and the choice record is then omitted from the comparisons defining the state. The total-probability rule gives:

\[
p(e\mid M_\lambda(P,Q))
=\lambda p(e\mid P)+(1-\lambda)p(e\mid Q).
\]

Consequently, the operational state of the randomized preparation is:

\[
\omega_{M_\lambda(P,Q)}=\lambda\omega_P+(1-\lambda)\omega_Q.
\]

The induced effects are affine functions on that state space.

**What follows:** if these probabilistic mixing procedures are admitted, affinity is not an independent lookup rule for every measurement.

**What does not follow:** the existence of probability, arbitrary randomization procedures, real-valued continuity, finite-dimensionality, or an ontic mixture of experiences. The argument uses ordinary probabilistic consistency; it does not derive probability from phenomenality.

No outside experimenter is required in the ontology. Preparations, records, and comparisons can all be internal processes. But their internality does not itself explain their existence or laws.

## 1.3 The model setting

For this round, assume a nontrivial finite-dimensional compact convex normalized state space Ω. Write:

\[
D=\dim(\operatorname{aff}\Omega)+1
\]

for the dimension of its associated unnormalized state space.

We use all affine effects e with 0 ≤ e(ω) ≤ 1 on Ω, and measurements consisting of effects that sum to 1. When interpreted physically, allowing all these effects is a measurement-completeness assumption. It must not be confused with the mere fact that an affine function can be written down.

Admitted reversible transformations form a closed subgroup G of the affine automorphism group. This gives a compact Lie-group setting in finite dimensions; closure under limits is part of the framework. G may be smaller than the full mathematical automorphism group. The symmetry assumptions below concern transformations admitted in the model, not merely changes of notation.

This remains a finite-sector construction, not an assertion that all reality is a finite convex set.

---

# 2. Replace the Jordan product postulate with two operational requirements

## 2.1 Frames and distinguishability

A frame is an ordered list of pure states (extreme points of Ω) that one measurement can distinguish perfectly. For a frame ω₁,…,ωₙ, effects e₁,…,eₙ satisfy:

\[
e_i(\omega_j)=\delta_{ij},
\qquad \sum_i e_i=1.
\]

Let N be the maximum frame size: the system's distinguishability capacity.

“Pure” means extremal in this convex representation. It does not mean conscious, phenomenally simple, or absolutely known by an omniscient observer.

## 2.2 SP — Spectrality

Every operational state is a convex combination of pure states belonging to one perfectly distinguishable frame:

\[
\omega=\sum_i\lambda_i\omega_i,
\qquad \lambda_i\ge0,\qquad\sum_i\lambda_i=1.
\]

This is much stronger than saying that a state is a mixture of pure states. In finite compact convex spaces, pure-state mixtures are generally available without the components being jointly distinguishable. SP requires a decomposition within one discriminating frame.

## 2.3 FH — Frame homogeneity, or strong symmetry

For any two ordered frames of the same length, an admitted reversible transformation takes the first to the second.

FH includes pure-state transitivity and permutations of a frame. It does not say that the actual state or Hamiltonian is symmetric, or that all felt contents are qualitatively identical.

It is also not mere invariance under renaming. A passive relabelling describes the same organization differently; FH asserts the availability of active reversible maps between alternatives within the model.

## 2.4 The representation theorem

The Barnum–Hilgert theorem states:

> A finite-dimensional compact convex set is spectral and strongly symmetric if and only if it is a simplex or affinely isomorphic to the normalized state space of a simple Euclidean Jordan algebra. [1](https://arxiv.org/abs/1904.03753)

Thus the operational requirements give the Jordan representation, including algebraic simplicity in the nonclassical case. Neither a Jordan product nor simplicity has to be inserted separately at this stage.

No additional no-higher-order-interference postulate is needed for this quoted state-space characterization. The earlier reconstruction of Barnum, Müller, and Ududec used that extra postulate; the later Barnum–Hilgert result removes it for the characterization. [1](https://arxiv.org/abs/1904.03753) [2](https://arxiv.org/html/1403.4147v4)

**Proof boundary:** this is a cited classification/representation theorem. The present script does not reprove its global convex-geometric proof. It tests its assumptions and consequences in explicit models.

**Explanatory boundary:** replacing an algebraic package with operational conditions makes the content clearer and more testable. It does not establish that those conditions are inevitable features of reality or experience.

---

# 3. Test whether spectrality and frame homogeneity are automatic

They are not consequences of generic convex consistency. Three models separate the relevant claims.

## 3.1 A regular pentagon: frame homogeneity without spectrality

Let Ω be the convex hull of five equally spaced unit-circle vertices, with all affine effects allowed.

The perfectly distinguishable pure pairs are the five diagonal pairs. Each such pair can be distinguished by a supporting affine effect. Adjacent vertices cannot be simultaneous maximum and minimum of an effect bounded between 0 and 1 on the pentagon.

There is no three-state frame. For a nonnegative affine effect to vanish at two different vertices, those vertices must lie on one supporting edge, unless the effect is identically zero. A three-state frame would require every pair among the three vertices to be an edge. The pentagon has no such triangle of edges.

Its capacity is therefore 2. The dihedral group is transitive on its five pure states and on its ten ordered diagonal pairs. Hence it satisfies FH.

But its center is not on any diagonal segment. The distance from the center to every frame segment is:

\[
\cos(2\pi/5)=\frac{\sqrt5-1}{4}\approx0.309017.
\]

The center is a mixture of all five vertices, but not a mixture within any pure distinguishable frame. Therefore SP fails.

**Consequence:** strong symmetry does not by itself give spectrality in the broad finite convex setting.

The frame feasibility and group orbits were independently enumerated. Numerical LP agrees with the supporting-line argument; the non-spectrality obstruction also has the exact geometric value displayed above.

## 3.2 A point joined to a disk: spectrality without frame homogeneity

Consider states:

\[
\Omega_J=\{(p,\mathbf r):0\le p\le1,
\ |\mathbf r|\le1-p,\ \mathbf r\in\mathbb R^2\}.
\]

Its pure states are an apex c = (1,0) and the circle of base points bₙ = (0,n), |n| = 1.

For r ≠ 0, put n = r/|r|. Every state has the decomposition:

\[
(p,\mathbf r)
=p\,c+\frac{1-p+|\mathbf r|}{2}b_{\mathbf n}
+\frac{1-p-|\mathbf r|}{2}b_{-\mathbf n}.
\]

For r = 0 choose any unit n. The three states are perfectly distinguishable using:

\[
e_c=p,\qquad
 e_\pm=\frac{1-p\pm\mathbf n\cdot\mathbf r}{2}.
\]

These effects are nonnegative, sum to 1, and produce the required delta values on the frame. Thus SP holds.

At most two pure base-disk states can be distinguished perfectly, so the joined model has capacity exactly 3. FH fails even for one-state frames: the apex is an isolated point of the pure-state set, whereas the base pure states form a circle. No affine automorphism can exchange these topologically different kinds of pure state.

This is also a simple example of a nonsimple Jordan representation—a classical sector joined to a real two-level sector. Spectrality alone does not select an irreducible component.

The script checked 512 random states against the decomposition and distinguishing effects; the general proof is the displayed formula and inequality.

## 3.3 A square: pure-state transitivity is weaker than FH

The square has a vertex-transitive symmetry group and capacity 2. Both adjacent and opposite vertex pairs are perfectly distinguishable, but no affine automorphism maps an edge pair to a diagonal pair.

There are two orbits of ordered two-state frames: sizes 8 and 4. Hence pure-state transitivity alone does not imply FH.

## 3.4 What these countermodels establish

They refute the stated entailments from generic operational assumptions. They do not prove that these models are metaphysically possible worlds, or that any of them experiences.

They also do not establish logical minimality of the full reconstruction package. For example, the pentagon has a discrete reversible group; it is a counterexample to FH ⇒ SP in the broad setting, not a proof about every strengthened package that also requires continuous dynamics.

**Result:** SP and FH carry substantive content. Neither may be justified simply by saying that a fully intelligible reality cannot contain arbitrary labels.

---

# 4. Weaken full contrast–generator reciprocity

## 4.1 EO — Faithful conserved-value assignment

Instead of starting with a bijective, covariant map from all nonconstant contrasts to all generators, require:

- nontrivial continuous reversible transformations;
- a linear assignment of an observable to every infinitesimal generator;
- different generators receive distinct observable functions modulo constant offsets;
- each assigned observable is conserved by its own generated evolution.

In the spectral/FH setting, the reversible group is pure-state transitive. Its invariant state μ is unique. Subtracting the value at μ removes arbitrary constant offsets from observables.

Write A₀ for the centered affine observables a satisfying a(μ) = 0. The condition becomes an injective linear map:

\[
\Phi:\mathfrak g\longrightarrow A_0,
\qquad
\Phi(X)(e^{tX}\omega)=\Phi(X)(\omega).
\]

Equivalently, in the homogeneous linear representation:

\[
\Phi(X)\circ X=0.
\]

In the nonclassical spectral/FH cases, the connected dynamics is pure-state transitive, and its globally invariant affine observables are constants. Finite classical models instead have a trivial connected group and are excluded separately by EO. Thus centering and injectivity implement the nontriviality requirement in the energy-observability definition.

This is the relevant centered version of the energy-observability postulate of Barnum, Müller, and Ududec. Their definition assigns generators conserved observables, excluding the case in which a nonzero generator receives a globally trivial label. [2](https://arxiv.org/html/1403.4147v4)

**Not assumed now:** surjectivity onto all contrasts, covariance of the assignment, or that every contrast generates a motion. EO concerns a consistent assignment across all admitted generators, not just one observed Hamiltonian trajectory.

## 4.2 The complex selection still follows

Combine:

1. SP and FH, which give a simplex or simple Jordan state space;
2. EO, which excludes the finite simplex and selects the complex matrix case among the Jordan alternatives.

The second step is the established Jordan energy-observability result. This exclusion of finite classical state spaces does not exclude classical phase-space mechanics, whose operational distribution space is infinite-dimensional. The general theorem covers the relevant reversible groups; the elementary calculations below examine the full rotation/matrix groups, not every possible transitive subgroup. [2](https://arxiv.org/html/1403.4147v4)

The energy-observability theorem also supplies all connected unitary conjugations as admitted reversible transformations. [2](https://arxiv.org/html/1403.4147v4) Thus, after complex selection, the connected generator and centered-observable dimensions both equal n² − 1. The injective assignment is therefore bijective. A canonical commutator correspondence covariant under the connected unitary group is available, as in round 4. Covariance under every possible disconnected state-space automorphism is not being inferred.

Thus bijection need not be a primitive type-selection assumption. “Weaker” here means less is directly required of the initial map; it does not assert strict inequivalence of the existence conditions after all finite reconstruction assumptions are added. This also does not identify every physically calibrated assignment with a particular clock and energy scale.

## 4.3 An elementary derivation for ball-shaped systems

For the full rotation group on a d-dimensional ball, a centered affine observable has the form b · r. Let a linear assignment associate b(A) to a skew matrix A generating ṙ = Ar.

Conservation for all states requires:

\[
A\,b(A)=0.
\]

Linearity and polarization give:

\[
A\,b(B)+B\,b(A)=0.
\]

Choose the elementary rotation matrices Kᵢⱼ.

**For d = 2:** the sole elementary rotation is invertible, so its assigned vector must vanish. No nonconstant assignment exists.

**For d ≥ 4:** first Kᵢⱼ b(Kᵢⱼ) = 0 forces the i and j components of b(Kᵢⱼ) to vanish. For disjoint pairs (i,j) and (k,l), polarization gives:

\[
K_{ij}b(K_{kl})+K_{kl}b(K_{ij})=0.
\]

The two terms occupy disjoint coordinate planes. Therefore the k and l components of b(Kᵢⱼ) vanish too. Every outside component can be paired with a fourth index; hence b(Kᵢⱼ) = 0 for every elementary generator. The entire map is zero.

**For d = 3:** each elementary rotation can receive a label along its perpendicular axis. Polarization fixes the relative coefficients, leaving a single common scalar. In axial-vector notation:

\[
A_{\boldsymbol\omega}\mathbf r
=\boldsymbol\omega\times\mathbf r,
\qquad
b(A_{\boldsymbol\omega})=\kappa\boldsymbol\omega.
\]

Every nonzero such assignment is injective, surjective, and covariant under proper rotations.

**This sharpens the round-4 result:** for full rotation balls, even the existence of a nonzero linear conserved-label assignment selects d = 3; equality of counts and full reciprocity need not be independently postulated.

The exact solver finds assignment-space dimensions 0, 1, 0, 0, 0, 0 for d = 2,…,7. The general exclusion is the argument above, not an extrapolation from those six cases.

## 4.4 Matrix checks

The script also solves every coefficient of a centered linear conserved-label assignment for standard matrix groups. It obtains:

| Model | Dimension of the space of linear conserved-label assignments |
|---|---:|
| Real symmetric 2 × 2 | 0 |
| Real symmetric 3 × 3 | 0 |
| Real symmetric 4 × 4 | 0 |
| Complex Hermitian 2 × 2 | 1 |
| Complex Hermitian 3 × 3 | 1 |

In the complex cases, each nonzero solution is a common scalar multiple of the canonical Hamiltonian assignment and has full rank. These are exact linear-algebra results for the listed cases, not statistical fits. They do not assert that every individual higher-level real flow lacks a conserved observable: the obstruction concerns one linear assignment across all generators. The general family-selection claim relies on the theorem, not just these checks.

## 4.5 Why “all real changes are observable” does not prove EO

The two-dimensional disk already satisfies SP and FH. It also has completely explicit, observable rotations.

Start at r = (1,0). Under rotations of speed +1 and −1, the effect e_y = (1 + r_y)/2 at time π/2 has probabilities 1 and 0. The two processes are perfectly distinguishable in that experiment.

Yet every affine observable conserved under all states of a nonzero disk rotation is constant. EO fails.

Therefore:

> Observability of processes is not the same as a faithful linear assignment of conserved state observables to their generators.

This blocks a tempting but invalid justification of reciprocity. EO remains an organizing law requiring a reason; it is not a restatement of operational observability or the absence of an external executor.

---

# 5. A second route: use composition instead of conserved-value labels

We can also avoid EO altogether, at the cost of explicit composition assumptions.

## 5.1 The additional commitments

For a system A and an independently prepared copy:

**IC — Ordinary independent composition:** product preparations and product comparisons exist and have the usual factorized probabilities; local reversible transformations extend faithfully to the composite.

**LT — Local tomography:** all product-comparison statistics determine the joint state.

**CM — Capacity multiplication:** distinguishability capacity multiplies:

\[
N_{AA}=N_A^2.
\]

Independent product frames already give a lower bound N_A². CM asserts that putting systems together does not introduce additional jointly distinguishable alternatives beyond that bound.

**CR — Nontrivial continuous reversibility:** the full systems under investigation have a nontrivial connected reversible group. This excludes finite simplices. Local reversible operations extend to composites, so a nontrivial continuous local group also supplies a nontrivial composite group.

SP and FH must hold for the admitted self-composite as well as for the original system.

These are assumptions, not consequences of saying “systems interact.” In particular, LT and CM are separate commitments; neither is silently inferred from the other here.

## 5.2 Why local tomography gives dimension multiplication

Independent product preparations span at least a D_A²-dimensional product subspace. Product comparisons separate those product directions, so their embedding cannot collapse that dimension.

Local tomography gives an injective representation of all joint states by those product statistics, limiting joint dimension to at most D_A². Together:

\[
D_{AA}=D_A^2.
\]

Both independent preparation and joint statistical completeness do work in this argument. Dimension multiplication is not obtained merely by defining a tensor symbol.

## 5.3 Use Jordan rank and dimension

SP and FH give simple Jordan models or simplices. CR excludes the finite simplices. For simple Jordan models, capacity is rank.

For rank n ≥ 2, the matrix families have full unnormalized dimensions:

\[
D_{\mathbb R}(n)=\frac{n(n+1)}2,
\qquad D_{\mathbb C}(n)=n^2,
\qquad D_{\mathbb H}(n)=n(2n-1).
\]

A self-composite has rank n² ≥ 4. At that rank, the only simple Jordan possibilities are the real, complex, and quaternionic matrix families. Spin factors have rank 2 and the exceptional Albert algebra has rank 3.

### Real family

The required joint dimension lies below even the smallest available rank-n² Jordan dimension:

\[
D_{\mathbb R}(n^2)-D_{\mathbb R}(n)^2
=\frac{n^2(n-1)^2}{4}>0.
\]

So no choice of simple Jordan family for the composite can meet both LT and CM.

### Quaternionic family

The required joint dimension exceeds even the largest available rank-n² Jordan dimension:

\[
D_{\mathbb H}(n)^2-D_{\mathbb H}(n^2)
=2n^2(n-1)^2>0.
\]

Again no simple Jordan composite can fit.

These exclusions do **not** assume that a system and its composite must belong to the same family. The inequalities compare against the minimum and maximum among all rank-n² possibilities.

### Spin factors

A rank-2 spin factor with d-dimensional ball has full dimension d + 1. Its self-composite must have rank 4, whose possible Jordan dimensions are 10, 16, and 28.

LT requires (d + 1)² to equal one of those numbers. Only 16 is an integer square, giving d = 3: the complex qubit.

### Exceptional algebra

The rank-3 Albert algebra has dimension 27. Its self-composite would have rank 9 and required dimension 729. The available rank-9 Jordan dimensions are 45, 81, and 153. None fits.

### Complex family

For the complex models:

\[
D_{\mathbb C}(n^2)=D_{\mathbb C}(n)^2=n^4.
\]

The usual complex composite realizes the required capacities and dimensions.

## 5.4 The result and its exact scope

> **Composition-route selection.** In the finite framework with SP and FH for systems and self-composites, ordinary independent composition, LT, CM, and nontrivial continuous reversibility, the surviving nonclassical state-space types are the complex Hermitian matrix models.

This is an elementary classification-based selection argument, not a new discovery claim. Composition-based characterizations of complex quantum structure are an established alternative to conserved-generator assumptions; the earlier reconstruction literature explicitly discusses this trade. [2](https://arxiv.org/html/1403.4147v4)

The proof selects state-space types and constrains composition. Matching rank and dimension alone is **not** a uniqueness proof for every composite embedding, intervention structure, or actual dynamics. The standard complex tensor product is a compatible realization; recovering its full physical status requires the composition maps and processes too.

No energy-label assignment or full CGR was needed for this selection route.

---

# 6. Test whether interaction itself forces the composition assumptions

It does not. Real quantum theory provides a precise alternative that can interact while failing local tomography.

## 6.1 A hidden joint distinction

A real two-level system has observable span {I,X,Z}, dimension 3. Two real two-level systems have real symmetric 4 × 4 observables, dimension 10. Products of local real observables span only 3 × 3 = 9 dimensions.

The missing direction is Y ⊗ Y. Although Y is not a real one-system observable, Y ⊗ Y is a real symmetric joint observable.

Consider the valid real density matrices:

\[
\rho_\pm=\frac{I_4\pm Y\otimes Y}{4}.
\]

Each has spectrum {0,0,1/2,1/2}. For every pair of real local observables A and B:

\[
\operatorname{Tr}(\rho_+A\otimes B)
=\operatorname{Tr}(\rho_-A\otimes B).
\]

It suffices to check the nine products of the local basis; all differences are exactly zero. But the allowed joint effect:

\[
Q_+=\frac{I_4+Y\otimes Y}{2}
\]

gives probabilities 1 and 0 on ρ₊ and ρ₋ respectively.

Thus the two states agree on **all local product statistics**, not merely on their marginals, while differing jointly. LT fails.

## 6.2 A genuine reversible interaction remains possible

Let:

\[
J=\begin{pmatrix}0&-1\\1&0\end{pmatrix},
\qquad K=J\otimes X.
\]

K is real skew-symmetric, so U(t) = exp(tK) is a reversible real orthogonal transformation. At time π/4:

\[
U(\pi/4)|00\rangle
=\frac{|00\rangle+|11\rangle}{\sqrt2}.
\]

This is entangled; either reduced state's purity is 1/2. The transformation cannot be just a product of independent local rotations, since it turns a product pure state into an entangled one.

All of these statements were checked exactly.

**Conclusion:** the existence of real interactions and joint distinctions does not force LT. This alternative is mathematically coherent at the operational level; that does not prove it is a metaphysically possible or actual world.

The counterexample does not refute the composition route. It shows which assumption excludes this alternative, and why that assumption must be justified independently.

---

# 7. What has genuinely been derived, and what remains an input?

## 7.1 The revised dependency structure

The current reconstruction has two paths:

\[
\text{probabilistic mixing assumptions}
\ \Longrightarrow\ \text{operational convex/affine representation},
\]

followed by:

\[
\text{SP}+\text{FH}
\ \Longrightarrow\ \text{simple Jordan or classical state space},
\]

and then either:

\[
\text{EO}
\ \Longrightarrow\ \text{complex quantum state-space type},
\]

or:

\[
\text{independent composition}+\text{LT}+\text{CM}+\text{CR}
\ \Longrightarrow\ \text{complex quantum state-space type}.
\]

Each arrow has a stated scope. The first does not establish probability or compact finite-dimensionality; the later arrows do not establish concrete instantiation.

In the complex model, the canonical value–change correspondence, trace probabilities, and reversible commutator form from round 4 remain available. Its actual Hamiltonian, clock calibration, initial conditions, and spacetime interpretation remain unselected.

## 7.2 The distinction between reduction and renaming

This is a reduction of the starting burden in a specific sense:

- The Jordan algebra no longer needs to be postulated as an unexplained full algebraic package; its representation follows from SP and FH in the chosen framework.
- Full bijective, covariant reciprocity is unnecessary as a primitive selection rule. EO is weaker, or a composition route avoids it.
- Several familiar structures now have a shared dependency rather than separate lookup rules.

It is not a proof that the new principles are ultimate explanations. Decomposing one axiom package into more interpretable requirements can clarify its content without reducing every kind of philosophical residue. Fewer symbols or more familiar wording do not by themselves produce greater metaphysical necessity.

## 7.3 What generic intelligibility does not yet supply

The countermodels establish that none of the following shortcuts is valid:

- “Every state is a pure-state mixture, therefore SP.” The distinguishability requirement is extra.
- “All pure alternatives can be transformed into one another, therefore FH.” The square separates these.
- “There are no arbitrary labels, therefore the required active symmetries exist.” Passive coordinate freedom does not supply active transformations.
- “Every real change is observable, therefore EO.” The disk rotations separate these.
- “Systems genuinely interact, therefore LT.” The real two-system interaction separates these.
- “A structure is uniquely selected conditionally, therefore it exists concretely or necessarily.” The earlier actualization gap remains.

These are formal non-entailments, not blanket impossibility results about deeper constitutive arguments.

## 7.4 Subjecthood and qualitative character are not supplied by the representation theorem

SP, FH, EO, and LT are statements about operational comparisons and possible processes. None directly states what is felt, which contents are co-conscious, or which organizations constitute subjects.

An algebraically simple state space is still not a phenomenal unity criterion. Whole and subsystem complex algebras can satisfy the reconstruction conditions simultaneously, as round 4 demonstrated.

Nor may convex decompositions be read as literal sums of microscopic experiences. Their primary role here is to represent public statistical equivalence classes.

The intrinsic-presentation proposal remains a constitutive hypothesis. This reconstruction develops part of Π and constrains a possible relational component of Q; it does not complete Σ or full Q.

---

# 8. Update the lead account and the zero-residue obligation

## 8.1 The improved candidate

> Investigate a concrete qualitative-relational constitution whose operational distinctions admit spectral resolution and frame homogeneity. Its public state-space structure then has Jordan form. If dynamics admits faithful conserved-value labels—or if composition instead satisfies the stated local-completeness and capacity constraints—the complex quantum family follows. Experiential subjecthood, where it occurs, is a concrete unity of presentation, not an additional inner spectator. But the constitution must still explain why these operational constraints hold, which organizations present, what their qualities are, and why any realization exists.

The alternatives in the middle are not evidence that both principles are independent extra ingredients of reality. They are different sufficient reconstruction routes. Their deeper relation may reduce the burden further, but has not been established here.

## 8.2 The assumption ledger

| Item | Current status |
|---|---|
| Some experience is actual | Starting datum |
| Affinity of operational effects | Follows given the admitted probabilistic mixing/forgetting procedures |
| Probability, real scalars, compact finite-sector representation | Still framework assumptions |
| Full affine effect availability | Explicit model commitment |
| SP: every state resolves within one distinguishing pure frame | Substantive postulate; not generic pure-state mixing |
| FH: reversible equivalence of equal-size frames | Substantive postulate; not merely relabelling or pure-state transitivity |
| Jordan representation and nonclassical simplicity | Follow from SP + FH via the cited theorem |
| Full CGR | Removed from the starting selection requirements |
| EO | Weaker sufficient dynamical postulate; not implied by process observability |
| Independent composition, LT, CM, continuous reversibility | Alternative sufficient route; each stated explicitly |
| Complex state-space type | Selected conditionally on either package |
| Canonical complex value–change structure | Available after selection; actual calibration not fixed |
| Unique actual interactions/history | Not selected |
| Subject boundaries and full phenomenal character | Not derived |
| Definite experienced outcomes | Not derived |
| Necessary concrete existence | Not derived |

The conditions apply to the full candidate sectors under investigation. Restricted measurement contexts, classical records, or mixtures of superselection sectors need not inherit every condition. It would be a mistake to infer that every subsystem appearing in an effective description must satisfy the whole reconstruction package.

## 8.3 The next constitutive target is now precise

For these two routes, the common unresolved core is **spectral resolution and active frame homogeneity**, plus either the dynamical-label condition or the composition conditions.

A deeper account must establish why a concrete presentational nature has those properties, or show how they emerge from more fundamental constraints. Their recovery of familiar quantum mathematics is not, by itself, their justification.

The explicit countermodels identify what such an argument would have to exclude. It cannot rely only on convex coherence, finite distinguishability, observable change, or the existence of interaction.

Separately, an account of phenomenal actuality must connect the operational representation to a genuinely presented occurrence rather than merely label the representation conscious.

Finally, necessary structure does not entail necessary realization. Even if a proposed concrete kind must have a particular structure whenever it exists, that does not show that the kind exists in every possibility. The backing/rooting and actualization questions of rounds 2–3 remain live.

### Research verdict

This round makes the account less dependent on a specially tailored reciprocity axiom and an opaque algebraic starting package. It gives two explicit routes to the same public state-space family and supplies countermodels separating the premises from weaker slogans.

That is constructive progress: more of the organizing structure follows from fewer **kinds of independent assignment**, and the remaining inputs are clearer. It is still **conditional explanatory integration**, not a fully intelligible zero-residue account of reality.

---

# Reproducibility and source boundaries

## Files

- **Script:** `zero_residue_research/round5_checks.py`
- **Results:** `zero_residue_research/round5_results.json`
- **Run:** `python zero_residue_research/round5_checks.py`
- **Dependencies:** Python 3, NumPy, SciPy, SymPy.

The script ran successfully; all implemented assertions passed.

### What was actually computed

- All pure frames of sizes 1–3 for the triangle, square, and pentagon, using affine-effect linear-program feasibility, with decided feasible/infeasible statuses. Supporting-geometry arguments in the text supply the corresponding analytic reasoning. No higher pure-frame size is possible once every triple is ruled out.
- Dihedral orbits of all resulting ordered frames.
- The pentagon center's distance from all possible frame segments: approximately 0.3090169944.
- The joined model's spectral decomposition and effect values on 512 sampled states; the general formula is proved in the text.
- Exact coefficient spaces of all centered linear conserved-label assignments for balls d = 2,…,7 and real/complex matrix examples.
- A classification-data screen for self-composite rank/dimension compatibility, with the two general positive-gap formulas verified symbolically. The global proof is the classification-based argument in §5, not finite enumeration alone.
- Exact equality of all nine real local-product expectations for the two hidden-joint-distinction states, exact joint discrimination, positivity, and an orthogonal entangling interaction.

LP calculations use floating-point geometry and feasibility tolerances. Exact symbolic assignment and matrix calculations use rational/complex algebra. Neither is an empirical consciousness experiment or an unrestricted metaphysical model checker.

## Primary sources used

1. **Barnum and Hilgert, “Strongly symmetric spectral convex bodies are Jordan algebra state spaces,” arXiv:1904.03753**; the published work is titled *Spectral Properties of Convex Bodies*. Theorem 1.1, the introduction, and the convex/effect framework were directly consulted in the accessible arXiv text. The global classification proof was not independently reproduced here. [1](https://arxiv.org/abs/1904.03753)
2. **Barnum, Müller, and Ududec, “Higher-order interference and single-system postulates characterizing quantum theory,” arXiv:1403.4147v4.** The introduction, energy-observability definition, Theorem 31 and part of its proof, and the discussion of composition alternatives were directly consulted. The full transitive-group classification appendix was not independently checked. Its older open question about whether spectrality plus strong symmetry suffice must be read in light of the later Barnum–Hilgert theorem. [2](https://arxiv.org/html/1403.4147v4)

The quoted representation and energy-observability theorems are established results. The dimension argument, explicit models, and computations above are supplied to make their use in this programme transparent, not to claim discovery of the quantum-reconstruction literature.
