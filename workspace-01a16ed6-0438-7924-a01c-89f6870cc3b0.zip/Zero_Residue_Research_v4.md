# Toward zero residue — constructive round 4
## Intrinsic contrasts, generators, and a conditional quantum core

**24 October 2026**  
**Continues:** [Round 3](./Zero_Residue_Research_v3.md).  
**Status:** a specific value–change constitution is proposed; a conditional selection theorem and associated probability, dynamics, geometry, and composition results are developed and checked. **Neither phenomenal constitution nor necessary concrete existence has been proved.**

## What this round adds

Round 3 ended by prioritizing intrinsic nature rather than another scalar consciousness score. Here is the attempted construction:

> The distinctions within a candidate concrete presentation have two coordinated roles: ways the occurrence is differentiated, and ways its other distinctions can transform. Public physics describes these value and change roles. They are not two substances exchanging signals.

The exact hypothesis developed below is **contrast–generator reciprocity**: the nonconstant distinctions and the generators of reversible change correspond linearly, one-to-one, and covariantly.

This is substantially stronger than saying “everything is related” or “consciousness is information.” It imposes mathematical constraints that many candidate structures fail.

**Main conditional result:** within nontrivial, finite-dimensional, simple Euclidean Jordan models, this reciprocity selects the complex Hermitian matrix algebras. Covariance gives reciprocal conservation; positive states give the Born trace form; continuous closed reversible changes give commutator dynamics. The smallest selected factor also has a Lorentz-shaped positive cone. A state-dependent discrimination metric can be derived from its complete sharp-contrast family rather than a handpicked response channel.

These are conditional mathematical achievements. **The postulates have not been derived from experience, and a Jordan algebra has not thereby been shown to experience.** The connection to known reconstruction and dynamical-correspondence mathematics is explicit, not presented as a new discovery. [12](https://www.pnas.org/doi/10.1073/pnas.95.12.6596) [3](https://arxiv.org/html/2006.14741)

---

# 1. Specify the proposed nature instead of leaving “intrinsic” blank

## 1.1 A value–change constitution

The lead idea is that a concrete occurrence's differentiations and powers are inseparable aspects of its nature:

- a **value role**: how the occurrence is differentiated relative to a contrast;
- a **change role**: how that contrast generates transformations of other contrasts;
- a **consistency structure** tying the roles together.

For an experiential occurrence, the value role would be intrinsic qualitative differentiation—not a picture shown to another observer. But the mathematical construction below supplies only a candidate structure for such differentiation. It does not tell us what redness feels like, or turn an abstract tuple into a felt occurrence.

We model the structural part by:

\[
\mathfrak K=(J,\omega,\psi),
\]

where J describes contrasts, ω their state-dependent expectations/probabilities, and ψ their change roles.

The concrete realization, its phenomenal character, and the unity of an episode are **not established merely by specifying this tuple**. “Observable” here means a potential discriminating quantity; it does not imply an observer, actual measurement, or experience.

## 1.2 Why try this particular connection?

The existing programme rejects a passive intrinsic stuff whose activity must be supplied by an external executor. It is therefore reasonable to investigate a nature whose differences also constrain its possible changes.

But that motivation does not prove a one-to-one correspondence. The same concrete thing can have differently structured roles. One-occurrence identity, explanatory economy, and the absence of an outside executor **do not logically entail reciprocity**.

Reciprocity is the substantive candidate law to be tested and, eventually, justified or replaced.

## 1.3 The mathematical assumptions

### J — A finite spectral contrast algebra

For the present construction, J is a finite-dimensional, unital Euclidean Jordan algebra. It is a real vector space with a commutative bilinear product ∘, unit 1, and:

\[
a^2\circ(a\circ b)=a\circ(a^2\circ b),
\qquad a^2=a\circ a.
\]

It is formally real: a sum of squares can vanish only if each squared element vanishes. Equivalently in finite dimensions, it has a compatible positive inner product. Positivity comes from its cone of squares.

This allows an internally coherent spectral calculus: powers and functions of a single contrast have unambiguous meanings. For suitable squaring structure, the mixed product can be recovered by polarization:

\[
a\circ b=\frac12\big((a+b)^2-a^2-b^2\big).
\]

**Not derived here:** why actual intrinsic differentiation must satisfy these algebraic assumptions. A functional calculus is a motivation, not a proof of all the Jordan conditions. The physical meaning of the full Jordan product is itself nontrivial, as the reconstruction literature emphasizes. [2](https://arxiv.org/pdf/1606.09331) [3](https://arxiv.org/html/2006.14741)

We initially examine a **simple**, nontrivial J: it has no nonzero proper Jordan ideals and more than one dimension. Simplicity is an algebraic condition, **not a definition or proof of phenomenal unity**.

This is a finite-sector construction. It does not assume that total reality is finite-dimensional. Real scalars, linearity, the finite-sector restriction, and continuous reversible transformations are assumptions too; none follows merely from finite experiential data.

### S — Positive normalized probabilistic states

A state is a real linear functional:

\[
\omega:J\to\mathbb R,
\qquad \omega(a)\ge0\text{ for }a\ge0,
\qquad \omega(1)=1.
\]

For an effect e satisfying 0 ≤ e ≤ 1, ω(e) is its probability.

This introduces a probabilistic framework. It does not derive probability from nonprobabilistic phenomenology. Convex mixtures of these states must not be identified automatically with mixtures of felt experiences.

### CGR — Contrast–generator reciprocity

CGR is distinct from the rooting condition called R in round 2.

Let J₀ be the trace-free contrasts, equivalently J modulo constant multiples of 1. Let Der(J) be the real Lie algebra of Jordan derivations:

\[
D(a\circ b)=D(a)\circ b+a\circ D(b).
\]

Their exponentials are continuous reversible Jordan automorphisms. We postulate a linear bijection:

\[
\psi:J_0\longrightarrow\operatorname{Der}(J).
\]

It must transform naturally under the **connected** automorphism group:

\[
\psi_{g(a)}=g\psi_a g^{-1}.
\]

Constants are removed because they do not express differences among states of this fixed algebra. The reciprocity pairs nonconstant contrasts, not arbitrary choices of numerical zero, with change generators.

This is a strong completeness assumption: every nonconstant contrast gets a unique generator, and every admitted reversible generator arises this way. It is not just a correlation between some observed quantities and some motions.

We take the full connected Jordan automorphism group as the kinematically admitted reversible structure. It does **not** follow that all such transformations are experimentally controllable in every physical setting, or that all are actual time evolution.

---

# 2. Derive conservation from reciprocity rather than stipulating it separately

Differentiate the covariance condition along a transformation generated by D:

\[
\psi_{D(a)}=[D,\psi_a].
\]

Jordan automorphisms preserve the spectral trace, so D(a) stays in J₀ when a does. Taking D = ψₐ gives:

\[
\psi_{\psi_a(b)}=[\psi_a,\psi_b].
\]

Exchange a and b, add, and use injectivity:

\[
\boxed{\psi_a(b)=-\psi_b(a).}
\]

Consequently:

\[
\psi_a(a)=0.
\]

Each contrast is conserved by its own generated reversible flow. Also:

\[
\boxed{\psi_a(b)=0\quad\Longleftrightarrow\quad\psi_b(a)=0.}
\]

This is a reciprocal conservation statement: a generates transformations preserving b exactly when b generates transformations preserving a.

The induced bracket {a,b} = ψₐ(b) is a Lie bracket. Equivariance identifies it with the commutator bracket of derivations, so the Jacobi identity follows; each ψₐ also obeys the Jordan Leibniz rule by construction.

**What was earned:** conservation and reciprocal symmetry are consequences of the exact value–change connection, not separately assigned conservation laws for every quantity.

**Where the explanatory burden resides:** the existence of ψ. Once observables are identified with generators appropriately, parts of Noether-type reciprocity become algebraically straightforward. Baez explicitly stresses that the nontrivial issue is the observable–generator connection, not the antisymmetry of a Lie bracket alone. [3](https://arxiv.org/html/2006.14741)

---

# 3. Select the complex quantum family without assuming it at the outset

## 3.1 The alternatives are real alternatives within this model class

Finite-dimensional simple Euclidean Jordan algebras are classified: real, complex, and quaternionic Hermitian matrix families; spin factors; and the exceptional Albert algebra. Some low-dimensional cases coincide. This classification is an established theorem, not something the script discovers. [2](https://arxiv.org/pdf/1606.09331) [3](https://arxiv.org/html/2006.14741)

Reciprocity requires equal dimensions for nonconstant contrasts and connected reversible generators.

| Simple algebra | Nonconstant contrasts | Derivation dimension | Can dimensions match? |
|---|---:|---:|---|
| Real symmetric n × n, n ≥ 2 | n(n+1)/2 − 1 | n(n−1)/2 | No |
| Complex Hermitian n × n, n ≥ 2 | n² − 1 | n² − 1 | Yes |
| Quaternionic Hermitian n × n, n ≥ 2 | n(2n−1) − 1 | n(2n+1) | No |
| Spin factor with d-dimensional ball, d ≥ 2 | d | d(d−1)/2 | Only d = 3 |
| Exceptional Albert algebra | 26 | 52 | No |

For the real family the mismatch is n − 1. For the quaternionic family the generators exceed the nonconstant contrasts by 2n + 1. The spin-factor equality gives d = 3; that spin factor is precisely the complex two-level case.

The group dimensions are standard classification data. Selected small cases are also independently calculated from the derivation equations in the accompanying script.

## 3.2 Construct the correspondence in the surviving case

A dimension match by itself does not establish a physically meaningful correspondence. In the surviving complex case, however, an explicit one exists:

\[
J=\operatorname{Herm}_n(\mathbb C),
\qquad
\psi_a(b)=\frac i2[a,b].
\]

This sends Hermitian contrasts to Jordan derivations, vanishes exactly on constant matrices, and spans all connected derivations in finite dimensions. It is covariant under unitary conjugation.

Therefore:

> **Conditional selection theorem.** Among nontrivial finite-dimensional simple Euclidean Jordan algebras, the algebras admitting the specified contrast–generator reciprocity are exactly the complex Hermitian matrix algebras, including the spin-factor realization of the qubit.

The proof uses the classification, dimension exclusions, and explicit construction in the surviving family. It is not merely an extrapolation from numerical samples.

## 3.3 Is the particular correspondence independently adjustable for every contrast?

No, not if covariance is retained. In the complex case, J₀ and Der(J) carry the adjoint representation of the connected projective unitary group. An equivariant bijection differs from the canonical commutator correspondence only by a common nonzero real scale.

One way to see this is to compose it with the inverse canonical correspondence. The result commutes with the adjoint representation on traceless Hermitian matrices. Complexifying gives the irreducible adjoint representation of the simple complex Lie algebra; its commuting endomorphisms are scalar, and preservation of the real form makes the scalar real.

Thus the map does not require a separate arbitrary rule for each contrast. A common scale and an orientation remain; the scale is normalized in the displayed formula. Relating that scale to calibrated physical energy and duration remains an additional task.

**Crucial limitation:** the theorem does not show that CGR is metaphysically necessary, or that J describes phenomenal reality. Generalized probabilistic theories outside the Jordan class, and infinite-dimensional classical phase-space theories, have not been excluded by this finite theorem.

Nor does it forbid real or quaternionic representation structures inside complex quantum theory. The exclusion concerns the full simple observable algebra subjected to these exact postulates, not every use of real or quaternionic mathematics. The relation among these descriptions is richer than a blanket declaration that the others are incoherent. [8](https://math.ucr.edu/home/baez/rch.pdf)

---

# 4. Recover a probability-and-change structure, not just a matching dimension

## 4.1 Join the two products

Let Lₐ(b) = a ∘ b. For the displayed complex correspondence:

\[
[\psi_a,\psi_b]=-[L_a,L_b].
\]

The compatible associative product is:

\[
\boxed{ab=a\circ b-i\psi_a(b).}
\]

Indeed, the right side is the symmetric half of ab plus its antisymmetric half. The two roles together recover ordinary complex multiplication.

Alfsen and Shultz prove a more general theorem: a unital JB-algebra is the self-adjoint part of a complex C*-algebra exactly when it admits a dynamical correspondence satisfying self-conservation and the displayed commutator condition. That theorem is established mathematics, not a new theorem of this research notebook. Our finite selection argument instead imposes a bijective, covariant role requirement on a simple sector and then constructs the normalized correspondence explicitly. [12](https://www.pnas.org/doi/10.1073/pnas.95.12.6596) [3](https://arxiv.org/html/2006.14741)

Self-conservation alone would not suffice. The zero map is self-conserving and is a derivation-valued map on every Jordan algebra. It fails bijectivity and, in a nonassociative Jordan example, fails the commutator condition. The script supplies an exact Pauli-matrix witness.

## 4.2 Positive states give the Born trace form

Every real linear functional on complex Hermitian matrices has a unique representation:

\[
\omega(a)=\operatorname{Tr}(\rho a).
\]

Positivity implies ρ ≥ 0: apply ω to every rank-one positive projector. Normalization gives Trρ = 1. Conversely, each such density matrix defines a positive normalized functional.

Therefore, for a positive effect e:

\[
\boxed{p(e)=\operatorname{Tr}(\rho e).}
\]

For a sharp rank-one effect and pure state this becomes the usual squared-overlap expression.

This recovers the trace form **within the positive-linear probabilistic framework already assumed**. It is not a derivation of probability without probabilistic premises, a solution of the measurement problem, or an argument identifying a density matrix with a felt episode.

For the smallest nontrivial factor:

\[
\rho=\frac{I+\mathbf r\cdot\boldsymbol\sigma}{2},
\qquad
 e_{\mathbf n}=\frac{I+\mathbf n\cdot\boldsymbol\sigma}{2},
\]

with |r| ≤ 1 and |n| = 1. Then:

\[
p(+\mathbf n\mid\mathbf r)=\frac{1+\mathbf n\cdot\mathbf r}{2}.
\]

The complete family of sharp contrasts is now fixed by the algebra; it is not a separately chosen response channel for every comparison.

## 4.3 Closed continuous reversible evolution has commutator form

The connected reversible automorphisms of the complex matrix algebra are unitary conjugations. A time-homogeneous one-parameter group therefore has, in calibrated physical units:

\[
\dot\rho=-\frac i\hbar[H,\rho].
\]

Equivalently, its Heisenberg generator on observables is (2/ℏ)ψ_H. A constant multiple of I added to H does not change this fixed-algebra conjugation flow.

For H = (ℏ/2) Ω · σ, the Bloch vector obeys:

\[
\dot{\mathbf r}=\boldsymbol\Omega\times\mathbf r.
\]

The script checks the algebraic derivative and a finite rotation: with ℏ = 1, H = σ_z/2, and an initial x-directed pure state, time π/2 produces a y-directed pure state.

**Derived conditionally:** the form of the reversible law.

**Not derived:** the actual H, its coupling constants, a physically distinguished clock, the value of ℏ in fixed units, the arrow of time, or a spacetime interpretation. A one-parameter transformation family is not by itself an account of temporal becoming.

---

# 5. The smallest selected algebra supplies a Lorentz-cone template

There is a further connection worth deriving rather than merely announcing.

Write a general, unnormalized Hermitian two-by-two element as:

\[
X=sI+x\sigma_x+y\sigma_y+z\sigma_z.
\]

Its eigenvalues are s ± √(x²+y²+z²). Therefore positivity is:

\[
s\ge\sqrt{x^2+y^2+z^2}.
\]

Its determinant is:

\[
\boxed{\det X=s^2-x^2-y^2-z^2.}
\]

Thus the positive cone has the form of a four-dimensional future Lorentz cone. The normalized state space is a section of this cone. The relation between spin factors and Lorentz cones is standard mathematics. [8](https://math.ucr.edu/home/baez/rch.pdf)

For A with complex determinant 1:

\[
X\longmapsto AXA^\dagger
\]

preserves this quadratic form because det(AXA†) = |det A|² det X. For the specific positive matrix:

\[
A=\operatorname{diag}(e^{\zeta/2},e^{-\zeta/2}),
\]

the induced transformation is:

\[
s'=\cosh\zeta\,s+\sinh\zeta\,z,
\qquad
z'=\sinh\zeta\,s+\cosh\zeta\,z,
\]

with x and y unchanged. This is exactly a Lorentz-boost formula. The determinant and boost identities were checked symbolically.

The Jordan multipliers and reversible generators correspond here to different kinds of cone transformations: boost-like reshaping and rotation-like motion. Their commutator relation connects those roles. The general dynamical-correspondence literature also relates order-preserving filtering transformations to the reversible ones. [12](https://www.pnas.org/doi/10.1073/pnas.95.12.6596) [3](https://arxiv.org/html/2006.14741)

### Do not substitute an algebraic resemblance for spacetime

The coordinate s is an operator coordinate, **not a derived physical time**. Likewise, three Bloch coordinates are not automatically three spatial directions.

We have not supplied events, translations between events, a spacetime manifold, the identification of this cone with causal accessibility, or a law gluing local cones into a gravitational geometry.

Moreover, a boost-like cone map generally does not preserve trace. It is not automatically an allowed deterministic trace-preserving quantum channel; after appropriate scaling it can occur as a filtering branch with conditioning.

**Earned:** one algebra provides both a quantum two-level structure and a Lorentz-cone mathematical template.

**Not earned:** a derivation of physical spacetime or special/general relativity from experience. The missing identification must be justified, not hidden by renaming s “time.”

---

# 6. Improve round 3's qualitative-geometry proposal

Round 3 derived a Fisher metric from a specified response channel, leaving the constitutive channel unidentified. The selected qubit structure supplies a complete family of sharp contrasts. This allows a less channel-arbitrary construction.

It still does not prove that statistical differentiation is phenomenal difference.

## 6.1 Maximize over the algebra's sharp contrasts

For |r| < 1, take a local change v = dr. A sharp contrast along unit n has probability (1 + n · r)/2 and classical Fisher quadratic form:

\[
F_{\mathbf n}(\mathbf r;\mathbf v)
=\frac{(\mathbf n\cdot\mathbf v)^2}
{1-(\mathbf n\cdot\mathbf r)^2}.
\]

Let M = I − rrᵀ, positive definite in the interior. Maximization over n is a generalized Rayleigh-quotient problem:

\[
\sup_{|\mathbf n|=1}
\frac{(\mathbf n\cdot\mathbf v)^2}{\mathbf n^TM\mathbf n}
=\mathbf v^TM^{-1}\mathbf v.
\]

Equality is reached for n proportional to M⁻¹v. Using the rank-one inverse identity:

\[
\boxed{
 ds_Q^2=d\mathbf r\cdot d\mathbf r+
 \frac{(\mathbf r\cdot d\mathbf r)^2}{1-|\mathbf r|^2}.
}
\]

This is the standard qubit symmetric-logarithmic-derivative quantum Fisher metric; the corresponding Bures line element uses a factor of 1/4. Optimizing statistical distinguishability over quantum measurements is an established construction associated with Braunstein and Caves, not an original discovery here. [1](https://painterlab.caltech.edu/wp-content/uploads/2019/06/statistical_distance_geometry_quantum_states.pdf)

The displayed derivation is for the full-rank interior and direction-by-direction optimal contrasts. It is not a claim that one fixed measurement simultaneously attains all multiparameter optima, or that every contrast is actually performed or experienced.

## 6.2 Consequences without fitted distance parameters

- Proper rotations of r and dr preserve the metric. The reversible Bloch rotations derived above are isometries.
- Radial and tangential changes need not have the same local statistical size. At r = (0,0,0.6), a unit radial tangent has squared metric 1.5625, versus 1 for a perpendicular unit tangent.
- Depolarizing contraction r → λr, with 0 ≤ λ ≤ 1, contracts this metric when the tangent is also transformed.

For the last claim, put a = r · v and q = |r|². The difference is:

\[
(1-\lambda^2)|\mathbf v|^2+
\left(\frac1{1-q}-\frac{\lambda^4}{1-\lambda^2q}\right)a^2\ge0,
\]

because the bracket has numerator (1−λ²)(1+λ²−λ²q) over a positive denominator.

The code checks the optimum against its analytic expression for 128 interior states/directions and 2,048 additional axes. Maximum numerical discrepancies are below 5 × 10⁻¹⁴ for the optimum and rotation checks.

## 6.3 What this repairs—and what it does not

Given the constitutive algebra and the choice of maximal sharp-contrast discrimination, there is no extra arbitrary motor/report channel to select. The metric depends on the actual statistical state, not merely a state-independent integration capacity.

But the maximization is itself a specified criterion. Unitary invariance alone would not select this metric: ordinary Euclidean geometry is also rotationally invariant and differs from it. We have not proved that maximal statistical discrimination is the right phenomenal criterion.

The proposed bridge is now more precise:

> **DM-Q:** for an already unified episode constituted by such a contrast structure, some local qualitative relations match its intrinsic maximal-discrimination geometry.

DM-Q remains an added, potentially testable identity hypothesis. It does not identify the experiential algebra, explain why it is experienced, or determine raw qualitative character. It also concerns a discrimination capacity over possible comparisons; that capacity must not silently be equated with all actual experienced contents.

**Progress:** the statistical metric can now be derived from the full candidate algebra rather than chosen response by response.

**Remaining bridge:** why that full algebra and this discrimination criterion constitute the relevant phenomenal relations.

---

# 7. Impose composition consistency: recover a public-process constraint

Complex single-system structure is not a complete physical theory. We must say how systems coexist and interact. Jordan theories admit nonstandard composites, so composition cannot be read off from a list of single-system algebras. [2](https://arxiv.org/pdf/1606.09331)

## 7.1 The additional composite assumption

Use the standard finite complex tensor product, with commuting local matrix factors and the usual positive global states. This is an additional composition commitment. Round 2 gave conditions under which commuting complete observable factors support such a product; those conditions are not derived from phenomenal unity here.

Now consider a proposed local process E. Positivity on isolated states is necessary but not enough. It must remain positive when extended by the identity on an arbitrary companion system:

\[
\operatorname{id}_k\otimes E\text{ is positive for every }k.
\]

This is **complete positivity**. Trace preservation adds normalization for an unconditioned deterministic process.

Thus the ancilla-consistency requirement supplies a nontrivial constraint on public processes once the composite structure is fixed.

## 7.2 An exact obstruction

Matrix transposition is positive on a single system, but not completely positive. Apply it to one half of a Bell state. The global output has eigenvalues:

\[
\{-\tfrac12,\tfrac12,\tfrac12,\tfrac12\}.
\]

The negative eigenvalue disqualifies it as a universally admissible unconditioned local operation under the assumed composition rule. The script calculates this spectrum.

This is not a proof that every completely positive trace-preserving map is physically available in every world. Actual interactions can impose additional restrictions.

## 7.3 Unconditioned local maps cannot alter the other marginal

For trace-preserving E acting on B:

\[
\operatorname{Tr}_B[(\operatorname{id}\otimes E)(\rho_{AB})]
=\operatorname{Tr}_B\rho_{AB}.
\]

In the dual picture, E†(I) = I, giving the result for every A-side expectation. A local amplitude-damping example was checked numerically with exactly zero reported marginal error at the chosen parameters.

Conditioned branches can have different correlations and conditional marginals. The claim concerns the unconditioned local operation.

This is no-signalling across the stipulated tensor factors. It does **not** derive physical spatial locality, a light cone, or the absence of nonlocal Hamiltonian interactions; those need their own constitutive account.

---

# 8. Stress tests: distinguish an explanatory core from a complete world

## 8.1 The actual Hamiltonian is still not selected

Even with the same complex algebra, reciprocity, states, and process constraints, actual histories differ.

On two qubits, begin with |00⟩. Compare:

\[
H_0=0,
\qquad H_1=\sigma_x\otimes\sigma_x
\]

in units with ℏ = 1. At time π/4:

- H₀ leaves a product state and one-qubit reduced purity 1;
- H₁ produces an entangled pure state and one-qubit reduced purity 1/2.

Both obey the reconstructed framework. The script checks both outcomes.

Therefore, selecting the complex family does not select the actual interactions, history, or laws of our world. Rank n, field content, locality, coupling strengths, initial/boundary conditions, and gravitational structure are not fixed.

This is underdetermination inside the candidate framework, not a proof that those remaining facts are forever inexplicable.

## 8.2 Static differentiation does not fix dynamical orientation

The products ab and ba have the same Jordan part, squares, positivity cone, state space, and same-time probabilities. Their commutators have opposite signs.

Both ψ and −ψ satisfy the normalized dynamical-correspondence commutator condition. The script verifies the two orientations. For Pauli matrices, XY = iZ while the opposite product gives −iZ, although X ∘ Y = 0 in both.

Alfsen and Shultz explicitly identify orientation as the additional ingredient needed to pass from Jordan structure to associative structure. [12](https://www.pnas.org/doi/10.1073/pnas.95.12.6596)

So even supplying a complete static state/effect geometry is not the same as specifying the full value–change constitution.

It would also be wrong automatically to count the two sign descriptions as metaphysically different worlds. If temporal/complex orientation and all operations are transported together, the difference may be representational. The calculation does not settle that interpretation or derive a physical arrow of time.

## 8.3 Algebraic simplicity does not select subjects

The whole algebra M₄(C) is simple. Its two commuting local M₂(C) factors are also simple. All fit the relevant complex structure.

Thus algebraic simplicity alone does not say whether there is one subject, two subjects, overlapping subjects, or no experience. The subject-boundary problem from round 3 has not been solved by substituting the word “simple” for the word “unified.”

Nor is CGR inherited by every restricted subalgebra: a diagonal classical record algebra need not itself satisfy full role reciprocity, even when embedded in a complex system that does. The postulate must have a principled domain of application.

## 8.4 A positive functional is not yet a presented episode

The same formal apparatus can describe potential statistics without asserting that anything is felt. It does not determine:

- which systems are presented to themselves;
- which contents are co-conscious;
- what a particular quality is like;
- how definite experienced outcomes relate to a quantum state;
- why this particular realization is actual.

This is formal incompleteness about phenomenality, not a metaphysical zombie proof. We have not established that complete physical reality could remain fixed while experience varies.

The value–change proposal becomes an actual constitutive explanation only if its full concrete nature and organization account for these facts. Renaming an algebra “a field of awareness” would not do so.

## 8.5 Universalizing the candidate requires another argument

Actual experience motivates an experience-inclusive account. It does not establish that every physical sector has the same intrinsic presentational nature, or that every quantum degree of freedom is a microsubject.

The current conditional construction could guide a universal constitution, but its extension beyond the experiential starting point remains a hypothesis. Neither a cosmic subject nor a population of conscious microatoms is being inferred.

---

# 9. Integrate the result and keep the ultimate obligation intact

## 9.1 An improved lead constitution

The proposal can now be sharpened:

> Investigate a concrete qualitative-relational nature in which intrinsic distinctions and reversible change roles are covariantly paired. Its public probability-and-change structure is not an independently imposed programme: under explicit finite Jordan assumptions, the paired roles have complex quantum form. Experiential subjecthood, where it occurs, is the unity of a concrete presentation, not an extra witness. But the constitution must still explain which organizations actually present, what their qualities are, and why they exist.

This supplies an actual structural candidate for part of Π, rather than leaving every public law behind an undefined extraction arrow. It also refines a possible relational component of Q through DM-Q.

It does **not** complete Σ, determine full Q, or justify actuality. Those interfaces remain genuine obligations, not hidden in the symbols.

## 9.2 Organizing principle versus necessity

The finite conditional theorem can be mathematically necessary without its premises being metaphysically necessary.

Similarly, even if a particular kind of concrete occurrence necessarily had this structure:

\[
\Box\forall x\,[C(x)\to K(x)],
\]

that would not alone establish:

\[
\Box\exists x\,C(x).
\]

Adding actual experience establishes an actual occurrence, not the missing modal step. Round 3's neutral-extension guardrail remains applicable wherever the theory is neutral about concrete instantiation.

We must still justify why J and CGR belong to the intrinsic nature of actual reality, why that nature admits or requires concrete occurrence, and why its remaining possibilities are realized as they are. Calling CGR an “essential law” without justification would relocate the explanatory residue rather than remove it.

## 9.3 The current explanatory budget

| Item | Status after this round |
|---|---|
| Some experience is actual | Starting datum |
| Episode identity removes an additional inner viewer | Conditional constitutive proposal; unity not derived |
| Intrinsic differences and change roles belong to one concrete occurrence | Lead ontological hypothesis |
| Finite Jordan spectral structure | Explicit model postulate; not derived from phenomenology |
| Positive linear probabilistic states | Explicit state framework; probability itself not derived |
| Bijective, covariant contrast–generator reciprocity | Specific constitutive hypothesis; not proved necessary |
| Reciprocal conservation follows from CGR | Derived |
| Complex Hermitian family is selected within the finite simple class | Derived using classification and explicit existence |
| Born trace form | Derived within the assumed positive-linear probability framework |
| Closed reversible commutator dynamics | Derived in form; actual Hamiltonian and physical scale remain open |
| Minimal-factor Lorentz cone | Derived algebraically; spacetime interpretation remains open |
| Full sharp-contrast Fisher metric | Derived for the selected qubit model and optimization criterion |
| That metric is phenomenal geometry | DM-Q hypothesis, not established |
| Complete positivity from ancilla consistency | Derived once standard complex composition is assumed |
| Subject boundaries and phenomenal character | Not derived |
| Definite experienced outcomes | Not derived |
| Necessary concrete existence and unique world constitution | Not derived |

## 9.4 What the next successful step must accomplish

The highest-leverage target is now narrower than “find an intrinsic nature”:

**Justify or replace the spectral Jordan structure and contrast–generator reciprocity without using the desired quantum result as their sole reason.**

There are two honest possibilities:

1. Derive them from independently defensible features of concrete presentation and change, obtaining genuine additional explanatory closure.
2. Find that they remain optional organizing laws, and then explain their selection through a deeper constitution rather than declaring them necessities.

In parallel, any proposed complete nature must pass the subject/outcome tests in §8. Recovering quantum mathematics does not by itself solve consciousness; recovering a Lorentz cone does not by itself solve spacetime.

### Research verdict

This round goes beyond giving consciousness a new name: it formulates a constrained value–change hypothesis and derives a public structural family with consequences for probabilities, reversible dynamics, statistical geometry, and allowable local processes. It also exhibits exactly where that family leaves the world undetermined.

The result is **conditional explanatory compression**, not zero residue. Its value is that there is now a small, explicit organizing principle to justify or defeat, rather than an unrestricted lookup table linking intrinsic nature to public physics.

---

# Reproducibility, proof scope, and sources

## Files

- **Script:** `zero_residue_research/round4_checks.py`
- **Results:** `zero_residue_research/round4_results.json`
- **Run:** `python zero_residue_research/round4_checks.py`
- **Dependencies:** Python 3, NumPy, SymPy, SciPy.

The script actually ran successfully. All implemented assertions passed.

## What was computed independently

The script solves the exact Jordan Leibniz equations for an unknown linear derivation and obtains:

| Algebra | Computed derivation dimension |
|---|---:|
| Real symmetric 2 × 2 | 1 |
| Complex Hermitian 2 × 2 | 3 |
| Real symmetric 3 × 3 | 3 |
| Complex Hermitian 3 × 3 | 8 |
| Spin factor d = 2 | 1 |
| Spin factor d = 3 | 3 |
| Spin factor d = 4 | 6 |
| Spin factor d = 5 | 10 |
| Three-outcome classical algebra | 0 |

The classification theorem and general family dimensions are mathematical inputs, not discoveries inferred from these examples.

For the complex 2 × 2 and 3 × 3 cases it checks the product and antisymmetry on **97 basis pairs**, and the derivation, covariance, and dynamical-correspondence identities on **793 basis triples**. Because those particular identities are bilinear/trilinear over the real Hermitian spaces, exact checks on complete bases extend to all arguments in those spaces. This is stronger than random sampling; it is still not a proof of phenomenal interpretation.

It also checks 256 Born-probability cases; finite unitary evolution; the zero-correspondence obstruction; opposite orientations; the sharp-contrast metric optimum and rotations; a depolarizing example; symbolic determinant/boost identities; the Bell partial-transpose obstruction; a local-channel marginal; two different Hamiltonians; and commuting complex factors.

The general claims have the arguments or cited theorems in the text. No conscious device, empirical brain model, or new experimental evidence is claimed.

## Primary sources and consultation boundaries

- **Alfsen and Shultz, “Orientation in operator algebras” (1998).** Primary statement of the dynamical-correspondence conditions and characterization; also explains why Jordan structure alone does not determine the associative product. Opening and dynamical-correspondence/theorem sections directly consulted, not the entire paper. [12](https://www.pnas.org/doi/10.1073/pnas.95.12.6596)
- **Baez, “Getting to the Bottom of Noether's Theorem,” arXiv:2006.14741.** The observables/generators distinction; Jordan classification and states; dynamical correspondence and Theorem 12. Introduction and relevant Jordan/theorem sections directly consulted. Its discussion explicitly leaves a physical justification of the stronger correspondence condition open. [3](https://arxiv.org/html/2006.14741)
- **Barnum, Graydon, and Wilce, “Composites and Categories of Euclidean Jordan Algebras,” arXiv:1606.09331.** Classification context and the warning that composition requires additional structure; alternative composites include nonstandard features. Opening section directly consulted; full composition proofs not reviewed here. [2](https://arxiv.org/pdf/1606.09331)
- **Braunstein and Caves, “Statistical Distance and the Geometry of Quantum States” (1994).** Standard optimization of statistical distinguishability over quantum measurements. Opening derivation directly consulted; the qubit Rayleigh-quotient derivation above is supplied explicitly. [1](https://painterlab.caltech.edu/wp-content/uploads/2019/06/statistical_distance_geometry_quantum_states.pdf)
- **Baez, “Division Algebras and Quantum Theory” (2011).** Context for real/complex/quaternionic structures and the spin-factor/Lorentz relation. Opening discussion directly consulted; Lorentz relation also checked against the indexed passage and independently derived above. [8](https://math.ucr.edu/home/baez/rch.pdf)

These mathematical structures and reconstruction ideas are established. The work here is their explicit use in the proposed constitution, the finite conditional selection argument, reproducible checks, and the resulting revision of the whole-reality programme—not a claim of priority or completion.
