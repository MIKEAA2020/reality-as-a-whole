"""Zero-residue research, round 2: finite logic and exact model calculations.

These checks do not verify metaphysical premises or phenomenal identities.
Dependencies: Python 3, sympy, numpy. Run from any working directory.
"""
from pathlib import Path
from itertools import product, permutations
import json
import math
import numpy as np
import sympy as sp


def is_acyclic(parents):
    n = len(parents)
    remaining = (1 << n) - 1
    while remaining:
        roots = sum(1 << j for j in range(n)
                    if remaining & (1 << j) and not (parents[j] & remaining))
        if not roots:
            return False
        remaining &= ~roots
    return True


def graph_parents(n, edge_mask):
    parents = [0] * n
    for i in range(n):
        for j in range(n):
            if edge_mask & (1 << (i*n+j)):
                parents[j] |= 1 << i
    return parents


# A finite shadow of the existential-support argument.
# Every node is an actually true existence-entailing fact.
# Its truth at world 1 determines whether it is necessary on this two-world
# universal frame (all nodes are true at actual world 0).
# ENB says every contingent node has some incoming existential support.
# ROOT says there is some node with no incoming existential support.
foundation_rows = []
for n in range(1, 5):
    graphs = 1 << (n*n)
    assignments = 0
    rooted_enb_assignments = 0
    wf_enb_assignments = 0
    wf_enb_necessitating_assignments = 0
    counterexamples = 0
    acyclic_graphs = 0
    for edge_mask in range(graphs):
        parents = graph_parents(n, edge_mask)
        root_mask = sum(1 << j for j in range(n) if not parents[j])
        rooted = bool(root_mask)
        wf = is_acyclic(parents)
        acyclic_graphs += wf
        for necessary_mask in range(1 << n):
            assignments += 1
            enb = (root_mask & ~necessary_mask) == 0
            conclusion = bool(necessary_mask)
            if rooted and enb:
                rooted_enb_assignments += 1
                if not conclusion:
                    counterexamples += 1
            if wf and enb:
                wf_enb_assignments += 1
                assert conclusion
                # Extra premise: each edge is a full-ground arrow with
                # necessary implication. A necessary parent then cannot
                # point to a contingent child. Complete conjunctive grounds
                # are represented as their own nodes, not separate edges
                # from individually insufficient conjuncts.
                necessitating = all(not (parents[j] & necessary_mask)
                                    or bool(necessary_mask & (1 << j))
                                    for j in range(n))
                if necessitating:
                    wf_enb_necessitating_assignments += 1
                    assert necessary_mask == (1 << n)-1
    assert counterexamples == 0
    foundation_rows.append({
        'nodes': n, 'graphs_including_loops': graphs,
        'acyclic_graphs': acyclic_graphs,
        'graph_modal_assignments': assignments,
        'rooted_ENB_assignments': rooted_enb_assignments,
        'well_founded_finite_ENB_assignments': wf_enb_assignments,
        'well_founded_ENB_necessitating_assignments': wf_enb_necessitating_assignments,
        'counterexamples_to_all_nodes_necessary_with_extra_premise': 0,
        'counterexamples_to_conditional': counterexamples,
    })
# Dropping ENB: one contingent unsupported node.
assert is_acyclic([0])
# Dropping ROOT: two contingent mutually supported nodes.
assert not is_acyclic([2, 1])
assert all([2, 1])
# ROOT is weaker than well-foundedness: a root feeding a cycle.
parents = [0, (1 << 0) | (1 << 2), 1 << 1]
assert not is_acyclic(parents)
assert any(x == 0 for x in parents)

# Self-consistency has variable solution counts.
copy_loop = [[x, y] for x, y in product([0, 1], repeat=2) if x == y and y == x]
inconsistent_loop = [[x, y] for x, y in product([0, 1], repeat=2)
                     if x == 1-y and y == x]
assert copy_loop == [[0, 0], [1, 1]]
assert inconsistent_loop == []
x, y = sp.symbols('x y')
unique_loop = sp.solve([x-(1+y)/2, y-(1+x)/2], [x, y])
assert unique_loop == {x: 1, y: 1}

# Fixed-grain four-component diffusion model.
e = sp.symbols('epsilon', positive=True)
L = sp.Matrix([[1+2*e, -1, -e, -e],
               [-1, 1+2*e, -e, -e],
               [-e, -e, 1+2*e, -1],
               [-e, -e, -1, 1+2*e]])
vectors = [(sp.Matrix([1, 1, 1, 1]), 0),
           (sp.Matrix([1, 1, -1, -1]), 4*e),
           (sp.Matrix([1, -1, 0, 0]), 2+2*e),
           (sp.Matrix([0, 0, 1, -1]), 2+2*e)]
for v, lam in vectors:
    assert sp.simplify(L*v-lam*v) == sp.zeros(4, 1)
P = sp.Matrix([[1, 1, 0, 0], [0, 0, 1, 1]])
LM = sp.Matrix([[2*e, -2*e], [-2*e, 2*e]])
assert sp.simplify(P*L-LM*P) == sp.zeros(2, 4)
assert L.subs(e, 1).eigenvals() == {0: 1, 4: 3}

# Exact perturbation residual: increase edge 0--2 by delta.
delta = sp.symbols('delta', positive=True)
v = sp.Matrix([1, 0, -1, 0])
Lpert = L + delta*v*v.T
D = sp.simplify(P*Lpert-LM*P)
assert D == delta*sp.Matrix([[1, 0, -1, 0], [-1, 0, 1, 0]])
assert (D*D.T).eigenvals() == {0: 1, 4*delta**2: 1}


def exp_negative_symmetric(matrix, t):
    eig, vec = np.linalg.eigh(matrix)
    return (vec * np.exp(-t*eig)) @ vec.T


e0 = 0.01
d0 = 0.001
t0 = 2.0
L0 = np.array(L.subs(e, sp.Rational(1, 100)), dtype=float)
LM0 = np.array(LM.subs(e, sp.Rational(1, 100)), dtype=float)
P0 = np.array(P, dtype=float)
x0 = np.array([1.0, 0, 0, 0])
xt = exp_negative_symmetric(L0, t0) @ x0
assert np.all(xt >= 0) and abs(float(sum(xt))-1) < 1e-12
fast_decay = math.exp(-(2+2*e0)*t0)
slow_decay = math.exp(-4*e0*t0)
assert np.allclose(xt, [0.25+0.25*slow_decay+0.5*fast_decay,
                        0.25+0.25*slow_decay-0.5*fast_decay,
                        0.25-0.25*slow_decay,
                        0.25-0.25*slow_decay])
Lpert0 = np.array(Lpert.subs({e: sp.Rational(1, 100),
                             delta: sp.Rational(1, 1000)}), dtype=float)
operator_error = np.linalg.norm(P0 @ exp_negative_symmetric(Lpert0, t0)
                               - exp_negative_symmetric(LM0, t0) @ P0, 2)
error_bound = 2*d0*t0
assert operator_error <= error_bound+1e-12

# Boundary extraction covaries under all 24 relabellings of the given parts.
for perm in permutations(range(4)):
    R = np.eye(4)[list(perm)]
    lp = R @ L0 @ R.T
    eig, vec = np.linalg.eigh(lp)
    fiedler = vec[:, 1]
    recovered = {frozenset(np.where(fiedler > 0)[0]),
                 frozenset(np.where(fiedler < 0)[0])}
    expected = {frozenset(i for i, old in enumerate(perm) if old in {0, 1}),
                frozenset(i for i, old in enumerate(perm) if old in {2, 3})}
    assert recovered == expected

# Exact two-qubit factorization example.
I = sp.eye(2)
X = sp.Matrix([[0, 1], [1, 0]])
Z = sp.diag(1, -1)
H = sp.Matrix([[1, 1], [1, -1]])/sp.sqrt(2)
CNOT = sp.Matrix([[1, 0, 0, 0], [0, 1, 0, 0],
                  [0, 0, 0, 1], [0, 0, 1, 0]])
kron = sp.kronecker_product
U = CNOT*kron(H, I)
assert U.T*U == sp.eye(4)
ket00 = sp.Matrix([1, 0, 0, 0])
bell = U*ket00
rho = bell*bell.T
rho_new_coordinates = sp.simplify(U.T*rho*U)
assert rho_new_coordinates == sp.diag(1, 0, 0, 0)


def ptrace_b(r):
    return sp.Matrix(2, 2, lambda a, ap: sum(r[2*a+b, 2*ap+b] for b in range(2)))


def ptrace_a(r):
    return sp.Matrix(2, 2, lambda b, bp: sum(r[2*a+b, 2*a+bp] for a in range(2)))


assert ptrace_a(rho) == I/2 and ptrace_b(rho) == I/2
assert ptrace_a(rho_new_coordinates) == sp.diag(1, 0)
assert ptrace_b(rho_new_coordinates) == sp.diag(1, 0)
XA, ZA, XB, ZB = kron(X, I), kron(Z, I), kron(I, X), kron(I, Z)
assert sp.simplify(U*XA*U.T) == ZA
assert sp.simplify(U*ZA*U.T) == kron(X, X)
assert sp.simplify(U*XB*U.T) == XB
assert sp.simplify(U*ZB*U.T) == kron(Z, Z)
Abasis = [sp.simplify(U*a*U.T) for a in [sp.eye(4), XA, ZA, XA*ZA]]
Bbasis = [sp.simplify(U*b*U.T) for b in [sp.eye(4), XB, ZB, XB*ZB]]
for a in Abasis:
    for b in Bbasis:
        assert sp.simplify(a*b-b*a) == sp.zeros(4)
products_matrix = sp.Matrix.hstack(*[(a*b).reshape(16, 1) for a in Abasis for b in Bbasis])
assert products_matrix.rank() == 16

results = {
    'scope': 'Conditional mathematical checks, not proof of ultimate actuality or consciousness.',
    'existential_support_theorem': {
        'finite_enumerations': foundation_rows,
        'total_graph_modal_assignments': sum(r['graph_modal_assignments'] for r in foundation_rows),
        'scope_note': 'Graphs are abstract support structures; a graph edge alone does not establish genuine metaphysical grounding.',
        'drop_ENB_countermodel': 'One contingent existential fact, no support edge.',
        'drop_ROOT_countermodel': 'Two contingent existential facts, mutually supporting.',
        'ROOT_is_weaker_than_well_foundedness': True,
        'strong_closure_result': 'Actual contingency, full necessitating ground closure, and strict well-foundedness cannot all hold.',
    },
    'self_consistency': {
        'binary_copy_loop_solutions': copy_loop,
        'binary_inconsistent_loop_solutions': inconsistent_loop,
        'continuous_contractive_loop_solution': {str(k): str(v) for k, v in unique_loop.items()},
        'actuality_follows_from_fixed_point_uniqueness': False,
    },
    'dynamical_individuation': {
        'spectrum_symbolic': ['0', '4*epsilon', '2+2*epsilon', '2+2*epsilon'],
        'exact_macro_identity': 'P L = L_M P',
        'epsilon': e0, 'time': t0,
        'fast_relaxation_time': 1/(2+2*e0),
        'slow_relaxation_time': 1/(4*e0),
        'timescale_ratio': (2+2*e0)/(4*e0),
        'within_pair_contrast_remaining': fast_decay,
        'between_pair_contrast_remaining': slow_decay,
        'state_at_time_from_first_node': xt.tolist(),
        'mass_in_initial_module': float(xt[0]+xt[1]),
        'label_permutations_checked': 24,
        'epsilon_one_nonzero_eigenvalue_multiplicity': 3,
    },
    'macro_robustness': {
        'perturbed_cross_edge_delta': d0,
        'exact_residual_norm': '2*delta',
        'operator_error_at_time': float(operator_error),
        'rigorous_operator_error_bound': error_bound,
    },
    'quantum_subsystem_structure': {
        'U': 'CNOT (Hadamard tensor I)',
        'original_individual_marginal_purities': ['1/2', '1/2'],
        'new_factor_individual_marginal_purities': ['1', '1'],
        'new_A_generators_in_old_coordinates': ['Z tensor I', 'X tensor X'],
        'new_B_generators_in_old_coordinates': ['I tensor X', 'Z tensor Z'],
        'cross_commutation_verified': True,
        'generated_full_operator_algebra_dimension': 16,
        'scope_note': 'The comparison changes the subsystem algebras while holding the abstract state fixed, not just coordinates of the same physical bipartition.',
    },
}
output = Path(__file__).with_name('round2_results.json')
output.write_text(json.dumps(results, indent=2)+'\n')
print(json.dumps(results, indent=2))
