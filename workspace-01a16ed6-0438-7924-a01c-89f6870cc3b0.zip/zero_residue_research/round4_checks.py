"""Round 4: conditional contrast--generator constitution.

Reproducible mathematical checks, not consciousness experiments.
Finite simple Euclidean Jordan algebra (EJA) + equivariant linear
bijection J/R1 -> Der(J) is a substantive candidate postulate, not a
consequence of phenomenology. Classification and Lie-group dimensions
are mathematical inputs; selected small derivation spaces are also
computed independently from the Leibniz equations.

Run: python zero_residue_research/round4_checks.py
Dependencies: numpy, scipy, sympy.
"""
from pathlib import Path
import json
import math
import numpy as np
import sympy as sp
from scipy.linalg import expm
from sympy.polys.matrices import DomainMatrix

OUT = Path(__file__).with_name('round4_results.json')


def jordan(a, b):
    return (a*b+b*a)/2


def psi(a, b):
    # Convention: ab = a o b - i psi_a(b).
    return sp.I*(a*b-b*a)/2


def zero(a):
    return all(sp.expand(x) == 0 for x in a)


def hermitian_basis(n, real=False):
    result = []
    for i in range(n):
        a = sp.zeros(n)
        a[i, i] = 1
        result.append(a)
    for i in range(n):
        for j in range(i+1, n):
            a = sp.zeros(n)
            a[i, j] = a[j, i] = 1
            result.append(a)
            if not real:
                b = sp.zeros(n)
                b[i, j], b[j, i] = -sp.I, sp.I
                result.append(b)
    return result


def matrix_structure_constants(basis):
    norms = [sp.trace(b*b) for b in basis]
    return [[[sp.simplify(sp.trace(bk*jordan(bi, bj))/norms[k])
              for k, bk in enumerate(basis)]
             for bj in basis] for bi in basis]


def spin_structure_constants(d):
    m = d+1
    c = [[[sp.S.Zero for _ in range(m)] for _ in range(m)] for _ in range(m)]
    for i in range(m):
        c[0][i][i] = c[i][0][i] = sp.S.One
    for i in range(1, m):
        c[i][i][0] = sp.S.One
    return c


def classical_structure_constants(m):
    c = [[[sp.S.Zero for _ in range(m)] for _ in range(m)] for _ in range(m)]
    for i in range(m):
        c[i][i][i] = sp.S.One
    return c


def derivation_dimension(c):
    """Exact nullity of D(a o b)=D(a)o b+a o D(b), with D unknown."""
    m = len(c)
    entries = {}
    row = 0
    for i in range(m):
        for j in range(i, m):
            for k in range(m):
                coeff = {}
                def add(index, value):
                    coeff[index] = coeff.get(index, sp.S.Zero)+value
                for ell in range(m):
                    add(k*m+ell, c[i][j][ell])
                    add(ell*m+i, -c[ell][j][k])
                    add(ell*m+j, -c[i][ell][k])
                for col, value in coeff.items():
                    if value:
                        entries[(row, col)] = value
                row += 1
    equations = sp.SparseMatrix(row, m*m, entries)
    rank = DomainMatrix.from_Matrix(equations).rank()
    return {'algebra_dimension': m, 'unknown_coefficients': m*m,
            'equations': row, 'rank': rank, 'derivation_dimension': m*m-rank}


# 1. Classification-data screen, not a derivation of the classification theorem.
dimension_screen = []
for n in range(2, 9):
    for family, obs, gen in [
        ('real_symmetric', n*(n+1)//2-1, n*(n-1)//2),
        ('complex_hermitian', n*n-1, n*n-1),
        ('quaternionic_hermitian', n*(2*n-1)-1, n*(2*n+1)),
    ]:
        dimension_screen.append({'family': family, 'n': n,
                                 'nonconstant_observables': obs,
                                 'connected_generators': gen,
                                 'dimension_match': obs == gen})
for d in range(2, 11):
    dimension_screen.append({'family': 'spin_factor', 'contrast_dimension': d,
                             'nonconstant_observables': d,
                             'connected_generators': d*(d-1)//2,
                             'dimension_match': d == d*(d-1)//2})
dimension_screen.append({'family': 'exceptional_Albert',
                         'nonconstant_observables': 26,
                         'connected_generators': 52,
                         'dimension_match': False})
assert all(r['family'] == 'complex_hermitian' or
           (r['family'] == 'spin_factor' and r['contrast_dimension'] == 3)
           for r in dimension_screen if r['dimension_match'])

# 2. Independent exact computations of small derivation spaces.
computed_derivations = {}
for n in (2, 3):
    for real in (True, False):
        name = f"{'real' if real else 'complex'}_{n}"
        computed_derivations[name] = derivation_dimension(
            matrix_structure_constants(hermitian_basis(n, real)))
        expected = n*(n-1)//2 if real else n*n-1
        assert computed_derivations[name]['derivation_dimension'] == expected
for d in (2, 3, 4, 5):
    name = f'spin_{d}'
    computed_derivations[name] = derivation_dimension(spin_structure_constants(d))
    assert computed_derivations[name]['derivation_dimension'] == d*(d-1)//2
computed_derivations['classical_3'] = derivation_dimension(classical_structure_constants(3))
assert computed_derivations['classical_3']['derivation_dimension'] == 0

# 3. Exact basis identities. Bilinear/trilinear identities extend to all
# Hermitian matrices by real multilinearity; this is not random sampling.
exact_identity_checks = {}
for n in (2, 3):
    basis = hermitian_basis(n)
    pairs = triples = 0
    for a in basis:
        for b in basis:
            assert zero(psi(a, b)+psi(b, a))
            assert zero(jordan(a, b)-sp.I*psi(a, b)-a*b)
            pairs += 1
            for c in basis:
                # psi_a is a derivation of the Jordan product.
                assert zero(psi(a, jordan(b, c))
                            -jordan(psi(a, b), c)-jordan(b, psi(a, c)))
                comm_psi = psi(a, psi(b, c))-psi(b, psi(a, c))
                comm_L = jordan(a, jordan(b, c))-jordan(b, jordan(a, c))
                # Dynamical correspondence and infinitesimal equivariance.
                assert zero(comm_psi+comm_L)
                assert zero(psi(psi(a, b), c)-comm_psi)
                # Opposite orientation also satisfies the correspondence.
                assert zero((-psi(a, -psi(b, c))+psi(b, -psi(a, c)))+comm_L)
                triples += 1
    exact_identity_checks[f'complex_{n}'] = {
        'basis_dimension': len(basis), 'basis_pairs': pairs,
        'basis_triples': triples, 'all_identities_zero': True}

# 4. Self-conservation alone does not impose the commutator condition.
X = sp.Matrix([[0, 1], [1, 0]])
Y = sp.Matrix([[0, -sp.I], [sp.I, 0]])
Z = sp.diag(1, -1)
I2 = sp.eye(2)
comm_L_witness = jordan(X, jordan(Z, X))-jordan(Z, jordan(X, X))
assert zero(comm_L_witness+Z)
weak_correspondence = {
    'zero_map_is_a_derivation_and_self_conserving': True,
    'commutator_condition_fails_for_zero_map': not zero(comm_L_witness),
    'witness_comm_L': str(comm_L_witness),
    'zero_map_is_not_bijective': True}

# The two opposite associative products share the same Jordan part,
# positivity cone and state space; their commutators have opposite signs.
assert zero(jordan(X, Y))
assert zero(X*Y-sp.I*Z)
assert zero(Y*X+sp.I*Z)
orientation_check = {
    'XY': str(X*Y), 'opposite_product_XY': str(Y*X),
    'same_Jordan_product': zero(jordan(X, Y)),
    'opposite_correspondences_both_pass': True,
    'inequivalent_metaphysical_worlds_proven': False}

# 5. Born probabilities and unitary dynamics in the selected complex case.
rng = np.random.default_rng(20261024)
sigma = [np.array(m).astype(complex) for m in (X, Y, Z)]
id2 = np.eye(2, dtype=complex)
max_prob_error = 0.0
for _ in range(256):
    r = rng.normal(size=3)
    r *= rng.uniform(0, 1)/np.linalg.norm(r)
    n = rng.normal(size=3)
    n /= np.linalg.norm(n)
    rho = (id2+sum(r[k]*sigma[k] for k in range(3)))/2
    effect = (id2+sum(n[k]*sigma[k] for k in range(3)))/2
    actual = float(np.trace(rho@effect).real)
    expected = float((1+n@r)/2)
    max_prob_error = max(max_prob_error, abs(actual-expected))
    assert np.linalg.eigvalsh(rho).min() >= -1e-12
    assert -1e-12 <= actual <= 1+1e-12
    assert np.linalg.norm(effect@effect-effect) < 1e-12
assert max_prob_error < 1e-12
rho0 = (id2+sigma[0])/2
H = sigma[2]/2  # hbar = 1; this H and time scale are choices, not derived.
t = math.pi/2
U = expm(-1j*H*t)
rhot = U@rho0@U.conj().T
bloch = [float(np.trace(rhot@s).real) for s in sigma]
assert np.allclose(bloch, [0, 1, 0], atol=1e-12)
assert zero((-sp.I*(Z*X-X*Z)/4)-Y/2)
born_and_dynamics = {
    'random_probability_cases': 256, 'max_probability_error': max_prob_error,
    'chosen_H': 'sigma_z/2; hbar=1', 'chosen_t': t,
    'initial_Bloch_vector': [1, 0, 0], 'final_Bloch_vector': bloch,
    'Schrodinger_vs_Bloch_derivative_exact_check': True}

# 6. From all sharp contrast axes to a state-dependent discrimination metric.
def qmetric(r, v):
    return float(v@v+(r@v)**2/(1-r@r))

metric_error = rotation_error = 0.0
sampled_axes = 0
for _ in range(128):
    r = rng.normal(size=3)
    r *= rng.uniform(0, .95)/np.linalg.norm(r)
    v = rng.normal(size=3)
    M = np.eye(3)-np.outer(r, r)
    nopt = np.linalg.solve(M, v)
    nopt /= np.linalg.norm(nopt)
    optimum = (nopt@v)**2/(1-(nopt@r)**2)
    analytic = qmetric(r, v)
    metric_error = max(metric_error, abs(optimum-analytic))
    assert abs(optimum-analytic) < 1e-11
    for _ in range(16):
        n = rng.normal(size=3)
        n /= np.linalg.norm(n)
        value = (n@v)**2/(1-(n@r)**2)
        assert value <= analytic+1e-11
        sampled_axes += 1
    K = rng.normal(size=(3, 3))
    R = expm((K-K.T)/2)
    rotation_error = max(rotation_error, abs(qmetric(R@r, R@v)-analytic))
    lam = .7
    assert qmetric(lam*r, lam*v) <= analytic+1e-11
assert metric_error < 1e-11 and rotation_error < 1e-10
quantum_geometry = {
    'interior_state_cases': 128, 'additional_sampled_axes': sampled_axes,
    'metric': 'v.v+(r.v)^2/(1-r.r)',
    'analytic_optimum_max_error': metric_error,
    'proper_rotation_metric_max_error': rotation_error,
    'chosen_depolarizing_contraction_lambda': .7,
    'radial_example_r': [0, 0, .6], 'radial_example_v': [0, 0, 1],
    'radial_example_metric': qmetric(np.array([0, 0, .6]), np.array([0, 0, 1])),
    'Euclidean_metric_at_same_example': 1.0,
    'phenomenal_metric_identity_established': False}

# 7. The smallest complex factor also has a Lorentz-shaped positive cone.
# This is an algebraic identification, not a derivation of physical spacetime.
s0, x0, y0, z0, rapidity, eig = sp.symbols('s x y z rapidity lambda', real=True)
contrast = s0*I2+x0*X+y0*Y+z0*Z
lorentz_form = s0**2-x0**2-y0**2-z0**2
assert sp.expand(contrast.det()-lorentz_form) == 0
assert sp.expand((contrast-eig*I2).det()-((eig-s0)**2-x0**2-y0**2-z0**2)) == 0
F = sp.diag(sp.exp(rapidity/2), sp.exp(-rapidity/2))
boosted = F*contrast*F
boost_s = sp.trace(boosted)/2
boost_z = sp.trace(boosted*Z)/2
assert sp.simplify((boost_s-sp.cosh(rapidity)*s0-sp.sinh(rapidity)*z0).rewrite(sp.exp)) == 0
assert sp.simplify((boost_z-sp.sinh(rapidity)*s0-sp.cosh(rapidity)*z0).rewrite(sp.exp)) == 0
assert sp.simplify(sp.trace(boosted*X)/2-x0) == 0
assert sp.simplify(sp.trace(boosted*Y)/2-y0) == 0
assert sp.simplify(boosted.det()-contrast.det()) == 0
lorentz_cone = {
    'operator_coordinates': 'X=s I+x sigma_x+y sigma_y+z sigma_z',
    'determinant': str(lorentz_form),
    'positive_cone': 's >= sqrt(x^2+y^2+z^2)',
    'boost_verified_symbolically': True,
    'boost_s': 'cosh(rapidity)*s+sinh(rapidity)*z',
    'boost_z': 'sinh(rapidity)*s+cosh(rapidity)*z',
    'determinant_preserved': True,
    'boost_is_generally_trace_preserving': False,
    'physical_spacetime_identification_proven': False}

# 8. Composite consistency: positive is weaker than completely positive.
bell = np.array([1, 0, 0, 1], dtype=complex)/math.sqrt(2)
rhoAB = np.outer(bell, bell.conj())

def partial_trace_B(rho):
    return np.einsum('abcb->ac', rho.reshape(2, 2, 2, 2))


def partial_transpose_B(rho):
    return rho.reshape(2, 2, 2, 2).transpose(0, 3, 2, 1).reshape(4, 4)

pt = partial_transpose_B(rhoAB)
pt_spectrum = np.linalg.eigvalsh(pt).tolist()
assert np.allclose(pt_spectrum, [-.5, .5, .5, .5])
gamma = .3
K0 = np.diag([1, math.sqrt(1-gamma)]).astype(complex)
K1 = np.array([[0, math.sqrt(gamma)], [0, 0]], dtype=complex)
assert np.allclose(K0.conj().T@K0+K1.conj().T@K1, id2)
channelled = sum(np.kron(id2, K)@rhoAB@np.kron(id2, K).conj().T
                 for K in (K0, K1))
no_signal_error = float(np.linalg.norm(partial_trace_B(channelled)-partial_trace_B(rhoAB)))
assert no_signal_error < 1e-12
assert np.linalg.eigvalsh(channelled).min() >= -1e-12
composites = {
    'Bell_partial_transpose_spectrum': pt_spectrum,
    'transpose_is_positive_but_not_completely_positive': True,
    'chosen_local_amplitude_damping_gamma': gamma,
    'unconditioned_other_marginal_error': no_signal_error,
    'spacetime_or_relativistic_locality_derived': False}

# 9. The kinematics still permits different actual Hamiltonians.
ket00 = np.array([1, 0, 0, 0], dtype=complex)
XX = np.kron(sigma[0], sigma[0])
choices = []
for g in (0.0, 1.0):
    t = math.pi/4
    state = expm(-1j*g*XX*t)@ket00
    rho = np.outer(state, state.conj())
    marginal = partial_trace_B(rho)
    purity = float(np.trace(marginal@marginal).real)
    choices.append({'coupling_g': g, 'time': t,
                    'reduced_purity': purity,
                    'total_state_purity': float(np.trace(rho@rho).real)})
assert abs(choices[0]['reduced_purity']-1) < 1e-12
assert abs(choices[1]['reduced_purity']-.5) < 1e-12

# 10. Algebraic simplicity is not a subject selector.
local_A = [sp.kronecker_product(a, I2) for a in (X, Y, Z)]
local_B = [sp.kronecker_product(I2, b) for b in (X, Y, Z)]
assert all(zero(a*b-b*a) for a in local_A for b in local_B)
factorization = {
    'whole_is_complex_matrix_factor': 'M_4(C)',
    'commuting_local_complex_factors': ['M_2(C) tensor I', 'I tensor M_2(C)'],
    'cross_commutation_verified': True,
    'simplicity_alone_determines_subject_boundaries': False}

results = {
    'scope': 'Conditional finite-algebra reconstruction; no phenomenal or necessity proof.',
    'classification_dimension_screen': dimension_screen,
    'independently_computed_derivation_spaces': computed_derivations,
    'exact_multilinear_identity_checks': exact_identity_checks,
    'weak_self_conservation_counterexample': weak_correspondence,
    'static_structure_vs_orientation': orientation_check,
    'Born_and_unitary_dynamics': born_and_dynamics,
    'full_contrast_discrimination_geometry': quantum_geometry,
    'minimal_complex_factor_Lorentz_cone': lorentz_cone,
    'composite_consistency': composites,
    'different_actual_Hamiltonians': choices,
    'factorization_vs_subjects': factorization,
    'all_assertions_passed': True}
OUT.write_text(json.dumps(results, indent=2)+'\n')
print(json.dumps(results, indent=2))
