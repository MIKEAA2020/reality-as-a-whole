"""Round 3: prototype subject criterion, invariance, and quality-space geometry.

This is an illustrative interventional cut score, NOT an implementation of
IIT 4.0 and NOT a consciousness detector. Binary nodes have conditionally
independent next-state noise; external inputs are held fixed before averaging.
Dependencies: Python 3 and SymPy. No empirical consciousness data are used.
"""
from itertools import product, combinations
from pathlib import Path
import json
import math
import sympy as sp


def states(n):
    return list(product((0, 1), repeat=n))


def h2(p):
    return -sum(a*math.log2(a) for a in (p, 1-p) if a > 0)


def bern_kl(p, q):
    out = 0.0
    for a, b in ((p, q), (1-p, 1-q)):
        if a > 0:
            if b <= 0:
                return math.inf
            out += a*math.log2(a/b)
    return out


class Network:
    def __init__(self, n, probabilities):
        self.n = n
        self.inputs = states(n)
        self.table = {x: tuple(float(v) for v in probabilities(x)) for x in self.inputs}
        assert all(len(p) == n and all(0 <= a <= 1 for a in p) for p in self.table.values())
        self.cache = {}

    def cut_cost(self, source, target):
        # Each target independently receives fresh uniform source-bit inputs.
        # All other bits, including external context, are fixed for this cut.
        key = (tuple(sorted(source)), tuple(sorted(target)))
        if key in self.cache:
            return self.cache[key]
        a, b = key
        total = 0.0
        alternatives = states(len(a))
        for x in self.inputs:
            ps = self.table[x]
            for i in b:
                q = 0.0
                for values in alternatives:
                    xp = list(x)
                    for j, v in zip(a, values):
                        xp[j] = v
                    q += self.table[tuple(xp)][i]
                q /= len(alternatives)
                total += bern_kl(ps[i], q)
        answer = total/len(self.inputs)
        self.cache[key] = max(0.0, answer)
        return self.cache[key]

    def integration(self, subset):
        s = tuple(sorted(subset))
        assert len(s) >= 2
        values = []
        # Symmetry of the bidirectional min permits fixing one node in A.
        for k in range(1, len(s)):
            for aa in combinations(s, k):
                if s[0] not in aa:
                    continue
                a = frozenset(aa)
                b = frozenset(s)-a
                values.append(min(self.cut_cost(a, b), self.cut_cost(b, a)))
        return min(values)

    def scores(self):
        return {frozenset(s): self.integration(s)
                for k in range(2, self.n+1) for s in combinations(range(self.n), k)}


def selection(table, tol=1e-10):
    strict, frontier = [], []
    for s, v in table.items():
        if v <= tol:
            continue
        overlaps = [w for t, w in table.items() if t != s and s & t]
        if all(v > w+tol for w in overlaps):
            strict.append(sorted(s))
        if not any(w > v+tol for w in overlaps):
            frontier.append(sorted(s))
    return {'strict_winners': sorted(strict), 'nondominated_frontier': sorted(frontier)}


copy = Network(2, lambda x: (x[0], x[1]))
swap = Network(2, lambda x: (x[1], x[0]))
feedforward = Network(2, lambda x: (x[0], x[0]))
common_driver = Network(3, lambda x: (x[0], x[0], x[0]))
assert copy.integration({0, 1}) == 0
assert abs(swap.integration({0, 1})-1) < 1e-12
assert feedforward.integration({0, 1}) == 0
assert common_driver.integration({1, 2}) == 0
# Compute the observational dependence of the two driven outputs.
joint = {}
for x in common_driver.inputs:
    out = (int(common_driver.table[x][1]), int(common_driver.table[x][2]))
    joint[out] = joint.get(out, 0)+1/len(common_driver.inputs)
left = {a: sum(v for (aa, b), v in joint.items() if aa == a) for a in (0, 1)}
right = {b: sum(v for (a, bb), v in joint.items() if bb == b) for b in (0, 1)}
common_driver_observational_mi = sum(v*math.log2(v/(left[a]*right[b]))
                                    for (a, b), v in joint.items() if v > 0)
assert common_driver_observational_mi == 1.0

# A bijective recoding of the swap dynamics into triangular coordinates.
phi = lambda x: (x[0] ^ x[1], x[1])
original_update = lambda x: (x[1], x[0])
recoded_update = lambda u: (u[0], u[0] ^ u[1])
for x in states(2):
    assert phi(original_update(x)) == recoded_update(phi(x))
triangular = Network(2, recoded_update)
assert triangular.integration({0, 1}) == 0
# Transport the actual physical cut operations instead of imposing new local
# u/v cuts: KL divergence is unchanged by the bijection on outcomes.
transported_costs = []
for source, target in [(0, 1), (1, 0)]:
    total = 0.0
    for x in states(2):
        actual_out = phi(original_update(x))
        cut_outputs = {}
        for new_source in (0, 1):
            y = list(original_update(x))
            y[target] = new_source
            out = phi(tuple(y))
            cut_outputs[out] = cut_outputs.get(out, 0)+0.5
        total += -math.log2(cut_outputs[actual_out])
    transported_costs.append(total/4)
assert transported_costs == [1.0, 1.0]

# Two strongly paired networks with cross-input modulation.
paired = [1, 0, 3, 2]
cross = [2, 3, 0, 1]


def cross_network(epsilon):
    def p(x):
        return [float(x[paired[i]]) if x[cross[i]] == 0
                else (1-epsilon if x[paired[i]] else epsilon)
                for i in range(4)]
    return Network(4, p)


sweep = []
for epsilon in [0, 0.01, 0.1, 0.25, 0.4, 0.45, 0.5, 0.75, 1.0]:
    net = cross_network(epsilon)
    table = net.scores()
    pair_value = 1-0.5*h2(epsilon)
    weak_value = h2(epsilon/2)-0.5*h2(epsilon)
    whole_value = min(pair_value, 2*weak_value)
    assert abs(table[frozenset({0, 1})]-pair_value) < 1e-10
    assert abs(table[frozenset({2, 3})]-pair_value) < 1e-10
    assert abs(table[frozenset({0, 2})]-weak_value) < 1e-10
    assert abs(table[frozenset(range(4))]-whole_value) < 1e-10
    assert all(v <= 1+1e-10 for v in table.values())
    chosen = selection(table)
    if epsilon < 0.4+1e-10:
        assert chosen['strict_winners'] == [[0, 1], [2, 3]]
    if epsilon >= 0.45:
        assert chosen['strict_winners'] == []
    sweep.append({'epsilon': epsilon,
                  'strong_pair_score': pair_value,
                  'weak_pair_score': weak_value,
                  'whole_score': whole_value,
                  **chosen})

# Unique crossing of weak-cut cost with the singleton/strong-pair ceiling.
lo, hi = 0.0, 1.0
for _ in range(65):
    mid = (lo+hi)/2
    f = 2*h2(mid/2)-0.5*h2(mid)-1
    if f < 0:
        lo = mid
    else:
        hi = mid
critical_epsilon = (lo+hi)/2

# A constructive information geometry calculation.
p, q = sp.symbols('p q', positive=True)
KL = p*sp.log(p/q)+(1-p)*sp.log((1-p)/(1-q))
assert sp.simplify(sp.diff(KL, q).subs(q, p)) == 0
fisher = sp.simplify(sp.diff(KL, q, 2).subs(q, p))
assert sp.simplify(fisher-1/(p*(1-p))) == 0
reverse_KL = q*sp.log(q/p)+(1-q)*sp.log((1-q)/(1-p))
reverse_second = sp.simplify(sp.diff(reverse_KL, q, 2).subs(q, p))
assert sp.simplify(reverse_second-fisher) == 0
u = sp.symbols('u', real=True)
pu = sp.sin(u/2)**2
metric_u = sp.trigsimp(sp.diff(pu, u)**2/(pu*(1-pu)))
assert sp.simplify(metric_u-1) == 0
eta = sp.symbols('eta', real=True)
r = eta+(1-2*eta)*p
noisy_metric = (1-2*eta)**2/(r*(1-r))
metric_loss = eta*(1-eta)/(p*(1-p)*r*(1-r))
assert sp.simplify(1/(p*(1-p))-noisy_metric-metric_loss) == 0


def fisher_distance(a, b):
    return abs(2*math.asin(math.sqrt(a))-2*math.asin(math.sqrt(b)))


a, b, noise = 0.25, 0.75, 0.2
ar = noise+(1-2*noise)*a
br = noise+(1-2*noise)*b
original_distance = fisher_distance(a, b)
noisy_distance = fisher_distance(ar, br)
assert noisy_distance < original_distance
assert abs(original_distance-math.pi/3) < 1e-12

# A neutral abstract background admits different concrete expansions.
# Both models have the same fixed abstract relation a < b, and a concrete
# occurrence at actual world 0. Only the concrete extension at world 1 varies.
neutral_models = [
    {'abstract_order_both_worlds': [['a', 'b']],
     'concrete_at_world_0': ['a'], 'concrete_at_world_1': [],
     'actual_concrete_existence': True, 'necessary_concrete_existence': False},
    {'abstract_order_both_worlds': [['a', 'b']],
     'concrete_at_world_0': ['a'], 'concrete_at_world_1': ['a'],
     'actual_concrete_existence': True, 'necessary_concrete_existence': True},
]

for model in neutral_models:
    assert model['actual_concrete_existence'] == bool(model['concrete_at_world_0'])
    assert model['necessary_concrete_existence'] == (bool(model['concrete_at_world_0'])
                                                    and bool(model['concrete_at_world_1']))

results = {
    'scope': 'Illustrative mathematics and proposed-criterion tests; no consciousness or necessary-existence proof.',
    'prototype_score': {
        'definition': 'Uniform-context mean KL cut cost, minimized over bipartitions and directions; independent next-node noise.',
        'copy_pair': copy.integration({0, 1}),
        'swap_pair': swap.integration({0, 1}),
        'feedforward_pair': feedforward.integration({0, 1}),
        'common_driver_target_pair': common_driver.integration({1, 2}),
        'common_driver_target_observational_MI_bits': common_driver_observational_mi,
        'not_IIT_4': True,
        'sweep': sweep,
        'crossing_epsilon': critical_epsilon,
        'binary_node_ceiling_bits': 1,
    },
    'intervention_covariance': {
        'original_swap_score': 1,
        'fresh_coordinate_local_cuts_after_XOR_recoding': 0,
        'transported_physical_directional_cut_costs': transported_costs,
        'interpretation': 'Carry physical intervention structure through coordinate changes; do not replace it with new local operations.',
    },
    'quality_space_geometry': {
        'KL_second_derivative': str(fisher),
        'metric': 'dp^2/[p(1-p)]',
        'flattening_coordinate': 'u=2*arcsin(sqrt(p))',
        'metric_in_u_coordinate': str(sp.simplify(metric_u-1)+1),
        'reverse_KL_same_second_derivative': bool(sp.simplify(reverse_second-fisher) == 0),
        'p': a, 'q': b, 'binary_noise_eta': noise,
        'original_Fisher_Rao_distance': original_distance,
        'after_noise_distance': noisy_distance,
        'phenomenal_identity_follows_from_geometry_alone': False,
    },
    'existence_neutral_expansions': neutral_models,
}
output = Path(__file__).with_name('round3_results.json')
output.write_text(json.dumps(results, indent=2)+'\n')
print(json.dumps(results, indent=2))
