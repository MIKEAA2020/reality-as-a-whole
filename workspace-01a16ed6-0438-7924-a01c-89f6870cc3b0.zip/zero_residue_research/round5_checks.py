"""Round 5: reduce the reconstruction assumptions and test their independence.

Not empirical consciousness research. Convex countermodels establish only
formal non-entailments, not metaphysical possibilities. The Barnum--Hilgert
spectrality/strong-symmetry theorem and Jordan classification are cited inputs.

Computations:
  * finite-polytope distinguishability via LP, including regular pentagon;
  * spectral decompositions of a point joined to a disk;
  * exact linear conserved-label assignments for rotation balls and matrices;
  * a capacity/local-tomography dimension screen with symbolic general gaps;
  * real two-level systems: hidden joint statistic and reversible interaction.

Run: python zero_residue_research/round5_checks.py
Dependencies: numpy, scipy, sympy.
"""
from pathlib import Path
from itertools import combinations, permutations
import json
import math
import numpy as np
import sympy as sp
from scipy.optimize import linprog
from sympy.polys.matrices import DomainMatrix

OUT = Path(__file__).with_name('round5_results.json')


def regular_polygon(n):
    angles = 2*np.pi*np.arange(n)/n
    return np.column_stack([np.cos(angles), np.sin(angles)])


def distinguishable(vertices, selected):
    """All affine effects allowed. Find m positive effects summing to 1."""
    m = len(selected)
    nv, d = vertices.shape
    vh = np.column_stack([np.ones(nv), vertices])
    q = d+1
    Aeq, beq = [], []
    for k in range(q):
        row = np.zeros(m*q)
        for j in range(m):
            row[j*q+k] = 1
        Aeq.append(row)
        beq.append(float(k == 0))
    for j in range(m):
        for i, index in enumerate(selected):
            row = np.zeros(m*q)
            row[j*q:(j+1)*q] = vh[index]
            Aeq.append(row)
            beq.append(float(i == j))
    result = linprog(np.zeros(m*q),
                     A_ub=np.kron(np.eye(m), -vh), b_ub=np.zeros(m*nv),
                     A_eq=np.array(Aeq), b_eq=np.array(beq),
                     bounds=[(None, None)]*(m*q), method='highs')
    if result.status not in (0, 2):
        raise RuntimeError(f'LP did not decide feasibility: {result.message}')
    if result.success:
        coefficients = result.x.reshape(m, q)
        assert np.min(coefficients@vh.T) > -1e-8
        assert np.max(np.abs(coefficients.sum(axis=0)-np.eye(1, q)[0])) < 1e-8
        for j in range(m):
            for i, index in enumerate(selected):
                assert abs(coefficients[j]@vh[index]-float(i == j)) < 1e-8
    return result.success


def ordered_frame_orbits(n, frames):
    remaining = set(tuple(p) for f in frames for p in permutations(f))
    group = [tuple((sign*i+k) % n for i in range(n))
             for sign in (1, -1) for k in range(n)]
    sizes = []
    while remaining:
        f = min(remaining)
        orbit = {tuple(g[i] for i in f) for g in group}
        assert orbit.issubset(remaining)
        remaining -= orbit
        sizes.append(len(orbit))
    return sizes


def point_segment_distance(point, a, b):
    delta = b-a
    t = float(np.clip((point-a)@delta/(delta@delta), 0, 1))
    return float(np.linalg.norm(point-a-t*delta))


# 1. Exact finite frame enumeration, with numerical LP feasibility.
polygons = {}
for n in (3, 4, 5):
    vertices = regular_polygon(n)
    frames = {m: [list(f) for f in combinations(range(n), m)
                  if distinguishable(vertices, f)] for m in (1, 2, 3)}
    orbit_sizes = {m: ordered_frame_orbits(n, frames[m]) for m in (1, 2, 3)}
    polygons[str(n)] = {
        'vertices': vertices.tolist(),
        'perfectly_distinguishable_frames': frames,
        'ordered_frame_orbit_sizes': orbit_sizes,
        'capacity': max(m for m in frames if frames[m]),
        'strong_symmetry': all(len(orbit_sizes[m]) <= 1 for m in (1, 2, 3))}
assert polygons['3']['capacity'] == 3 and polygons['3']['strong_symmetry']
assert polygons['4']['capacity'] == 2 and not polygons['4']['strong_symmetry']
assert polygons['5']['capacity'] == 2 and polygons['5']['strong_symmetry']
assert len(polygons['5']['perfectly_distinguishable_frames'][2]) == 5
assert all(min((a-b) % 5, (b-a) % 5) == 2
           for a, b in polygons['5']['perfectly_distinguishable_frames'][2])
v5 = regular_polygon(5)
center_dist = min(point_segment_distance(np.zeros(2), v5[a], v5[b])
                  for a, b in polygons['5']['perfectly_distinguishable_frames'][2])
assert abs(center_dist-(math.sqrt(5)-1)/4) < 1e-10
assert np.linalg.norm(v5.mean(axis=0)) < 1e-12
polygons['5']['center_distance_from_any_frame_segment'] = center_dist
polygons['5']['center_has_spectral_decomposition'] = False
polygons['5']['center_is_equal_mixture_of_all_five_vertices'] = True

# 2. Spectral but not strongly symmetric: a point joined to a disk.
rng = np.random.default_rng(20261024)
join_error = effect_error = 0.0
for _ in range(512):
    p = rng.uniform(0, 1)
    n = rng.normal(size=2)
    n /= np.linalg.norm(n)
    radius = (1-p)*rng.uniform(0, 1)
    r = radius*n
    weights = np.array([p, (1-p+radius)/2, (1-p-radius)/2])
    pure = np.array([[1, 0, 0], [0, *n], [0, *(-n)]])
    state = np.array([p, *r])
    join_error = max(join_error, float(np.linalg.norm(weights@pure-state)))
    assert np.min(weights) >= -1e-12
    assert abs(weights.sum()-1) < 1e-12
    # e_c=p; e_+=(1-p+n.r)/2; e_-=(1-p-n.r)/2.
    values = np.array([[w[0], (1-w[0]+n@w[1:])/2,
                       (1-w[0]-n@w[1:])/2] for w in pure])
    effect_error = max(effect_error, float(np.linalg.norm(values-np.eye(3))))
assert join_error < 1e-12 and effect_error < 1e-12
join = {'random_states': 512, 'max_reconstruction_error': join_error,
        'max_distinguishing_effect_error': effect_error,
        'capacity': 3,
        'all_states_spectral_by_displayed_formula': True,
        'strong_symmetry': False,
        'reason': 'The apex is an isolated pure state; disk pure states form a circle.'}

# 3. Solve all linear conserved-label assignments exactly.
def label_assignments(actions):
    """Unknown B: generator coefficients -> centered observable coefficients.

    Conservation for every generator x says A(x) B(x)=0. Polarization
    gives A_a B_a=0 and A_a B_b+A_b B_a=0, a<b.
    """
    g, q = len(actions), actions[0].rows
    entries = {}
    row = 0
    for a in range(g):
        for b in range(a, g):
            for i in range(q):
                coeff = {}
                for j in range(q):
                    index = j*g+b
                    coeff[index] = coeff.get(index, sp.S.Zero)+actions[a][i, j]
                    if a != b:
                        index = j*g+a
                        coeff[index] = coeff.get(index, sp.S.Zero)+actions[b][i, j]
                for column, value in coeff.items():
                    if value:
                        entries[(row, column)] = value
                row += 1
    system = sp.SparseMatrix(row, q*g, entries)
    rank = int(DomainMatrix.from_Matrix(system).rank())
    nullity = q*g-rank
    output = {'generators': g, 'centered_observables': q,
              'equations': row, 'unknowns': q*g,
              'rank': rank, 'assignment_space_dimension': nullity}
    if nullity:
        vectors = system.nullspace()
        assert len(vectors) == nullity
        matrices = [sp.Matrix(q, g, lambda i, j: v[i*g+j]) for v in vectors]
        output['basis_assignment_ranks'] = [int(B.rank()) for B in matrices]
        output['basis_assignments'] = [[[str(x) for x in B.row(i)]
                                        for i in range(q)] for B in matrices]
    return output


def skew_basis(d):
    result = []
    for i in range(d):
        for j in range(i+1, d):
            K = sp.zeros(d)
            K[i, j], K[j, i] = 1, -1
            result.append(K)
    return result


ball_labels = {}
for d in range(2, 8):
    result = label_assignments(skew_basis(d))
    assert result['assignment_space_dimension'] == int(d == 3)
    if d == 3:
        assert result['basis_assignment_ranks'] == [3]
    ball_labels[str(d)] = result


def centered_matrix_basis(n, real=False):
    result = []
    for k in range(1, n):
        D = sp.zeros(n)
        for i in range(k):
            D[i, i] = 1
        D[k, k] = -k
        result.append(D)
    for i in range(n):
        for j in range(i+1, n):
            S = sp.zeros(n)
            S[i, j] = S[j, i] = 1
            result.append(S)
            if not real:
                A = sp.zeros(n)
                A[i, j], A[j, i] = -sp.I, sp.I
                result.append(A)
    return result


def matrix_label_model(n, real=False):
    observables = centered_matrix_basis(n, real)
    generators = skew_basis(n) if real else [-sp.I*H for H in observables]
    norms = [sp.trace(a*a) for a in observables]
    actions = []
    for K in generators:
        D = sp.Matrix(len(observables), len(observables),
                      lambda i, j: sp.simplify(sp.trace(observables[i]*(K*observables[j]-observables[j]*K))/norms[i]))
        assert all(sp.im(x) == 0 for x in D)
        actions.append(D)
    return label_assignments(actions)


matrix_labels = {}
for n in (2, 3, 4):
    matrix_labels[f'real_{n}'] = matrix_label_model(n, real=True)
    assert matrix_labels[f'real_{n}']['assignment_space_dimension'] == 0
for n in (2, 3):
    result = matrix_label_model(n, real=False)
    assert result['assignment_space_dimension'] == 1
    assert result['basis_assignment_ranks'] == [n*n-1]
    B = sp.Matrix([[sp.sympify(x) for x in row] for row in result['basis_assignments'][0]])
    assert B == B[0, 0]*sp.eye(n*n-1)
    matrix_labels[f'complex_{n}'] = result

# Ordinary process distinguishability does not imply conserved labels.
t = math.pi/2
process_observability = {
    'initial_disk_state': [1, 0], 'time': t,
    'plus_rotation_y_effect_probability': (1+math.sin(t))/2,
    'minus_rotation_y_effect_probability': (1-math.sin(t))/2,
    'nonconstant_linear_conserved_labels_for_all_disk_rotations':
        ball_labels['2']['assignment_space_dimension']}
assert process_observability['plus_rotation_y_effect_probability'] == 1
assert process_observability['minus_rotation_y_effect_probability'] == 0

# 4. A second route: capacity multiplication and local tomography.
def rank_dimension_candidates(rank):
    # Self-composite rank >=4: spin and exceptional rank-3 cases cannot occur.
    assert rank >= 4
    return {'real': rank*(rank+1)//2,
            'complex': rank*rank,
            'quaternionic': rank*(2*rank-1)}


composition_screen = []
models = []
for n in range(2, 9):
    models.extend([('real', n, n*(n+1)//2),
                   ('complex', n, n*n),
                   ('quaternionic', n, n*(2*n-1))])
for d in range(2, 11):
    models.append((f'spin_{d}', 2, d+1))
models.append(('exceptional_Albert', 3, 27))
for family, rank, dimension in models:
    candidates = rank_dimension_candidates(rank*rank)
    wanted = dimension*dimension
    matches = [name for name, D in candidates.items() if D == wanted]
    composition_screen.append({'family': family, 'capacity': rank,
                               'full_state_dimension': dimension,
                               'required_composite_capacity': rank*rank,
                               'required_composite_dimension': wanted,
                               'candidate_dimensions_at_that_capacity': candidates,
                               'matches': matches})
    assert bool(matches) == (family == 'complex' or family == 'spin_3')
n = sp.symbols('n', integer=True, positive=True)
DR = lambda x: x*(x+1)/2
DH = lambda x: x*(2*x-1)
real_gap = sp.factor(DR(n*n)-DR(n)**2)
quaternionic_gap = sp.factor(DH(n)**2-DH(n*n))
assert sp.expand(real_gap-n*n*(n-1)**2/4) == 0
assert sp.expand(quaternionic_gap-2*n*n*(n-1)**2) == 0

# 5. Real quantum systems are coherent and can interact without local tomography.
I2 = sp.eye(2)
X = sp.Matrix([[0, 1], [1, 0]])
Y = sp.Matrix([[0, -sp.I], [sp.I, 0]])
Z = sp.diag(1, -1)
YY = sp.kronecker_product(Y, Y)
I4 = sp.eye(4)
rho_plus, rho_minus = (I4+YY)/4, (I4-YY)/4
assert all(sp.im(x) == 0 for x in YY)
assert rho_plus == rho_plus.T and rho_minus == rho_minus.T
assert sp.trace(rho_plus) == sp.trace(rho_minus) == 1
assert all(value >= 0 for rho in (rho_plus, rho_minus) for value in rho.eigenvals())
local = (I2, X, Z)
product_differences = [sp.simplify(sp.trace((rho_plus-rho_minus)*sp.kronecker_product(a, b)))
                       for a in local for b in local]
assert product_differences == [0]*9
Qplus = (I4+YY)/2
assert Qplus*Qplus == Qplus
joint_probabilities = [sp.trace(rho*Qplus) for rho in (rho_plus, rho_minus)]
assert joint_probabilities == [1, 0]
J = sp.Matrix([[0, -1], [1, 0]])
K = sp.kronecker_product(J, X)
assert K.T == -K and K*K == -I4
U = (I4+K)/sp.sqrt(2)
assert U.T*U == I4
ket00 = sp.Matrix([1, 0, 0, 0])
state = U*ket00
assert state == sp.Matrix([1, 0, 0, 1])/sp.sqrt(2)
rho = state*state.T
marginal = sp.Matrix(2, 2, lambda a, c: sum(rho[2*a+b, 2*c+b] for b in (0, 1)))
assert sp.trace(marginal*marginal) == sp.Rational(1, 2)
real_composite = {
    'one_rebit_full_state_dimension': 3,
    'two_rebits_full_state_dimension': 10,
    'local_product_dimension': 9,
    'hidden_joint_observable': str(YY),
    'all_local_product_expectation_differences': [int(x) for x in product_differences],
    'joint_effect_probabilities': [int(x) for x in joint_probabilities],
    'rho_plus_spectrum_with_multiplicity': sorted([str(x) for x, m in rho_plus.eigenvals().items() for _ in range(m)]),
    'rho_minus_spectrum_with_multiplicity': sorted([str(x) for x, m in rho_minus.eigenvals().items() for _ in range(m)]),
    'real_orthogonal_interaction_verified': True,
    'entangled_output_reduced_purity': str(sp.trace(marginal*marginal)),
    'local_tomography_holds': False}

results = {
    'scope': 'Conditional reconstruction and countermodels; no necessity or phenomenality proof.',
    'polygon_frame_enumeration': polygons,
    'spectral_nonhomogeneous_join': join,
    'exact_ball_conserved_label_spaces': ball_labels,
    'exact_matrix_conserved_label_spaces': matrix_labels,
    'process_observability_vs_energy_labels': process_observability,
    'composition_route_dimension_screen': composition_screen,
    'general_positive_dimension_gaps': {'real': str(real_gap), 'quaternionic': str(quaternionic_gap)},
    'real_composite_counterexample': real_composite,
    'all_assertions_passed': True}
OUT.write_text(json.dumps(results, indent=2)+'\n')
print(json.dumps(results, indent=2))
