"""Small exact checks supporting Zero-Residue Research, v1.

These are toy-model tests and exact finite calculations, not proofs of a
metaphysical theory or tests of whether physical systems are conscious.
Run with Python 3; no third-party dependencies.
"""
from fractions import Fraction as F
from itertools import product
import json
from pathlib import Path


def matmul(a, b):
    return [[sum(a[i][k] * b[k][j] for k in range(len(b)))
             for j in range(len(b[0]))] for i in range(len(a))]


def trace(a):
    return sum(a[i][i] for i in range(len(a)))


def partial_trace_b(rho):
    return [[sum(rho[2*a+b][2*ap+b] for b in range(2))
             for ap in range(2)] for a in range(2)]


def partial_trace_a(rho):
    return [[sum(rho[2*a+b][2*a+bp] for a in range(2))
             for bp in range(2)] for b in range(2)]


# Universal two-world accessibility: box means truth at both worlds.
# Conditional result: box(E) and box(E -> p) entail box(p).
modal_premise_models = []
modal_counterexamples = []
weakened_counterexamples = []
for e0, e1, p0, p1 in product([False, True], repeat=4):
    E, p = (e0, e1), (p0, p1)
    necessary_link = all((not E[i]) or p[i] for i in range(2))
    if all(E) and necessary_link:
        modal_premise_models.append({'E': E, 'p': p})
        if not all(p):
            modal_counterexamples.append({'E': E, 'p': p})
    # E actually holds at world zero, but its necessity is not assumed.
    if E[0] and necessary_link and not all(p):
        weakened_counterexamples.append({'E': E, 'p': p})
assert not modal_counterexamples
assert weakened_counterexamples

# A conditional route to necessary concrete actuality in S5.
# A means "some concrete actuality exists"; on this universal frame,
# GP = box(diamond(A) -> A). Actual A and GP entail box(A).
grounded_possibility_rows = []
for a0, a1 in product([False, True], repeat=2):
    A = (a0, a1)
    possible_A = any(A)
    GP = all((not possible_A) or A[i] for i in range(2))
    if A[0] and GP:
        assert all(A)
    grounded_possibility_rows.append({
        'A': A, 'actual_A_at_world_zero': A[0],
        'grounded_possibility_principle': GP,
        'necessary_A': all(A),
    })
# Necessary nonemptiness does not identify a necessarily concrete individual.
occupants = [{'a'}, {'b'}]
assert all(bool(world) for world in occupants)
assert not set.intersection(*occupants)

# Symmetry test: swap two equally ranked, overlapping subject candidates.
# An equivariant rule returning a single candidate cannot choose one of them
# if the input itself is invariant under the swap.
candidates = [frozenset({0, 1}), frozenset({1, 2})]
swap = {0: 2, 1: 1, 2: 0}
act = lambda s: frozenset(swap[x] for x in s)
assert act(candidates[0]) == candidates[1]
assert act(candidates[1]) == candidates[0]
invariant_selections = []
for included in product([False, True], repeat=2):
    selected = frozenset(candidates[i] for i in range(2) if included[i])
    transformed = frozenset(act(x) for x in selected)
    if transformed == selected:
        invariant_selections.append([sorted(x) for x in selected])
assert all(len(x) != 1 for x in invariant_selections)

# Joint states are not determined by individual marginals.
# Bell state's density matrix has entries 1/2 at (00,00),(00,11),
# (11,00),(11,11). Compare the fully mixed two-qubit density matrix.
bell = [[F(0) for _ in range(4)] for _ in range(4)]
for i, j in [(0, 0), (0, 3), (3, 0), (3, 3)]:
    bell[i][j] = F(1, 2)
mixed = [[F(int(i == j), 4) for j in range(4)] for i in range(4)]
assert partial_trace_a(bell) == partial_trace_a(mixed)
assert partial_trace_b(bell) == partial_trace_b(mixed)
assert trace(matmul(bell, bell)) == 1
assert trace(matmul(mixed, mixed)) == F(1, 4)
local_purity = trace(matmul(partial_trace_b(bell), partial_trace_b(bell)))
assert local_purity == F(1, 2)
zz = [1, -1, -1, 1]
expect_zz = lambda rho: sum(zz[i] * rho[i][i] for i in range(4))
assert expect_zz(bell) == 1
assert expect_zz(mixed) == 0

# A symmetric two-state transition system cannot define an oriented unary
# phenomenal label solely from its unlabelled, swap-symmetric structure.
X = {0, 1}
label_sets = [frozenset(i for i, included in enumerate(mask) if included)
              for mask in product([False, True], repeat=2)]
label_invariant = [sorted(q) for q in label_sets
                   if frozenset(1-i for i in q) == q]
assert label_invariant == [[], [0, 1]]
# This does not establish that real physical structures have this symmetry,
# or that phenomenality is not structurally definable in some richer theory.

results = {
    'scope': 'Exact finite illustrations; not a verification of metaphysical closure.',
    'necessary_ground_check': {
        'worlds': 2,
        'valuations_examined': 16,
        'counterexamples_to_stated_conditional': modal_counterexamples,
        'counterexamples_when_ground_necessity_is_dropped': weakened_counterexamples,
    },
    'grounded_possibility_existence_route': {
        'two_world_rows': grounded_possibility_rows,
        'premise': 'S5 plus actual A plus box(diamond(A) -> A)',
        'conclusion': 'box(A); the grounding premise is not independently established',
        'necessary_nonemptiness_implies_necessary_individual': False,
        'different_occupants_countermodel': [sorted(world) for world in occupants],
    },
    'symmetric_subject_selector': {
        'candidate_sets': [sorted(x) for x in candidates],
        'symmetry_invariant_selections': invariant_selections,
        'unique_invariant_single_candidate_exists': False,
        'scope': 'Only an invariant input with an automorphism swapping candidates; not an IIT calculation.',
    },
    'quantum_joint_state_check': {
        'same_A_marginal': True,
        'same_B_marginal': True,
        'bell_global_purity': str(trace(matmul(bell, bell))),
        'mixed_global_purity': str(trace(matmul(mixed, mixed))),
        'local_purity_both_cases': str(local_purity),
        'bell_ZZ_expectation': str(expect_zz(bell)),
        'mixed_ZZ_expectation': str(expect_zz(mixed)),
        'scope': 'Assumes ordinary finite-dimensional complex quantum mechanics; no claim about consciousness.',
    },
    'qualitative_label_toy_check': {
        'invariant_unary_extensions': label_invariant,
        'singleton_label_uniquely_definable_from_this_symmetric_base': False,
        'scope': 'A toy definability constraint, not a no-go theorem for physicalism or structural theories.',
    },
}
path = Path(__file__).with_name('check_results.json')
path.write_text(json.dumps(results, indent=2) + '\n')
print(json.dumps(results, indent=2))
