# Toward a zero-residue account of reality
## Constructive research notebook — version 1

**24 October 2026**  
**Aim:** a fully intelligible account of reality as a whole, with no unexplained actuality, arbitrary foundation, omitted experience, or illicit explanatory exemption.  
**Status:** a strengthened candidate architecture, several conditional derivations, exact toy-model checks, and a prioritized route toward the remaining foundations. **Not a completed theory of everything.**

This notebook advances the project beyond the earlier audit. It does not treat the failure of the original self-simulation argument as a reason to abandon its ambition. It replaces that argument with a more disciplined construction, develops some bridges rather than merely requesting them, and records where further inference is still required.

## Executive construction

The working hypothesis is **immanent constitutive realism**:

> Reality is actual concrete constitution, not a description awaiting execution by an external machine. Physical structure, phenomenal occurrence, and the existence of subjects must be accounted for within that constitution. A whole-reality explanation must ultimately explain why this constitution obtains, or establish why the remaining demand for an explanation is genuinely inapplicable—not merely declare its foundation exempt.

Here **concrete** means instantiated or occurrent, not necessarily material and not necessarily situated in a pre-existing spacetime. It marks the actuality to be explained rather than supplying an explanation of it.

The lead completion to investigate is an **intrinsically qualitative-relational constitution**: physical relations are not relations between wholly unspecified placeholders, and actual experience is included in what is real rather than added to an otherwise complete ontology. This is a research choice, not an established identity between physical structure and experience. It neither asserts that everything is conscious nor postulates a single cosmic subject.

Six advances are developed here:

1. **Constitution replaces external execution.** This removes an unnecessary host/interpreter regress without pretending to explain existence itself.
2. **The modal target becomes explicit.** Necessary grounds plus necessitating explanations yield necessary consequences. A weaker probabilistic or grounding explanation must not be silently advertised as answering the stronger contrastive question.
3. **Subject individuation gets a mathematical target and a symmetry test.** A partition can be recovered from an appropriate co-consciousness relation; deriving that relation remains the substantive task. “Choose the maximum” is insufficient in symmetric tie cases without further principles.
4. **A genuine spacetime bridge is supplied.** Under suitable continuum assumptions, chronological order fixes conformal geometry, and volume fixes the remaining conformal factor. This is a derivation, not a metaphor about stable relations.
5. **Quantum holism is made precise without metaphysical inflation.** Exact states illustrate why restricted access can coexist with a determinate joint state, while local marginals need not reconstruct that state. Conditional quantum reconstructions identify substantive premises still requiring explanation.
6. **The existence question is pursued through a specific conditional argument.** A concrete-grounding principle for possibility, together with suitable modal assumptions and actual existence, entails necessary concrete nonemptiness. The argument isolates the disputed bridge rather than pretending to have established it; the relevant instance of its grounding premise is shown to be equivalent in strength to the desired necessity under the background assumptions.

The central outstanding question is sharper than “what runs the simulation?”:

> What makes there necessarily be actual concrete constitution at all, and what determines its nature, including experience and physical law?

No argument in this notebook establishes the answer. The purpose is to make the route to an answer more exact and to make several real steps along it.

---

# Pass I — Specify the target without assuming it is attainable

## 1. What would count as zero residue?

Call a proposed account **T**. For every genuine fact within its whole-reality scope, T must do one of the following:

- **Derive it:** show how it follows from adequately justified grounds.
- **Constitute it:** explain what it consists in, with the proposed identity or constitution independently defended.
- **Dissolve the question:** show that the apparent further explanatory demand is ill-typed, contradictory, representational duplication, or otherwise genuinely without an additional target.

Each route requires an argument. Naming something “necessary,” “self-grounding,” “intrinsic,” or “autonomous” does not itself perform any of them.

The account must cover at least:

- existence and actuality;
- the nature and modal status of its foundations;
- laws, states, boundary conditions, and any genuine outcome selection;
- spacetime and its relation to quantum physics;
- phenomenal occurrence, qualitative specificity, unity, and subject boundaries;
- internal representation, computation, and meaning where these are invoked;
- the intelligibility and justification of the explanatory framework itself.

A whole-reality claim also needs an eventual position on mathematical truth and on any genuine normative or value facts. Explaining human judgments about value is not automatically explaining objective value, if such value exists. These topics are registered here, not silently declared solved by the physical/phenomenal architecture.

### Important distinction: a vocabulary is not automatically a residue

An account needs concepts and inference rules. The mere presence of primitive vocabulary does not show that a contingent fact has been left brute. Conversely, having a short vocabulary does not show that its factual commitments have been explained.

For example, introducing the word *constitution* does not explain why any constitution exists. Introducing *experience* can acknowledge an immediately available datum without explaining why this experience occurs. Introducing *necessity* does not establish that the selected foundations possess it.

The standard is therefore **no arbitrary unexplained actuality**, not “a description written without any concepts or inferential resources.” Whether every apparent final explanatory question can legitimately be resolved remains open.

## 2. Three different accomplishments

These should remain separate throughout the project:

| Accomplishment | What it establishes | What it does not establish |
|---|---|---|
| Ontological inclusion | Nothing actual lies outside total reality | Why reality exists or why its members are as they are |
| Conditional explanatory integration | Given a foundation, the relevant phenomena follow | Why that foundation obtains |
| Ultimate closure | The foundation and all genuine residual contrasts are accounted for | Automatic human omniscience or a finite algorithm predicting every event |

We can pursue the third while making real progress on the second. Calling the second the third would defeat the project.

## 3. Starting commitments, with their actual force

**K1 — Some experience is actual.** Even if an apparent world is illusory, the occurrence of seeming is not thereby eliminated. This is an epistemic starting point, not yet a proof that experience exists necessarily or that all reality is experiential.

**K2 — Whole-reality explanation cannot require an actual entity outside all reality.** An alleged external machine or creator, if real, belongs to the total inventory. This does not exclude a creator within that inventory, and does not prove substance monism.

**K3 — A representation is not its realization.** A mathematical model of a fire does not burn merely because it describes combustion. Conversely, an actual fire does not need a separate interpreter to make its combustion occur.

**K4 — Explanation need not mean an earlier event.** Constitutive explanation can explain what something consists in rather than what produced it at an earlier time. This is especially important if time itself belongs to what is being explained.

**K5 — Whole-reality scope does not settle subjecthood.** One totality can contain many subjects, one subject, or regions without subjects. A single domain of quantification is not a single field of awareness.

These commitments guide the construction. They do not jointly entail the lead ontology, quantum mechanics, a cosmic mind, or necessary existence.

---

# Pass II — Build the strongest candidate architecture

## 4. From “self-simulation” to concrete constitution

A simulation normally involves:

1. an abstract specification;
2. a realized system;
3. a relation under which that system implements the specification;
4. often, though not necessarily, a represented target.

Calling the whole “a simulation of itself” does not automatically supply any of these relations. It can also manufacture a problem by treating fundamental reality as if it were inert code awaiting a computer.

The improved starting point is different:

> Actual concrete activity does not need a second instance of itself, outside reality, to make it actual activity.

An actual field need not be a digital rendering of a more fundamental field. Its equations describe relations among its states; they need not be an externally stored program that a further machine reads.

**What this genuinely removes:** the demand for an external executor solely because reality admits a formal description.

**What it does not remove:** why any actual field, process, or constitution exists; why it has these relations; or why its realization includes experience.

This distinction is constructive. It stops us searching for an unnecessary cosmic computer while retaining the actual existence problem.

## 5. One constitution, several kinds of access

Use **C** as a placeholder for the complete concrete constitution, not as a claim that we already possess its specification.

The proposed architecture has three interfaces:

\[
C\;\xrightarrow{\Pi}\;\text{public physical structure},
\]

\[
C\;\xrightarrow{\Sigma}\;\text{subjects or experiential episodes, if any},
\]

\[
(C,s)\;\xrightarrow{Q}\;\text{the phenomenal character of episode }s.
\]

Here:

- **Π** extracts the publicly describable relations and dynamics.
- **Σ** supplies a criterion for which organizations constitute subjects or episodes.
- **Q** specifies what those episodes are like, including their unity and qualitative distinctions.

This is a **specification of what a successful unification must construct**. The arrows are not solutions. If Π, Σ, and Q are independently stipulated lookup tables, the project has merely renamed its gaps.

A successful completion should establish them from the same constitution and show why they are compatible. In particular, it should not obtain phenomenal facts by inserting a concealed subject into every fundamental variable.

### Why explore an intrinsically qualitative-relational completion?

Purely relational descriptions can leave the relata's intrinsic nature unspecified. Experience, meanwhile, is not merely the assertion that some abstract role is occupied: it supplies a case of something actually occurring with qualitative character.

This motivates investigating whether the concrete realizers of physical structure have a nature that already includes the resources for phenomenal occurrence, rather than beginning with an explicitly nonphenomenal base and adding an unrelated second substance.

The motivation is not a proof. A physicalist may deny that a complete physical description leaves the relevant intrinsic nature unspecified; an idealist may propose stronger mental foundations; a neutral monist may reject both classifications. The current architecture does not settle those disputes by notation.

**Working preference:** a nonatomistic, experience-inclusive concrete constitution, with physical descriptions capturing its public structural organization.

**Unpaid obligation:** explain why the concrete constitution has the specified phenomenal character and boundaries, rather than merely relocating phenomenal facts into an unexamined primitive.

## 6. A real but limited simplification: no two-substance interaction problem

If physical organization and phenomenal character are aspects of one constitution, their correlation need not be explained as causal communication between two independent substances.

Compare:

- **Two-substance model:** physical event P causes a distinct mental event M through an additional psychophysical interaction.
- **Constitutive model:** one concrete episode has physical structural description P and phenomenal character M.

The second model avoids an extra interaction mechanism **if the constitution or identity claim is established**. It still must explain the joint specificity: why this P belongs to this M, whether the relation is necessary, and why there is an episode at all.

Thus the interaction problem can be avoided conditionally; the constitution problem cannot be declared solved conditionally.

## 7. Laws as intrinsic constraints, not an external legislature

The lead account should investigate whether the laws are the essential relations of C, rather than separate instructions imposed on otherwise indifferent material.

A useful representation is:

\[
\mathcal{H}_{T}=\{h: h\text{ satisfies the constitutive constraints of }T\}.
\]

Here h is an entire admissible history or other complete realization; no external time is required to “run” the set of constraints.

This representation supports three distinct questions:

1. Why these constraints?
2. Why any actual realization of them?
3. If several realizations are admissible, why this one, or why all of them?

The representation answers none of those questions by itself. Its contribution is to locate them without inventing a further law-enforcing machine.

Nor does a whole-history representation prove that becoming is illusory. If irreducible becoming is a real feature rather than a feature of experience or description, the final constitution must accommodate it. We should not settle that issue merely by choosing an atemporal notation.

## 8. Computation and semantics as internal achievements

Computation should be recovered where concrete organization supports it, not imposed as the essence of all actuality.

For a simple deterministic subsystem, let:

- S be concrete states;
- Fₐ be its transitions under admissible input a;
- A be abstract computational states;
- δₐ be the abstract transition rule;
- h map relevant concrete states onto abstract states.

A necessary structural condition for implementation is:

\[
h(F_a(s))=\delta_a(h(s)).
\]

The condition must hold across appropriate counterfactual states and inputs, not just be fitted retrospectively to one observed trajectory. A credible account also needs independently defensible state types, components, and causal dependencies. The displayed equation alone is not a complete solution to implementation triviality.

This develops the causal/counterfactual route in the implementation literature, including Chalmers's analysis of Putnam's finite-state-automaton argument. That literature also records remaining difficulties; a single unrestricted mapping is not enough. [1](https://consc.net/papers/rock.html) [14](https://consc.net/papers/varieties.pdf) [19](https://plato.stanford.edu/archives/fall2025/entries/computation-physicalsystems/)

An internal representation can additionally be constrained by what it tracks, how errors affect action, and how it is corrected. These are candidate grounds of functional content. They do not automatically explain phenomenal meaning or all intentionality.

**Gain:** neither computation nor minimal functional representation logically requires a conscious interpreter outside the system.

**Limit:** showing that a system computes is not yet showing that it experiences, understands, or grounds all reality.

---

# Pass III — Work the experience and perspective bridge

## 9. Do not start with an unnecessary cosmic subject

A global constitution need not be a globally experienced constitution.

This distinction allows a cleaner construction:

- Global organization determines which relations obtain.
- Some organizations may constitute experiential episodes.
- Distinct episodes may have distinct access and unity.
- Nothing in this description implies a subject that experiences all episodes together.

Starting with a universal subject would create a further task: derive genuinely private subjects from it. Starting with tiny, already complete subjects would create a combination task. The lead architecture assumes neither starting point.

It does **not** thereby solve subject constitution. It avoids adding either of those particular burdens before an argument requires them.

## 10. A conditional derivation of an episode partition

Suppose there is a domain of phenomenal occurrences and a relation J such that J(x,y) means that x and y belong to one unified experiential episode.

If J is reflexive, symmetric, and transitive, then it is an equivalence relation. Its equivalence classes form a unique partition:

\[
\Sigma=\{[x]_J:x\text{ is a phenomenal occurrence}\}.
\]

Every occurrence belongs to exactly one class, and classes do not overlap. This is a genuine mathematical consequence of the assumptions.

But the assumptions contain the hard part:

- Why should an appropriate J obtain in the concrete constitution?
- Is phenomenal unity in fact transitive at the relevant grain and timescale?
- What grounds J without presupposing the subjects being derived?
- Are the relata instantaneous qualities, temporally extended episodes, or something else?

The partition theorem is useful because it makes the missing bridge exact. It does not explain unity merely by writing the word *co-consciousness*. A theory that allows overlapping or nontransitive phenomenal organization will need a different construction.

This concerns **episode individuation**. The persistence of a person across different episodes is a further problem; memory, continuity, and agency may help explain it without being identical to phenomenal unity.

## 11. A symmetry constraint on “pick the maximally integrated subject”

Consider two overlapping candidates:

\[
A=\{0,1\},\qquad B=\{1,2\}.
\]

Suppose the concrete structure is invariant under exchanging 0 and 2, so A and B have exactly the same status under every relevant label-independent score.

Then an invariant rule cannot select exactly A and not B, or exactly B and not A. The symmetry swaps those answers. Its invariant selections from these two candidates are only:

- neither candidate;
- both candidates.

If an additional exclusion rule permits only one of the overlapping candidates, a unique answer requires more structure, a principled tie rule, or a revision of the selection requirement.

This is a small conditional no-selection result, **not a calculation of IIT and not a refutation of integration-based consciousness theories**. Real organizations may break the symmetry, and an actual theory may contain additional rules. The result supplies a benchmark any proposed unique-maximality construction should pass.

The exact finite check in the companion script confirms the invariant-selection calculation.

**Gauge qualification:** if the alternatives differ only by a genuine representational redundancy, a theory may specify an equivalence class instead of choosing a label. The theorem rules out a canonical labelled selector under its assumptions; it does not rule out physical uniqueness up to symmetry. A real unresolved contrast must be established before a tie counts as explanatory residue.

### Connection to existing theory, without outsourcing the solution

IIT 4.0 provides a substantive attempt to connect phenomenal unity, intrinsic causal organization, and exclusion into an explicit subject criterion. It is useful here as a developed candidate, not as a proven identification of consciousness with a score. [1](https://journals.plos.org/ploscompbiol/article?id=10.1371%2Fjournal.pcbi.1011465)

**Important refinement after checking its supplement:** IIT 4.0 already addresses ties. Its S1 supplement compares structure integrated information Φ when overlapping systems tie in system integrated information φₛ; if the tie persists, those systems fail the exclusion requirement and the algorithm seeks a next-best unique system. Thus our symmetry example is not a newly discovered omission in IIT. It explains why a developed theory needs such additional rules. The further constitutive question is why these rules identify actual phenomenal boundaries. [3](http://journals.plos.org/ploscompbiol/article/asset?unique=&id=info%3Adoi%2F10.1371%2Fjournal.pcbi.1011465.s001)

Empirical results must constrain any such bridge. The 2025 COGITATE adversarial collaboration challenged key predictions of both IIT and global neuronal workspace theory while supporting some predictions; it does not certify either as a completed theory. The published Nature study's abstract states this mixed result. [1](https://ideas.repec.org/a/nat/nature/v642y2025i8066d10.1038_s41586-025-08888-1.html)

For our construction, a viable criterion must address at least:

1. why a proposed organization is a subject at all;
2. why its qualitative character is this rather than another;
3. why its boundary and temporal grain are the right ones;
4. why similar information processing is sometimes unconscious;
5. how neural interventions alter experience;
6. how symmetric, nested, or overlapping candidates are handled.

These are positive construction requirements. They are not interchangeable with reporting that integration and consciousness correlate.

## 12. A constructive model of restricted access

A local perspective can be treated, initially, as restricted access to a more extensive organization. That alone does not produce phenomenality, but it can explain an informational asymmetry without an external observer.

A precise quantum illustration is useful.

Take:

\[
|\Phi^+\rangle=(|00\rangle+|11\rangle)/\sqrt{2},
\]

and compare its density matrix with the maximally mixed joint state:

\[
\rho_{\mathrm{mix}}=I_4/4.
\]

Both give the same individual subsystem states:

\[
\rho_A=\rho_B=I_2/2.
\]

Nevertheless, their joint structures differ:

| Quantity | Bell state | Maximally mixed joint state |
|---|---:|---:|
| Individual A state | I₂/2 | I₂/2 |
| Individual B state | I₂/2 | I₂/2 |
| Joint purity Tr(ρ²) | 1 | 1/4 |
| Correlation ⟨Z⊗Z⟩ | 1 | 0 |

The calculation uses exact rational density-matrix entries; it has been run, not just proposed.

**What it establishes:** within ordinary finite-dimensional quantum mechanics, the same individual marginals can belong to different joint states. A whole can have a definite joint description not recoverable from either individual subsystem state.

**What it does not establish:** that the universe is pure, that subjects are subsystems of a cosmic subject, that entanglement is phenomenal unity, or that informational restriction constitutes first-person awareness.

Do not confuse this with a denial of quantum local tomography: product-measurement **joint correlations** contain information not supplied by the two individual marginal states alone.

## 13. Objectivity as a compatibility-and-reconstruction problem

Let each perspective provide data Dₛ, and let rₛ restrict a candidate whole ω to what that perspective accesses. The compatible wholes are:

\[
\mathcal K=\{\omega:r_s(\omega)=D_s\text{ for every }s\}.
\]

Three cases matter:

- **No compatible whole:** the data, representation, or compatibility assumptions need revision.
- **Exactly one whole up to the relevant equivalence:** reconstruction succeeds.
- **Several inequivalent wholes:** the data underdetermine the whole; further constraints or observations are needed.

This supplies a constructive route from situated access to public objectivity: identify compatibility conditions, add cross-perspective correlations, and establish uniqueness where possible.

It does not assume that actual reality is indeterminate merely because observations underdetermine it. Nor does agreement alone force a unique common-world reconstruction. The Bell/mixed-state example demonstrates the latter limitation for a simple data choice.

---

# Pass IV — Build physical bridges rather than invoke “coherence”

## 14. Conditional recovery of spacetime geometry

A relational approach becomes explanatory only when it specifies which relations recover which geometry.

For suitable past- and future-distinguishing Lorentzian spacetimes of dimension greater than two, the chronological structure determines the metric up to a conformal factor. This is the reconstruction result discussed in Surya's review of causal-set theory; the causal assumptions and continuum setting matter. See the [review](https://link.springer.com/article/10.1007/s41114-019-0023-1).

Write a representative of the conformal class as ḡ. Then:

\[
g=\Omega^2\bar g,\qquad \Omega>0.
\]

In spacetime dimension d, the volume element transforms as:

\[
dV_g=\Omega^d\,dV_{\bar g}.
\]

If an appropriate positive smooth volume measure μ is additionally specified, the conformal factor is fixed:

\[
\Omega=\left(\frac{d\mu}{dV_{\bar g}}\right)^{1/d}.
\]

Thus:

\[
\boxed{\text{chronological structure + volume}\ \Longrightarrow\ \text{metric geometry, under the stated assumptions}.}
\]

### Why this is more than a coordinate trick

If we choose another conformal representative ḡ′ = f²ḡ, its volume element is multiplied by fᵈ. The formula gives Ω′ = Ω/f. Therefore:

\[
(\Omega')^2\bar g'=\Omega^2\bar g=g.
\]

The recovered metric does not depend on the arbitrary conformal representative. The physically meaningful uniqueness is understood with the appropriate diffeomorphism equivalence.

### What remains before this is an origin of spacetime

We still need an account of:

- why the relevant order and volume structure obtains;
- why there is a suitable continuum approximation;
- the relevant dimension and causal conditions;
- gravitational dynamics and matter;
- quantum compatibility;
- any relevant global assumptions and scales.

An arbitrary partial order does not automatically approximate a relativistic spacetime. Most causal sets are not manifold-like, and continuum-uniqueness issues remain in the causal-set programme. The reviewed reconstruction is not a derivation of Einstein's equations from totality or intelligibility.

**Actual gain:** metric structure need not be an independent unexplained addition if an appropriate order and measure are already justified. A real explanatory dependency has replaced a verbal claim about relational stability.

## 15. Quantum theory: a conditional uniqueness programme

A useful model of successful theoretical elevation is the finite-dimensional operational reconstruction by Chiribella, D'Ariano, and Perinotti.

Its assumptions include:

1. causality;
2. perfect distinguishability;
3. ideal compression;
4. local distinguishability;
5. pure conditioning;
6. purification, with the appropriate uniqueness condition.

The first five are satisfied by both classical and quantum theory in the reconstruction's setting. Purification is the discriminating extra postulate. The derivation is conditional on these substantive operational premises, not on the bare fact that reality is consistent or has no external host. See the [primary paper](https://arxiv.org/abs/1011.6451) and the [APS explanatory article](https://physics.aps.org/articles/v4/55).

In the familiar quantum formalism, purification has the form:

\[
\rho_A=\operatorname{Tr}_B|\Psi_{AB}\rangle\langle\Psi_{AB}|,
\]

with an appropriate uniqueness up to reversible transformations of the purifying system.

This tells our project exactly where a useful next derivation would have to land: establish why the underlying constitution satisfies those operational constraints, or find another justified route to quantum structure.

### Do not infer purification from cosmic closure

“Nothing is outside all reality” is an inclusion claim. “Every mixed state can be represented as a marginal of a pure state with the specified uniqueness” is a structural claim. The first does not entail the second.

Likewise:

- pure does not mean every measurement has a predetermined outcome;
- a mathematical purification is not automatically an additional actual physical system;
- a closed universe need not be globally pure by definition;
- operationally reconstructed quantum mechanics does not by itself solve measurement, select a cosmology, or establish phenomenal constitution.

## 16. Connecting the physical bridges

A provisional derivation graph is:

```text
justified concrete constitution
    |
    +--> justified operational constraints --> quantum structure
    |
    +--> justified order + volume + continuum conditions --> metric geometry
    |
    +--> justified unity/quality constitution --> experiential episodes
    |
    +--> internal causal organization --> computation and representation
```

The first arrows are not currently proved. Neither are the compatibility conditions joining the quantum and spacetime branches. Their placement makes the missing work visible rather than distributing it among impressive terms.

A completed physical branch would also have to recover or improve on relativistic quantum field theory, observed interactions, masses and couplings, cosmological data, and gravitational phenomena. The current reconstruction does not derive the Standard Model or its parameters.

We should nevertheless retain the demonstrated bridges. A future foundation need not reinvent every successful conditional result; it must justify their premises and their joint application.

---

# Pass V — Attack the foundations directly

## 17. The most promising explanatory form: constitutive rationalism

For the whole, an earlier external cause is not the only explanatory option. A constitutive explanation might say that substantive facts follow from what the fundamental reality is.

Dasgupta's *Metaphysical Rationalism* develops a relevant distinction:

- a fact can be apt for grounding and grounded;
- apt for grounding but brute;
- or allegedly not apt for further grounding—an autonomous fact.

His proposed rationalist principle is that every substantive fact has an autonomous ground. Real definitions or essences are the main candidates for autonomy. Importantly, the paper does not prove this principle true, and it treats autonomy as a primitive clarified through analogies. See [the paper, especially §3](https://shamik.net/papers/dasgupta%20metaphysical%20rationalism.pdf).

This is a serious route to investigate because it distinguishes an intelligible endpoint from a randomly selected first fact. But that distinction is not yet secured merely by invoking it. Oberle's discussion presses the need for a principled, nonarbitrary demarcation of facts allegedly exempt from explanation. See [Metaphysical Foundationalism and the Principle of Sufficient Reason](https://www.cambridge.org/core/journals/dialogue-canadian-philosophical-review-revue-canadienne-de-philosophie/article/metaphysical-foundationalism-and-the-principle-of-sufficient-reason/7E67DFE251072B0B97BAB6E20CC0D0B2).

### Admission conditions for a proposed essential endpoint

For this project, an alleged autonomous foundation must pass demanding tests:

1. **Not merely stipulative:** it characterizes reality, not just our chosen term.
2. **No concealed selection:** it does not insert a particular law, quantity, quality, or world under an unrestricted label such as “the nature of reality.”
3. **Clear explanatory type:** the alleged inapplicability of a further question is demonstrated, not asserted.
4. **Existential accountability:** if the essence is conditional on instantiation, the account recognizes that rather than inferring actuality from it.
5. **Independent leverage:** the account derives constraints or consequences not already copied into its definition.

These conditions are a research discipline, not a theorem that any proposed endpoint can satisfy them.

## 18. Essence does not automatically establish instantiation

Consider a characterization:

\[
\forall x\,(R(x)\rightarrow\Phi(x)).
\]

It says that everything of kind R has the relevant nature Φ. It is compatible with there being no R at all. Existential import must come from somewhere else:

\[
\exists x\,R(x).
\]

Real-essentialist theories may make stronger claims than the displayed conditional. The point is not that all essence must reduce to this formula. It is that a derivation must show where actual existence enters; it cannot move from a conditional nature to instantiation unnoticed.

Adding “necessarily existing” to a definition does not independently establish that anything answers to it. To succeed, a proposed necessary being or necessary constitution needs an argument for the relevant metaphysical possibility/actuality and modal inference, not just an internally consistent description.

### The useful correction: existence need not be a separate activation process

We should distinguish:

- a supposed mechanism that turns an abstract possibility “on”;
- the truth that something actually exists;
- an explanation of why that existential truth obtains.

The first need not be a genuine additional mechanism. Actual reality need not have a second actuality-making engine. But eliminating that engine does not explain the existential truth.

Likewise, saying that existence is not an extra ordinary property does not entail that any specified thing exists necessarily. The difference between no instance and an instance remains an existential difference even if it is not an extra colour-like attribute.

This relocates the foundation problem correctly. We seek an account of existential truth, not necessarily a pre-cosmic switch.

## 19. Why familiar routes do not yet cross the existence gap

### A. Present experience is undeniable

This establishes an actual occurrence in the present epistemic situation. It does not show that every metaphysically possible reality includes such an occurrence.

A world without concrete experiencers does not refute itself by containing a thinker denying experience; by hypothesis it contains no such thinker. Our describing it is not an inhabitant of that world.

### B. Absolute nothingness cannot be described without truths

Even if necessary abstract or logical truths cannot be absent, that does not yet establish concrete activity, matter, or phenomenality. “No concrete things” is a sharper challenge than “no truths of any kind.”

A bridge from necessary truth to concrete realization must still be argued.

### C. Reality is the totality

That fixes the scope of “reality.” It does not show that the scope must contain concrete members. Nor does uniqueness of the total inventory imply a uniquely possible inventory.

### D. Reality is self-consistent or a fixed point

A consistency condition can have no solutions, one solution, or many. A fixed-point equation can require substantial existence assumptions. A mathematical solution is not, without further argument, concrete instantiation.

### E. Self-presentation includes actuality

Actual self-presentation is indeed factive: if an experience is occurring, it is actual. But a description of possible self-presentation does not thereby self-present. A proposed self-instantiating essence must explain this passage rather than include it in the label.

These failures do not prove that an existence explanation is impossible. They identify the bridge an improved argument must genuinely supply.

### F. A direct constructive attempt: ground the possibility of concrete reality

Rather than stop with those failures, consider a stronger candidate argument.

Let **A** mean *some concrete actuality exists*. Propose the following principle:

> **GP — Concrete grounding of possibility:** at any possible world, the possibility of concrete actuality requires some concrete actuality there to ground that possibility.

A proposed rationale is that possibilities are not free-floating entities: modal truths should have a basis in what is actual. But that rationale is incomplete unless it shows why necessary abstract natures, or a broader modal structure, could not ground the relevant possibility. GP is therefore a substantive hypothesis, not an axiom of logic and not an established consequence of the PSR.

GP entails:

\[
\Box(\Diamond A\rightarrow A).
\]

Assume metaphysical modality satisfies S5 and A is actually true. Symmetric accessibility is already sufficient for the particular step used here; S5 is a stronger sufficient framework. Then A is possible from every world in the relevant accessibility class: □◇A. Applying GP at each world yields:

\[
\boxed{A+\mathrm{S5}+\mathrm{GP}\ \Longrightarrow\ \Box A.}
\]

**Proof in words:** any world accessible from this actual concrete world can, under S5, access it back. Concrete actuality is therefore possible from that world. If GP holds there, that world must itself include concrete actuality. Hence no accessible world is concretely empty.

This is a real conditional route to necessary nonemptiness. Its inferential step is valid; the exact two-world check agrees. Unlike a bare definition of necessary existence, it displays a proposed explanatory bridge that can be assessed.

**Countermodel to its being logic alone:** take an S5 frame with two mutually accessible worlds, one concrete and one concretely empty. A is true in the first and false in the second; ◇A is true in both. Nothing in S5 forbids this. GP is precisely what rejects the empty world. The frame is a formal countermodel, not a demonstration that the empty world is metaphysically possible.

**Strength check:** given actual A and S5, the existential instance of GP is equivalent to □A: necessary A also entails □(◇A → A). Consequently the conditional result is not new independent evidence for necessity. Its value is to isolate a proposed metaphysical rationale—concrete grounding of modal possibility—that must be defended on grounds other than the desired conclusion. This is a disciplined reformulation and a candidate argument, not a deduction from already established weaker premises.

**Where the work now lies:** justify GP without equating metaphysical possibility with ordinary causal potential. A world can lack the internal causal power to produce something while that thing is metaphysically possible. Nor may we dismiss abstract/modal grounds merely because our preferred ontology is concrete. The relevant modal accessibility assumptions also need defense rather than assumption.

**Limit even if it succeeds:** □A would establish necessary concrete nonemptiness, not a uniquely necessary universe, a particular necessarily existing individual, necessary consciousness, or any physical law. In particular:

\[
\Box\exists x\,C(x)\ \not\Rightarrow\ \exists x\,\Box C(x)
\]

without further premises: two worlds can each have concrete occupants but have no concrete occupant in common. The companion check includes that simple example.

**Research verdict:** GP is admitted as a precise lead for the existential bridge, not accepted as proven. It advances the search from an unstructured demand for self-existence to a specific disputed dependence claim. A fully intelligible account must still justify that dependence, or find a better bridge.

## 20. The modal constraint: what follows from necessary complete grounds?

Let E be a complete explanatory ground of fact p. If:

\[
\Box E
\]

and:

\[
\Box(E\rightarrow p),
\]

then:

\[
\Box p.
\]

This follows by the distribution principle of normal modal logic. It does not require S5. The small two-world exhaustive check also finds no counterexample to this conditional; the general justification is the modal inference, not the finite enumeration.

If every fact has a ground of this kind, all those facts are necessary. That is the relevant route to necessitarianism.

### What the result does not say

- An ordinary causal explanation is not automatically necessitating.
- A general PSR does not automatically contain the two premises.
- A necessary probabilistic law is not automatically a necessary token outcome.
- Deterministic dynamics with contingent initial conditions is not necessitarianism.
- A necessary foundation that merely allows p does not entail □p.

The exact check includes a countermodel to the shortcut that omits the necessity of E: E and p are true at one world and false at the other, while E → p holds at both. Necessary implication plus actual E is insufficient for necessary p.

## 21. Which notion of complete explanation are we pursuing?

There is a substantive philosophical choice here.

**Nonnecessitating explanation:** a law or ground can adequately explain why p occurs even though the same ground permits not-p. Proponents need not regard the permitted alternative as an explanatory defect.

**Strong contrastive closure:** if all explanatory facts remain exactly the same while either p or not-p can obtain, a further question remains about the difference between these actualities.

The second standard is the demanding target retained in this project. It is not presented as a theorem about every legitimate use of the word *explanation*. A probabilistic explanation may be excellent science without answering this stronger contrastive question.

If we retain that target, we should not close the ledger by saying “the law assigns probability 1/2” when the outstanding question is why this token outcome rather than the other.

Possible ways forward include:

- show that the putative token contrast is not fundamental;
- provide a necessitating constitution of the actual totality;
- justify a plenitude in which appropriately indexed alternatives are actual;
- or demonstrate why the further contrastive demand is genuinely inapplicable.

None can be asserted just to protect the ambition from difficulty.

## 22. The main candidate branches

| Branch | Proposed source of closure | What it still owes |
|---|---|---|
| **Necessary determinate constitution** | Reality's actual nature could not have been absent or different | Justified necessary existence; derivation of its specific structure and phenomenal facts |
| **Principled plenitude** | All appropriately admissible realizations obtain; no unique-world selector | Why admissibility entails actuality; how realizations are individuated; measure and self-location |
| **Necessary generative law with genuine contingency** | Every occurrence follows an adequate nonnecessitating explanation | Why the token contrast is not an outstanding residue under the demanding target |
| **Nonfoundational explanatory network** | No brute first item; facts are intelligible through a complete dependence structure | Why the network and its actual realization obtain; why dependence is explanatory rather than merely circular |

Autonomous essence is a possible explanatory strategy within more than one branch, not an automatic fifth world-making mechanism.

### Working priority

Investigate **necessary determinate constitution first**, while keeping principled plenitude as a live rival. This is a search priority, not evidence that a unique necessary reality has been established.

The reason is strategic: it directly addresses both existential absence and arbitrary selection without beginning by multiplying actual worlds and then adding a measure problem. If the required necessity cannot be justified, that failure should redirect the project rather than be concealed.

## 23. What symmetry can—and cannot—do for plenitude

A useful conditional theorem is available.

Let a group G act transitively on a space A of candidates. Suppose a selection B ⊆ A is invariant under G. Then:

\[
B=\varnothing\quad\text{or}\quad B=A.
\]

**Proof:** if b is selected and a is any candidate, transitivity supplies a symmetry sending b to a. Invariance therefore selects a. Hence any nonempty invariant selection is all of A.

This is a real result. Its metaphysical application requires much more:

1. A must be the right candidate space.
2. The candidates must really be related by relevant symmetries; our ignorance of differences is not enough.
3. Selection must preserve those symmetries.
4. A nonempty actuality must already be justified.
5. The candidates must be jointly actualizable in the proposed sense.

Mutually exclusive values of one variable cannot simply all hold at once. A plenitude normally needs distinct world or branch indices, and the constitution of those indexed realizations is an additional claim.

Thus “no arbitrary preferred candidate” does not by itself prove “all mathematical worlds are concretely actual.” Symmetry can constrain a selection rule; it does not create actuality.

### Measure does not come free with “all”

For a countably infinite candidate set, there is no normalized countably additive distribution assigning the same probability c to every singleton: c = 0 gives total 0, while c > 0 gives an unbounded sum.

This rules out one simple uniform-measure proposal. It does not rule out all measures or settle uncountable cases. Any useful plenitude theory still needs a justified probability or typicality framework and an account of indexical location.

## 24. Can the explanatory framework explain itself?

An account of all reality must include the existence and reliability of the finite reasoners using it. That is not the same demand as requiring a logically prior theory that validates every inferential resource without using any inferential resources.

Three levels should be separated:

1. **Ontic inclusion:** our reasoning episodes and representations belong to reality.
2. **Epistemic warrant:** evidence and argument justify particular conclusions, with fallibility made explicit.
3. **Metalogical assessment:** one can analyze the soundness and scope of a system using a stated metatheory.

Moving to a metatheory does not produce a viewpoint outside reality. Nor does it automatically yield presuppositionless certainty. The goal should be to show that the explanatory commitments are warranted and nonarbitrary, not to claim that a sentence can certify all of its own semantic and modal assumptions.

This does not settle the ultimate status of logic, mathematics, or normativity. It prevents their absence from a finished physical model being hidden behind the phrase “the universe explains itself.” No Gödel-based impossibility theorem is being claimed here.

---

# Pass VI — Consolidate the actual progress and set the next proof obligations

## 25. What changed across the constructive passes?

| Stage | Candidate or shortcut | Test or development | Revised result |
|---|---|---|---|
| Starting proposal | Reality is a self-running self-simulation | Separate description, implementation, actuality, and subjecthood | Retain immanence; remove unnecessary universal computation and external executor |
| Constitutive proposal | One constitution unifies physical and phenomenal facts | Ask whether the aspect maps are derived or simply assigned | Keep one-constitution architecture; expose Π, Σ, Q as construction obligations |
| Subject proposal | Maximal integration uniquely selects the subject | Exact symmetric overlapping-candidate check | Unique selection needs adequate structure/tie handling; no automatic cosmic subject |
| Perspective proposal | Local perspectives fix the common whole | Exact Bell-versus-mixed density-matrix calculation | Local marginals do not suffice; correlations and uniqueness conditions are needed |
| Relational physics | Causal relations yield spacetime | Supply conformal-plus-volume derivation | Genuine conditional metric recovery; dynamics and continuum assumptions remain |
| Coherence-to-quantum proposal | Closure itself entails quantum purity | Compare with operational reconstruction premises | Keep reconstruction as a target; do not infer purification from totality |
| Ultimate explanation | A necessary ground makes everything necessary | Separate ground necessity from necessitating linkage | Precise modal theorem; ordinary PSR is not silently strengthened |
| Essential endpoint | Reality follows from its definition | Separate nature from instantiation | Existence is now the explicit central bridge, not an assumed premise hidden in “self-grounding” |
| Direct existence argument | Possibility requires an actual concrete ground | Derive necessary nonemptiness conditionally; construct a formal countermodel without GP | A valid route is isolated, but its grounding principle and modal application remain unproved |

This is more than another critique: the dependency structure is clearer, some bridge mathematics is supplied, implementation gets a concrete necessary condition, and the remaining foundational search has a defined target. It is also less than absolute closure.

## 26. Claim and residue ledger

Status labels: **D** = datum or definitional scope; **T** = proved conditional; **L** = established conditional result in cited literature; **H** = working hypothesis; **O** = open obligation.

| Claim | Status | What would elevate it |
|---|---|---|
| An experience/seeming is actual in the present epistemic situation | D | Does not itself establish universal or necessary experience |
| Any actual external simulator belongs to total reality | D | No further ontological consequence follows just from inclusion |
| Necessary E plus necessary E → p entails necessary p | T | Justify that proposed foundations actually satisfy the premises |
| Actual A plus S5 and GP entails necessary concrete nonemptiness | T | Independently justify GP and the relevant modal assumptions; no uniqueness follows yet |
| An invariant selector cannot uniquely pick between symmetry-exchanged candidates | T | Determine the relevant real symmetries and additional subject rules |
| Appropriate equivalence relation yields a unique episode partition | T | Derive and justify the relation and its equivalence properties |
| Same one-part marginals can accompany different joint quantum states | T | Use adequate joint information when reconstructing a whole |
| Chronological order plus volume fixes suitable continuum metric geometry | L + explicit derivation | Derive its premises and connect them to quantum gravity |
| Suitable operational axioms reconstruct finite-dimensional quantum theory | L | Explain why those axioms characterize actual reality |
| Physical and phenomenal facts belong to one concrete constitution | H | A defended constitution/identity account, not just correlated descriptions |
| Intrinsic qualitative-relational constitution is the best completion | H | Independent arguments and successful specific derivations |
| Subject boundaries and qualities follow from that constitution | O | A precise, noncircular bridge with empirical and conceptual adequacy |
| The constitution exists necessarily | O | An existential/modal argument, not a definition or present-tense datum |
| This exact law/state structure is uniquely necessary | O | Derive it without inserting the target structure in the premises |
| A plenitude avoids all arbitrary selection | O | Derive coactuality, admissibility, measure, and self-location |
| Logic, mathematical truth, meaning, and any genuine normativity are integrated | O | Account for their status without confusing representation with ontology |
| Absolute zero residue is achieved | O | Close all genuine obligations above and any further ones exposed by the construction |

No percentage of completion is assigned. There is no justified metric under which several solved toy cases amount to, say, “80% of ultimate reality.”

## 27. The next research sequence

### Step 1 — The existential bridge

Take the GP argument in §19F as one explicit lead. Investigate whether possibility really requires concrete grounding, whether abstract/modal grounds suffice, and whether the relevant modal accessibility assumptions hold. Compare rival existential arguments with an equally explicit chain from premises to conclusion. Test them against a model with necessary abstract truths but no concrete instances.

**Success condition:** the model is excluded for a reason supplied by the argument, not by defining “possible” as “already actual.”

**Failure condition:** the argument proves only that something exists now, that truths cannot all be false, or that an instantiated thing has a certain essence.

### Step 2 — The nonarbitrary nature of the foundation

If necessary actuality is established, determine whether its nature is unique, underdetermined, or necessarily plural. Test every proposed identifying feature for concealed factual input.

**Success condition:** a genuine restriction on possible constitutions, ideally a uniqueness result up to nonphysical redescription.

**Failure condition:** “the necessary nature is exactly the observed universe” introduced as an essence with no independent argument.

### Step 3 — Phenomenal constitution and subjecthood

Develop a precise account of Π, Σ, and Q. Use symmetry, overlapping-candidate, unconscious-processing, and neural-intervention cases as tests. Keep episode unity separate from personal persistence and reportability.

**Success condition:** explain qualitative and subject facts from a defended constitutive base, not just predict verbal reports or add arbitrary labels.

### Step 4 — Physical reconstruction and compatibility

Derive substantive operational constraints, recover quantum structure, recover suitable causal/volume geometry, and establish the compatibility of these branches. Then pursue dynamics, matter content, constants, and cosmology.

**Success condition:** detailed mathematical and empirical recovery, not a resemblance between philosophical vocabulary and physical terminology.

### Step 5 — Eliminate or explain selection residue

If multiple histories or worlds remain admissible, test necessary realization, justified coactuality, or an argued limit on the contrastive demand. A named probability distribution is not an explanation of its own selection or authority.

### Step 6 — Reflective closure

Account for the representation, evidence, inference, and any genuine normative commitments used in the construction. Identify which explanatory questions were answered and which were legitimately dissolved.

These steps need not be strictly sequential. Phenomenal constitution and physical recovery can constrain a proposed foundation while its necessity is investigated. The ordering identifies logical dependencies rather than prescribing that physics wait for a completed metaphysics.

## 28. The consolidated thesis, at the strength currently warranted

> A promising route to ultimate intelligibility is an immanent, constitutive account: reality is not an abstract program awaiting external execution; its public physical structure and actual experience must belong to the same complete concrete account; local subjects, when present, must be constituted rather than assumed to be either independent substances or fragments of an unproved cosmic mind. Some of the required bridges admit precise conditional reconstruction. The decisive unfinished task is to justify actual existence and the specific nature of the constitution without an arbitrary selection, a merely stipulated essence, or a redefinition of explanation.

The goal remains **fully intelligible, zero-residue reality**. The present result is an improved candidate and a set of earned constraints—not a declaration that the goal has been met, and not an argument that it cannot be met.

---

# Appendix A — Reproducible checks actually run

Companion script: `zero_residue_research/checks.py`  
Exact output: `zero_residue_research/check_results.json`  
Run: `python zero_residue_research/checks.py`  
Dependencies: Python 3 standard library only.

The script checks:

1. **Two-world modal valuations:** 16 assignments; no counterexample to □E ∧ □(E → p) ⇒ □p. Dropping □E produces the counterexample E = (true, false), p = (true, false).
2. **Symmetric overlapping candidates:** swapping 0 and 2 exchanges {0,1} and {1,2}; the only invariant selections are neither or both, not a unique singleton selection.
3. **Quantum joint-state example:** equal individual marginals, but exact global purities 1 and 1/4 and Z⊗Z expectations 1 and 0.
4. **Toy qualitative definability:** in a swap-symmetric two-state structure, an oriented singleton label is not invariantly definable from that base alone. This is not a theorem that real phenomenal qualities cannot be physically or structurally constituted; a richer base can remove the symmetry.
5. **Direct existence route:** the two-world S5 valuations verify the conditional A + GP ⇒ □A, and show that the concrete/empty-world model violates GP rather than modal logic. A second example has different concrete occupants in each world, distinguishing necessary nonemptiness from a necessarily concrete individual.

Finite checks illustrate particular models. They do not establish metaphysical possibility, actual subjecthood, the truth of a PSR, or universal ontological closure. The general modal and symmetry results have arguments in the main text independent of the enumeration.

# Appendix B — Source use and boundaries

The notebook uses sources as specific resources, not authorities for an already completed synthesis.

- **Dasgupta, _Metaphysical Rationalism_ (2016).** The opening and autonomy discussion were consulted. The paper supplies a developed constitutive-rationalist option, not a demonstration of PSR or our proposed foundation.
- **Oberle, _Metaphysical Foundationalism and the Principle of Sufficient Reason_ (online 2023).** Used for the demand that any restriction of the PSR have a principled, nonarbitrary demarcation. The entire article has not been reviewed here.
- **Chalmers, _Does a Rock Implement Every Finite-State Automaton?_ (1996), _The Varieties of Computation: A Reply_, and SEP on physical computation.** Used for implementation constraints and their limitations, not to infer computational consciousness or universal pancomputationalism.
- **Surya, _The causal set approach to quantum gravity_ (2019).** Relevant reconstruction discussion consulted; used for conditional conformal/volume reconstruction and warnings about manifold-likeness. Not presented as a finished quantum-gravity theory.
- **Chiribella, D'Ariano, and Perinotti, _Informational derivation of quantum theory_ (2011), with Brukner's APS explanation.** Used as an example of substantive conditional reconstruction. Its full proof has not been independently rederived here.
- **Albantakis et al., IIT 4.0 (2023), and COGITATE (2025).** Used to identify a developed subject-constitution proposal and current empirical constraints. IIT's complete S1 tie-resolution supplement was also consulted, and the discussion was refined accordingly. Neither theory is treated as settled. The empirical claim was checked against the published abstract, not a reanalysis of experimental data.

The originality claimed here is the organization, conditional arguments, exact checks, and proposed research architecture—not the discovery of the cited reconstruction theorems or a solution to the foundations they leave open.
