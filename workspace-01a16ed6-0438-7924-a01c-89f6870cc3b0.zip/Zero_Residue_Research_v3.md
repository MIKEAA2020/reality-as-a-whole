# Toward zero residue — constructive round 3
## Episode identity, causal boundary tests, and qualitative geometry

**24 October 2026**  
**Continues:** [Round 2](./Zero_Residue_Research_v2.md).  
**Status:** a proposed phenomenal constitution, explicit tests of one operational version, a repaired invariance condition, and a conditional quality-space derivation. **Not a completed theory of consciousness or necessary existence.**

## The advance attempted

The previous rounds constructed physical subproblems while leaving the phenomenal bridge unspecified. This round attempts an actual bridge proposal:

> A minimal experiencing subject is not a further observer inspecting a process. It is the phenomenal unity of an intrinsically presented concrete episode. The episode's public causal organization and its intrinsic phenomenal character belong to the same occurrence.

Call this the **episode–process identity proposal**, within the existing immanent constitutive programme. It is a hypothesis to develop, not something established by the words “intrinsic” or “identity.”

This round does three things beyond stating that hypothesis:

1. Builds and runs a concrete causal boundary selector, including common-cause and coordinate controls.
2. Finds and proves a limitation that prevents its simplest scalar rule from determining subjects adequately; repairs the coordinate issue without inventing a phenomenal tie rule.
3. Derives a possible geometry of qualitative distinguishability from response probabilities, while separating the derived geometry from the unproved claim that it is phenomenal geometry.

A further model-theoretic result makes the remaining actuality requirement explicit: a theory neutral about concrete instantiation cannot exclude an empty-concrete expansion merely by having a unique abstract model.

---

# 1. A candidate phenomenal constitution, with its assumptions exposed

## 1.1 The working commitments

**E0 — Actual experience:** some phenomenal occurrence obtains. This remains a datum, not a proof of necessary or universal experience.

**H1 — Episode identity:** a minimal subject of an episode is the unity of that episode, rather than a second substance or inner observer that separately witnesses it.

**H2 — One-occurrence constitution:** where an experiential episode occurs, its public causal organization and intrinsic phenomenal character belong to one concrete occurrence. If this identity is true, an additional interaction law between independently existing mental and physical substances is unnecessary.

**H3 — Organization matters:** episode boundaries and qualities are not arbitrary decorations on a causal skeleton. The full actual organization, state, temporal structure, and physically meaningful interventions must constrain the proposed phenomenal constitution.

**H4 — Qualitative structure:** at least some relations among experienced qualities may be explained by a mathematically constrained geometry of the constitutive process's differentiations. Section 6 develops one precise hypothesis of this kind.

Only E0 is being used as an experiential starting point. H1–H4 require arguments and testing. H2 is not established by causal correlation, and H3 is not established by producing any integration score.

## 1.2 What this could simplify

If justified, H1 avoids a homuncular addition: the episode need not be displayed to another miniature experiencer, who would then need another experiencer, and so on. H2 avoids an extra two-substance interaction mechanism.

But these are **conditional simplifications**, not a derivation of phenomenal occurrence. Saying “the subject is the unity” does not explain why that unity obtains.

Nor does an episodic subject immediately explain a person's persistence, memories, agency, or identity across episodes. Relations of memory and causal continuity must not be confused with simultaneous phenomenal unity.

## 1.3 What we must not conceal in the word “quality”

Three questions are distinct:

- What intrinsic qualitative differences obtain?
- Which differences are experienced?
- Which experienced differences are jointly presented in one episode?

Positing qualities without microsubjects avoids *assuming* a subject-summing task. It does not automatically explain the existence of a macrosubject, macrophenomenal qualities, or their structure. This distinction is central in discussions of Russellian monism, panqualityism, and the combination problem. [1](https://plato.stanford.edu/entries/russellian-monism/) [8](https://consc.net/papers/combination.pdf)

Likewise, calling states jointly accessible does not establish that they are jointly experienced. Bayne and Chalmers explicitly distinguish access unity from phenomenal unity; their work does not prove the episode–process identity proposed here. [2](https://consc.net/papers/unity.html)

We will not prove a universal unity thesis simply by defining a “subject” as whatever is unified. Whether all experiences of a biological person belong to one episode remains a substantive question.

---

# 2. Make a causal boundary proposal precise enough to fail

To test H3 rather than leave it verbal, I constructed a deliberately simple interventional model.

**This is not an implementation of IIT 4.0, not an empirical consciousness measure, and not presented as a replacement for that developed theory.** Different proposed integrated-information measures have materially different properties; a result about this prototype is not a result about all of them. [1](https://doi.org/10.3390/e21010017)

## 2.1 The model's inputs

We assume:

- physically meaningful binary mechanism variables;
- a next-state transition kernel;
- conditionally independent next-node noise, given the complete current state and external context;
- a specified family of physical cut interventions;
- a uniform reference distribution over possible input states for this benchmark.

The reference distribution is an analysis choice, not a derived cosmic probability measure. The meaningful variables and interventions are additional physical structure, not arbitrary coordinate names.

For a candidate set S, partition it into nonempty A and B. A cut A → B replaces the A inputs reaching each B mechanism with fresh independent uniform inputs. Other inputs, including external context, are fixed before the cut effect is calculated.

Let the mean effect of the cut be:

\[
D_{A\to B}=\mathbb E_{x\sim\mu}
D_{\rm KL}\left(T_S(\cdot\mid x)\;\Vert\;
T^{\rm cut(A\to B)}_S(\cdot\mid x)\right).
\]

The external contexts are averaged only *after* their conditional cut effects are evaluated. We do not mistake unconditional shared-input correlation for within-system influence.

Define bidirectional cut resistance:

\[
I(S)=\min_{A\mid B}\min\{D_{A\to B},D_{B\to A}\}.
\]

Thus a purely one-way connection cannot by itself give positive bidirectional resistance. The score uses base-2 logarithms and is measured in bits.

Single-component subjecthood is not decided by this test: I is defined here only for sets with at least two mechanism variables. Treating the absence of a possible bipartition as proof of absent experience would add another unsupported assumption.

## 2.2 A strong operational version to test

A simple prototype boundary rule is:

> A candidate set is selected if its positive I score is strictly greater than that of every other overlapping candidate.

A strong phenomenal completion would then say that an actually realized selected process is self-presenting, and that its full actual state and organization have the episode's qualitative character.

**That phenomenal completion is an added identity postulate. It does not follow from the cut-score definition.** The operational tests below examine the selection mechanism, not whether a device experiences.

## 2.3 Controls actually run

| Process | Observational or causal feature | I score |
|---|---|---:|
| Two independent copy mechanisms | No cross-influence | 0 |
| One-way copying | One direction influences the other | 0 |
| Two mutually swapping bits | Each influences the other | 1 bit |
| Two outputs copying one external driver | Outputs share 1 bit observationally, but do not influence one another | 0 |

These controls are useful. The criterion distinguishes mutual influence from correlation and from one-way transmission.

They do not establish that a swapping two-bit mechanism is conscious. If the strong phenomenal postulate assigns it minimal experience, that is a substantive panexperientialist commitment requiring defense—not a finding of the calculation.

---

# 3. Repair an apparent coordinate failure correctly

## 3.1 An exact recoding

Consider the swap dynamics:

\[
x'=y,\qquad y'=x.
\]

Define new coordinates:

\[
u=x\oplus y,\qquad v=y,
\]

where ⊕ is XOR. This transformation is bijective. In the new coordinates the same evolution is:

\[
u'=u,\qquad v'=u\oplus v.
\]

Now the coordinate dependency graph is one-way between u and v. If we impose fresh “local u/v” cut interventions, the prototype score changes from 1 to 0.

It would be incorrect to conclude immediately that physics itself changed, or that any causal account of consciousness is impossible.

## 3.2 What actually changed

The new independent coordinate-local interventions are not the same physical interventions as independently manipulating x and y. A global change of variables does not license replacing the physical intervention family with a different one.

When the original physical cuts are transported through the bijection, their outcome distributions transform together with the dynamics. KL divergence is invariant under the common bijection. The two original directional cut costs both remain exactly **1 bit**.

The script verifies the dynamical conjugacy and both transported costs.

Thus a repaired physical signature must contain at least:

\[
\boxed{\text{state space + dynamics + physical intervention structure},}
\]

not an unstructured transition table whose coordinates are arbitrarily declared mechanisms.

## 3.3 What is now closed, and what is not

**Closed conditionally:** this apparent coordinate inconsistency disappears when the complete physical structure is transformed consistently.

**Not closed:** why a particular mechanism/intervention structure is physically distinguished at the fundamental level. Round 2's observable-algebra construction identifies one target for that question. The present calculation does not derive that structure from a bare state space.

For a whole-reality account, “physical intervention” must ultimately concern real interaction possibilities inside reality—not an experimenter outside it choosing which ontology exists.

---

# 4. Test subject fusion instead of assuming maximality will handle it

## 4.1 The coupled-pair family

Take four binary mechanisms. Initially, 1 and 2 swap with each other, and 3 and 4 swap with each other.

Add cross-input modulation:

\[
X_i'=X_{p(i)}\oplus(B_i\land X_{q(i)}),
\]

where:

- p pairs 1 with 2 and 3 with 4;
- q pairs 1 with 3 and 2 with 4;
- the Bᵢ are independent Bernoulli variables with parameter ε.

**Here ε is a binary-channel modulation probability, not the diffusion-rate parameter used in round 2.** This is a new illustrative family, not a model of actual brain fusion.

All relevant subsets and bipartitions were evaluated. Holding external inputs fixed before averaging gives the following formulas, with h₂ the binary entropy:

\[
C(\varepsilon)=1-\frac12h_2(\varepsilon)
\]

for either original pair, and:

\[
W(\varepsilon)=h_2(\varepsilon/2)-\frac12h_2(\varepsilon)
\]

for either cross pair. For the whole:

\[
I(\{1,2,3,4\})=\min\{C(\varepsilon),2W(\varepsilon)\}.
\]

These formulas agree with direct enumeration of the transition kernels and cuts. They also have a direct derivation:

- Cutting a strong source makes the target output fair. Its original average conditional entropy is h₂(ε)/2, so the mean cost is C.
- Cutting a weak source gives a mean flip probability ε/2, hence a cost h₂(ε/2) − h₂(ε)/2 = W.
- A singleton-versus-rest partition has bidirectional minimum C. The original-pair partition cuts two weak inputs in each direction and has minimum 2W. Each other balanced partition has minimum 2C.

These exhaust the seven unordered whole-system bipartitions, giving min{C,2W}. Each three-node candidate has a weak-only leaf and score at most W; opposite unconnected pairs score zero. Thus the persistent tie is analytically supported, not inferred solely from a few sampled parameter values.

## 4.2 Results

| ε | Original-pair score | Whole score | Strict rule selects |
|---:|---:|---:|---|
| 0 | 1.000000 | 0 | The two original pairs |
| 0.10 | 0.765502 | 0.103798 | The two original pairs |
| 0.40 | 0.514525 | 0.472906 | The two original pairs |
| 0.45 | 0.503613 | 0.503613 | Nothing: overlapping ties |
| 0.50 | 0.500000 | 0.500000 | Nothing: overlapping ties |
| 0.75 | 0.594361 | 0.594361 | Nothing: overlapping ties |

The crossover occurs at approximately:

\[
\varepsilon_*=0.424632497.
\]

**This is a threshold in the invented scoring model, not a discovered consciousness threshold.**

Instead of yielding a uniquely determined fused subject, the scalar score develops persistent ties between the whole and its constituent pairs. One whole and two disjoint pairs are not the same answer under mere relabelling.

A theory could explicitly postulate that all experience disappears there. But the calculation supplies no independent reason for that phenomenal claim; it merely shows that strict scalar maximality returns no winner.

## 4.3 Why this is not merely a numerical accident

The score has a bottleneck ceiling in this class of models.

Choose a partition that isolates one binary target i, and consider the cut from the rest into i. Conditional independence makes the other output factors cancel in the KL ratio. Averaging over input states gives a conditional mutual information:

\[
D_{S\setminus\{i\}\to i}
=I(X_{S\setminus\{i\}};X_i'\mid X_i,\text{external context})
\le1\text{ bit}.
\]

Because our score takes the minimum across partitions and directions:

\[
\boxed{I(S)\le1\text{ bit}}
\]

for binary mechanism variables under the stated assumptions. More generally, the corresponding bound is the smallest target alphabet capacity.

A large organization can therefore hit the same bottleneck ceiling as a small pair. The one-number ranking need not encode the richer differences among their causal structures.

This is a limitation of **this** prototype. It is not a theorem about every integrated-information measure, every full causal structure, or IIT 4.0. The developed IIT account also has additional structural and tie-handling machinery, as checked in round 1.

## 4.4 The appropriate revision

I do not add “choose the biggest” or “choose the smallest” merely to preserve a preferred answer. Those are additional selection postulates requiring justification.

Instead, the operational procedure should return a **nondominated frontier** when tied overlapping structures remain. At ε = 0.5, that frontier contains the two original pairs and the whole.

This is a record of what the score has not decided—not a claim that all candidates are subjects, or that none is.

A nonexclusive theory could allow overlapping subjects, but would have to defend that phenomenal ontology and its consequences. An exclusive theory needs a principled constitutive distinction that the scalar lacks. Neither choice follows from maximality alone.

**Verdict:** the simple strict-score boundary rule is not accepted as an adequate derived subject criterion. Episode–process identity remains a research hypothesis; this attempted operational completion has not earned the required boundaries.

---

# 5. What phenomenal unity still requires

## 5.1 Capacity is not an actual phenomenal character

The prototype score averages across possible input states. It therefore gives the same capacity score to different actual states of the same mechanism.

For example, the swap system's states 00 and 01 have the same I score, although their actual next states and state histories differ. Whatever qualitative difference might exist between actual episodes cannot be recovered from that state-independent scalar alone.

This is not a general theorem that no scalar could encode any complex information. It is an explicit many-to-one property of this score.

A serious candidate would at least need a state- and temporally sensitive signature such as:

\[
\mathcal P_{S,\tau}
=(\text{realized process},\text{actual state/history},
\text{physical interventions},\text{temporal grain}).
\]

Even that richer signature is not automatically phenomenal. The identity between its intrinsic concrete nature and a presented episode remains to be justified.

## 5.2 Avoiding an inner observer is not explaining unity

The minimal-subject proposal can remove one unnecessary layer: a unified experience need not be sent to another observer to become an experience.

But it does not remove the following questions:

- Why is this occurrence experiential?
- Why are these contents jointly presented?
- Why is its boundary this one?
- Why does it have this qualitative character?

Calling the unity a “joint presentation” acknowledges the target; it does not construct it from independent grounds.

Similarly, starting with complete microscopic subjects would add a subject-summing task. Starting with one cosmic subject would add a subject-decomposition task. We have not established that either starting point is required.

## 5.3 Explanation is not experiential reproduction

A theory need not cause its reader to undergo every experience it explains. “Why am I not currently feeling your pain while reading its explanation?” can ask for a different occurrence, not an omitted explanatory fact.

That distinction does not dissolve the real qualitative question. If the account leaves unexplained **which phenomenal fact obtains**, or why the relevant process is experiential at all, that is not repaired by saying that explanations need not reproduce their objects.

Thus we should separate:

- a demand that the theory induce an experience in every reader;
- a demand that it account for the experience that actually occurs.

Only the second belongs to the present ontological target. This does not settle the broader knowledge-argument or phenomenal-concept debates.

---

# 6. A positive bridge: derive a geometry of differentiation

Boundary scoring is not the only place to work. Qualitative experience also has relational structure: similarities, differences, intensities, and discriminations. A candidate constitution should explain some of that structure instead of assigning every relation independently.

The following is a **standard information-geometric construction**, developed explicitly here. It derives statistical distinguishability, not consciousness.

## 6.1 From response probabilities to a local metric

Suppose a physically specified response process has probabilities:

\[
p_r(\theta),
\]

where θ describes variations of the relevant process or input.

Expanding KL divergence between nearby response distributions gives:

\[
D_{\rm KL}(p_\theta\Vert p_{\theta+d\theta})
=\frac12 F_{ab}(\theta)d\theta^a d\theta^b
+O(\|d\theta\|^3),
\]

where:

\[
F_{ab}=\sum_r p_r\,
\partial_a\log p_r\,\partial_b\log p_r.
\]

Thus statistical differentiation supplies the Fisher metric:

\[
ds^2=F_{ab}d\theta^a d\theta^b.
\]

These formulas use natural logarithms. Changing logarithm convention rescales the metric; it does not derive units of phenomenal intensity.

## 6.2 Why the quadratic geometry is not arbitrary within a broad class

For a smooth f-divergence:

\[
D_f(p,q)=\sum_r q_r f(p_r/q_r),
\]

with the usual local regularity, f(1) = 0, and nonzero f″(1), the second-order expansion is proportional to:

\[
\sum_r\frac{(dp_r)^2}{p_r}.
\]

A linear f′ term makes no contribution because probabilities normalize. Therefore many different smooth divergence choices produce the same local geometry up to a constant.

This is not a proof that *every imaginable metric* or *every phenomenal similarity relation* must be Fisher geometry. It is a conditional constraint within the stated statistical framework.

The script explicitly checks the second derivatives of forward and reverse Bernoulli KL. The general f-divergence statement follows by the Taylor expansion, not by that finite check alone.

## 6.3 Worked one-dimensional case

For a binary response with probability p ∈ (0,1):

\[
ds^2=\frac{dp^2}{p(1-p)}.
\]

The change of coordinate:

\[
u=2\arcsin\sqrt p
\]

gives:

\[
ds^2=du^2.
\]

So equal differences in raw probability need not be equal statistical distances in this metric. The distance along the Bernoulli family is:

\[
d(p,q)=2\left|\arcsin\sqrt p-\arcsin\sqrt q\right|.
\]

For p = 0.25 and q = 0.75:

\[
d=\pi/3\approx1.047198.
\]

## 6.4 A nontrivial prediction under added noise

Pass the binary response through a symmetric flip channel with probability η, where 0 ≤ η ≤ 1/2:

\[
r=\eta+(1-2\eta)p.
\]

The pulled-back response metric becomes:

\[
g_\eta(p)=\frac{(1-2\eta)^2}{r(1-r)}.
\]

Direct calculation gives:

\[
\frac1{p(1-p)}-g_\eta(p)
=\frac{\eta(1-\eta)}{p(1-p)r(1-r)}\ge0.
\]

Thus the noise contracts statistical distinguishability. For the same p and q above, with η = 0.2, the distance falls from approximately **1.047198** to **0.609385**. At η = 1/2 the channel is input-independent.

These are derived model properties, not measurements of experienced color or intensity.

## 6.5 The actual phenomenal hypothesis, separately stated

A testable candidate bridge is:

> **DM — Distinguishability matching:** for an already phenomenally unified episode, some local qualitative differences are governed by the Fisher geometry of its constitutive differentiation process.

If justified, DM would explain relational qualitative structure with fewer independently assigned distances. The geometry follows from probabilities rather than a new distance parameter for every pair of qualities.

But DM remains a hypothesis. The derivation does not tell us:

- which response process constitutes the experience;
- whether that process is experienced at all;
- whether qualitative difference and statistical discriminability coincide;
- why a particular quality is felt rather than merely represented.

A downstream report or motor channel need not be the constitutive presentation process. Conversely, one cannot rescue DM by changing the identified channel after every mismatch.

In particular, statistical contraction under noise need not mean that two actually experienced colors become more similar. If independently fixed constitutive channels and well-supported phenomenal judgments dissociate, that would challenge the simple bridge.

**Earned result:** a constrained mathematical geometry of differentiation and its transformation under noise.

**Unpaid bridge:** identification of that geometry with the relevant phenomenal relations.

---

# 7. Keep the actuality gap explicit: a neutral-extension result

The identity proposal must not be used to smuggle existence into its definitions. A simple model-theoretic observation supplies a useful guardrail.

## 7.1 The result

Let T be a theory in an abstract vocabulary L. Add a new predicate C meaning concrete instantiation, with no axioms linking C to the L structure.

For any model M of T, expand M by interpreting C as empty. All L sentences retain their truth values. Thus:

\[
T\not\models\exists x\,C(x).
\]

Even if the abstract structure is unique up to isomorphism, the empty-concrete expansion still satisfies the abstract theory.

This is not an impossibility theorem about metaphysical explanation. It applies to **concreteness-neutral theories**. A successful constitutive theory could reject the neutrality by supplying a justified identity or existential bridge.

The point is that such a bridge must do real work. Categoricity, mathematical consistency, self-reference, and fixed-point uniqueness cannot silently perform it.

## 7.2 Adding actual experience does not automatically yield necessity

A two-world illustration makes the remaining modal step clear.

Both models contain the same fixed abstract structure and a concrete occurrence in the actual world. In one, the other world has no concrete occurrence; in the second, it does.

| Feature | Expansion 1 | Expansion 2 |
|---|---|---|
| Abstract structure | Same | Same |
| Concrete occurrence at actual world | Yes | Yes |
| Concrete occurrence at other world | No | Yes |
| Necessary concrete nonemptiness | No | Yes |

The shared neutral theory plus the actual datum does not choose between them. They are formal expansions, not demonstrations that both worlds are metaphysically possible.

A necessary-existence argument must justify a restriction that excludes the first expansion. Round 2's backing/rooting route states one such explanatory architecture. The present episode identity does not independently justify that architecture.

## 7.3 “Self-presenting” cannot be merely a predicate name

One can add a predicate called SelfPresenting and an axiom saying that self-presenting things are concrete. That yields an existential conclusion only if something genuinely satisfies the relevant antecedent.

A representation of self-presentation does not thereby self-present. Naming an abstract property after experience is not a demonstration that it has phenomenal actuality.

A real essence or constitutive identity might supply the needed connection. But its justification, rather than the name, would be the explanatory achievement.

---

# 8. Refine the account and concentrate the remaining work

## 8.1 What survives the attempted construction

The lead proposal remains:

> Experience, where it occurs, is the intrinsic presentation of an actual concrete episode, not an image shown to an additional inner observer. Its public causal organization and qualitative character must be accounted for as aspects of that same occurrence. Physical organization constrains candidate boundaries and qualitative relations, but a scalar integration score does not supply the constitutive identity by itself.

This does not imply that all reality is experienced, that every recurrent device is conscious, or that there is one cosmic subject. A stronger panexperientialist completion is possible to propose, but needs its own defense.

The proposal avoids introducing a separate subject substance as an automatic explanatory requirement. It does not yet derive which concrete organizations are genuinely unified presentations.

## 8.2 What is rejected or withheld

- **Rejected as a sufficient derived boundary procedure:** select subjects solely by strict maximality of this prototype scalar.
- **Rejected:** infer phenomenal unity from shared input or observational correlation.
- **Rejected:** treat coordinate-local cuts as physically equivalent after an arbitrary global recoding without transporting the intervention structure.
- **Withheld:** infer qualitative character from the capacity score.
- **Withheld:** infer actual or necessary experience from a mathematical structure labelled self-presenting.
- **Withheld:** identify statistical geometry with phenomenal geometry without an independently defended bridge.

The general irreducibility/identity programme is not refuted by the failure of this one score. It is now more constrained.

## 8.3 The bridge budget

| Claim or construction | Present status |
|---|---|
| Some experience occurs | Datum |
| Minimal subject = unity of an episode, not an additional viewer | Proposed constitutive identity; not a proof of unity |
| Public organization and phenomenality are one occurrence | Working hypothesis; not established by correlation |
| Common cause can be separated from internal causal influence in the toy model | Demonstrated |
| Correctly transported physical cuts preserve the recoded result | Demonstrated |
| Strict scalar maximality uniquely determines subjects | Not established; the explicit family produces persistent overlap ties |
| A state-independent capacity score determines actual qualitative character | Not established; the score discards actual-state differences |
| Fisher geometry follows locally from response distinguishability | Derived under the stated assumptions |
| Smooth f-divergence choices give proportional local geometry | Conditional Taylor-expansion result |
| That geometry is the geometry of experienced qualities | DM hypothesis, still unverified |
| A neutral abstract theory establishes concrete instantiation | No; the empty-concrete expansion is a formal countermodel |
| Actual experience plus neutral abstract truth establishes necessary existence | No; the modal restriction is still missing |
| Full zero-residue reality | Not established |

## 8.4 Where the next derivation should aim

The highest-leverage shift is not to invent another scalar and call it consciousness. It is to investigate **intrinsic nature first**, then derive its public roles:

1. Specify a candidate intrinsic presentational nature rather than a bare unknown quiddity.
2. Derive constraints on its possible unity and differentiation.
3. Show how public interactions and observables express those constraints.
4. Recover independently constrained qualitative relations and physical predictions.
5. Justify why this constitution actually obtains, and whether it is necessary.

This reverses the direction of the hardest bridge without assuming the reversal succeeds. Starting from actual phenomenal occurrence is legitimate; inferring that every constituent of reality is phenomenal is not licensed by that datum alone.

If the intrinsic-nature proposal yields no independent constraints—if it merely copies the observed laws and experiences into a definition—it is not the unifying explanation sought.

### Research verdict

This round has not solved phenomenal constitution. It has done more specific work than restating its difficulty: it proposed an identity account, implemented a boundary criterion, exposed a general bottleneck behind its failure to select, repaired an intervention-invariance issue, and derived a possible qualitative-structure bridge with a concrete noise prediction.

The remaining core is now explicit: **a defended intrinsic nature whose organization explains presentation and its public physical roles, together with an actualization/necessity argument that does not presuppose its conclusion.**

---

# Reproducibility and source boundaries

**Script:** `zero_residue_research/round3_checks.py`  
**Saved output:** `zero_residue_research/round3_results.json`  
**Run:** `python zero_residue_research/round3_checks.py`  
**Dependencies:** Python 3 and SymPy.

The script actually ran. It calculates the causal controls; all relevant cuts for the coupled four-bit family; score frontiers; the recoding and transported interventions; the forward/reverse KL curvature; the Bernoulli coordinate change; the noise-contraction identity; and the numerical distances. Component labels in the script are zero-based; the prose uses labels 1–4.

The bottleneck bound, f-divergence expansion, and neutral-extension result have the arguments in the text. Finite code is not being used to prove that actual systems experience or that formal countermodels are metaphysically possible.

**Specific literature used:**

- Bayne and Chalmers, *What is the Unity of Consciousness?* (2003): distinctions among unity claims, including phenomenal versus access unity. The opening discussion was directly consulted; the whole paper was not reviewed here. [2](https://consc.net/papers/unity.html)
- Chalmers, *The Combination Problem for Panpsychism*: distinguishes problems of subjects, qualities, and structure. Opening sections were directly consulted; the panqualityism-specific limitation was checked against the paper's indexed excerpt. [8](https://consc.net/papers/combination.pdf)
- SEP, *Russellian Monism*: intrinsic-nature motivation and the remaining combination burden. [1](https://plato.stanford.edu/entries/russellian-monism/)
- Mediano, Seth, and Barrett, *Measuring Integrated Information: Comparison of Candidate Measures in Theory and Simulation*, Entropy 21(1):17 (2019): different measures need not behave alike. The indexed abstract and comparison discussion were checked, not the full derivations. Our prototype is not one of their measures or IIT 4.0. [1](https://doi.org/10.3390/e21010017)

The mathematical methods are standard. The contribution here is the focused construction, attempted operational completion, tests, repairs, and revised explanatory commitments—not a claim to have discovered information geometry or solved consciousness.
