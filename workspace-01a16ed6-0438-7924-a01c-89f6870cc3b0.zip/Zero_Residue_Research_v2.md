# Toward zero residue — constructive round 2
## Existential support, intrinsic parts, and derived macroscopic organization

**24 October 2026**  
**Continues:** [Constructive research, version 1](./Zero_Residue_Constructive_Research_v1.md).  
**Status:** new conditional arguments and explicit constructions; absolute closure remains unestablished.

## What this round actually improves

Version 1 left three arrows largely unspecified: how an account gets to necessary existence, how a whole acquires physically distinguished parts, and how those parts support relatively autonomous higher-level organization. This round works on those arrows rather than adding another general description of the desired theory.

| Gap | Work performed | Result |
|---|---|---|
| Existence argument relied on a near-equivalent modal premise | Replace it with an existential-support argument; separate backing from rooting | A conditional nonemptiness theorem, a derived backing lemma under full sufficiency, and a sharper contingency–closure–foundation choice |
| Self-consistency was too vague | Compare underdetermined, inconsistent, and uniquely determining networks | A rootless network can determine its values; determination still does not establish concrete instantiation |
| Quantum subsystems were implicitly given | Construct two different subsystem algebras for the same abstract state; develop the algebra-to-factorization bridge | State alone does not fix parts; suitable distinguished algebras do induce a tensor-product structure |
| Stable local systems were asserted rather than constructed | Solve a four-component interacting model | Two dynamically distinguished modules and a calculable timescale window |
| Micro-to-macro correspondence was just an arrow | Derive an exact coarse-graining identity and a perturbation bound | Autonomous aggregate dynamics, with a quantified approximation outside the ideal case |
| Physical individuation risked being called subjecthood | Identify exactly what the constructions supply and what a phenomenal identity would additionally require | A more constrained consciousness problem, not a declaration that modules are minds |

**Important:** the proofs below close inferential and structural subproblems *under explicit premises*. They do not justify every premise, derive our universe, or establish phenomenal identities. No percentage of metaphysical completion is inferred from the number of calculations.

---

# Step 1 — Improve the existence argument

## 1.1 Why the earlier GP route is not enough

Version 1 considered a concrete-grounding principle for possibility, GP. Given actual concrete existence and S5, its relevant existential instance was equivalent to necessary concrete existence. That made it a useful statement of a possible commitment, but not independent evidence for the conclusion.

The improvement is to investigate two different explanatory commitments separately:

- **Backing:** does contingent concrete actuality require existentially committing explanatory support?
- **Rooting:** does at least one line of such support have an existential root?

Neither asks us directly to assume that possibility entails actuality. They are still substantive, contestable commitments. Their conjunction must not be advertised as free metaphysical knowledge.

## 1.2 Definitions

Let **A** mean that some concrete occurrence or instantiation obtains. This is not restricted to material objects. Modal claims are evaluated world by world; “actual” is not a rigid actuality operator that makes statements about our world trivially invariant.

Let **F** be a nonempty domain of actually true, **existence-entailing facts**. For every f in F:

\[
\Box(f\rightarrow A).
\]

Examples might include the occurrence of an experiential episode, an actual field configuration, or an existential fact about the whole. The domain need not consist of individual objects, atoms, or spatial parts.

Write:

\[
g\prec f
\]

when g provides a relevant existentially committing contribution to explaining f. This is not defined as mere logical implication, temporal precedence, correlation, or an arbitrarily drawn arrow.

For a concrete application, F must include the relevant existential antecedents. We cannot manufacture a root by deleting actual support facts or trimming the domain to the desired conclusion. Collective grounds must also be represented adequately—for example by their conjunctive ground-fact where appropriate—not silently replaced by a single individually sufficient item.

## 1.3 Two explicit premises

**EB — Existential backing:** if an actual f in F is contingent, it has some relevant existential support g in F:

\[
f\wedge\Diamond\neg f\quad\Longrightarrow\quad
\exists g\in F\;(g\prec f).
\]

EB is stronger than a generic demand for explanation. It disallows a contingent existential fact whose adequate explanation is wholly existentially neutral. Someone who permits an abstract-only, nonnecessitating explanation can reject EB without thereby accepting that *all* facts are brute.

**R — An existential root exists:** some r in F has no antecedent in the relevant existential-support domain:

\[
\exists r\in F\;\neg\exists g\in F\;(g\prec r).
\]

R says less than universal well-foundedness. It does not require every support chain to terminate, every fact to share one ground, or every explanatory relation to be acyclic.

An existential root is also not automatically absolutely ungrounded. It might have abstract grounds or another kind of explanation. What it lacks is an antecedent of the specified existential-support kind.

## 1.4 Conditional existential foundation theorem

**Claim:** with the definitions above, EB and R entail necessary concrete nonemptiness:

\[
\boxed{\mathrm{EB}+\mathrm R\quad\Longrightarrow\quad\Box A.}
\]

**Proof:**

1. By R, choose an actual existential root r.
2. If r were contingent, EB would supply an existential antecedent g, contradicting its being a root.
3. Since r is actual and not contingent, r is necessary: □r.
4. By the definition of F, □(r → A).
5. Therefore □A. ∎

No S5 step is needed. The modal part requires only ordinary duality and the normal inference from a necessary premise and necessary implication to a necessary consequence.

**What has improved:** a single near-equivalent modal commitment has been replaced by a transparent explanatory architecture. We can now investigate backing and rooting separately and exhibit exactly what happens if either fails.

**What has not been established:** that EB and R are true of total reality. A proof from disputed explanatory premises is not yet a proof that those premises are unavoidable.

## 1.5 Countermodels and the cost of rejecting a premise

### Drop EB

Take one actual contingent existential fact, with no existential support. It is a root, but no necessary existential fact follows. The account might treat it as brute or offer another explanatory kind not covered by EB.

### Drop R

Consider an infinite sequence of contingent existential facts:

\[
\cdots\prec f_2\prec f_1\prec f_0.
\]

Every fact has a preceding existential support, so EB can hold. None is a root. Formally, one can assign every fₙ truth at one world and falsity at another. This is a countermodel to the inference from backing alone to necessity—not proof that such a network is metaphysically possible or explanatorily adequate.

A finite mutual-support loop gives a second formal countermodel when loops are allowed. If grounding must be asymmetric, the infinite acyclic example remains the relevant alternative.

### Universal well-foundedness is stronger than needed

If every nonempty subset of F has a minimal element, R follows. But R can hold even when another branch descends indefinitely. One necessary root could coexist with an infinite chain of derivative facts.

This distinction matters: we should not defend a stronger premise than the argument needs. The grounding literature explicitly distinguishes strict order-theoretic well-foundedness from weaker foundational conditions. [2](https://plato.stanford.edu/entries/infinite-regress/supplement.html)

### A useful conditional diagnosis

Within this architecture:

\[
A\wedge\neg\Box A
\quad\Longrightarrow\quad
\neg\mathrm{EB}\;\vee\;\neg\mathrm R.
\]

If concrete reality is contingent, either existential backing fails somewhere, or there is no existential root. This is not an exhaustive classification of every conceivable metaphysics independent of the architecture; it is an exact consequence of the stated commitments.

## 1.6 What the theorem deliberately does not infer

It does not establish:

- a unique necessary individual;
- a creator, person, cosmic subject, or maximal intelligence;
- the necessity of every detailed fact;
- the number or nature of the roots;
- a complete explanation of why the necessary fact is necessary;
- a necessary particular physical law or qualitative palette.

In particular:

\[
\Box\exists x\,C(x)\not\Rightarrow\exists x\,\Box C(x)
\]

without further premises. Necessary nonemptiness can be represented by worlds with different concrete occupants.

Nor is the support relation assumed to necessitate everything it helps explain. Adding complete necessitating grounds would substantially strengthen the account and revive the modal-collapse question. Grounding, full versus partial explanation, and necessity must not be conflated. [1](https://plato.stanford.edu/entries/grounding/)

## 1.7 Tests actually run

The companion script exhaustively checks abstract support graphs on one to four nodes, allowing loops, together with two-world necessity assignments. It examines **1,052,740 graph/assignment combinations** and finds no counterexample to the stated conditional.

That is a check on finite illustrations, not evidence that real metaphysical support is a graph with these properties. The general proof is the short argument above, not the large enumeration.

The most important remaining work is therefore philosophical and constructive: justify EB, justify or replace R, and identify a real explanatory endpoint rather than an unnamed necessary fact.

## 1.8 Go one step further: derive existential commitment from full sufficiency

There is a way to reduce the independent burden on EB without banning abstract grounds.

Suppose an actual existential fact f has an actual full ground whose joint obtainment is represented by g, and suppose the full explanatory connection necessitates f:

\[
\Box(g\rightarrow f).
\]

Since f entails A, logical composition gives:

\[
\Box(g\rightarrow A).
\]

Thus **a fully sufficient ground of an existential fact is itself existentially committing**, regardless of whether we initially call its description mathematical, essential, abstract, or concrete.

If g is admitted into the support-closed domain, it supplies the backing required by EB. The key issue is its explanatory sufficiency, not a categorical prohibition on abstract-to-concrete explanation.

For finite full grounds, g can be the conjunction of their obtainment. For infinite plural grounds, we must justify the corresponding representation or formulate the argument plurally; an unrestricted conjunction of all truths is not being assumed.

This is a real reduction of one gap: **under a full necessitating-explanation standard, the semantic existential commitment of the grounds follows, rather than being separately stipulated.** We still need to justify that standard's application and identify genuine grounds. Mere implication is not sufficient to be an explanation.

## 1.9 A sharper result: the contingency–closure–foundation triangle

The same reasoning yields more.

Suppose f is actual but contingent, g actually obtains, and □(g → f). Because f can fail, g must be able to fail too; otherwise necessary g and necessary implication would make f necessary. Hence g is also contingent.

Therefore, if every actual contingent existential fact has such a full ground in the domain, every contingent existential fact has a **contingent existential antecedent**.

Now assume strict well-foundedness of that full-ground relation. If any contingent existential facts exist, their nonempty domain must have a minimal member. But that member, being contingent, must have a preceding contingent full ground in the same domain—a contradiction.

Consequently these three commitments cannot all hold:

1. There are actual contingent existential facts.
2. Every such fact has a full necessitating ground, with the domain properly closed under those grounds.
3. The full-ground relation is strictly well-founded.

Equivalently:

\[
\boxed{\text{full necessitating closure + strict well-foundedness}
\ \Longrightarrow\ \text{no actual existential contingency}.}
\]

The finite checks verify the corresponding strengthened result when each complete joint ground is encoded as a node.

**Why this matters:** the project cannot leave all three commitments tacitly in place. It must justify necessary constitution, investigate a non-well-founded complete constitution, or defend a genuinely adequate nonnecessitating explanation/dissolution of the residual contrast.

This is not a proof that every legitimate explanatory standard is necessitating. Nor does necessity by itself make a fact intelligible: a necessary fact can still lack an adequate account of its nature. The result identifies a dependency and a choice point, not ultimate closure.

---

# Step 2 — Investigate the rootless alternative fairly

We should not dismiss rootless constitution merely by saying that an infinite chain “borrows reality forever.” The metaphor is not a proof. We need to distinguish two questions:

1. Can a network determine its values without a first value-setting member?
2. Does that determination account for concrete instantiation?

## 2.1 Self-consistency can fail, underdetermine, or determine

For Boolean x and y:

| Constraints | Solutions |
|---|---|
| x = y; y = x | (0,0) and (1,1) |
| x = 1 − y; y = x | None |

For real x and y in [0,1]:

\[
x=\frac{1+y}{2},\qquad y=\frac{1+x}{2}
\]

has the unique solution x = y = 1. The associated map is a contraction with factor 1/2.

The equations are mutually constraining without a first equation. This is a legitimate form of mathematical determination. Whether it is metaphysical grounding is a further issue.

## 2.2 Even an infinite descending network can determine its values

Consider, for every n ≥ 0:

\[
x_n=\frac{1+x_{n+1}}{2},\qquad 0\le x_n\le1.
\]

Iterating k steps gives:

\[
x_n=1-2^{-k}(1-x_{n+k}).
\]

Hence:

\[
0\le1-x_n\le2^{-k}
\]

for every k. Therefore xₙ = 1 for every n.

There is no final index, yet the bounded solution is unique. Thus the blanket claim “an infinite regress can never determine anything” is false for mathematical constraint determination.

The boundedness condition and the particular affine rule do important work. Their presence must not be hidden. Remove the bound, and xₙ = 1 + c·2ⁿ satisfies the recurrence for every real c. The bound is therefore doing demonstrable selection work.

## 2.3 The remaining instantiation question

Nothing above shows that actual concrete processes instantiate these equations. It also does not explain why this rule, coefficient, domain, or bound is the nature of reality.

The correct refinement of the earlier programme is therefore:

> Global constraint determination is a live explanatory tool. It is neither automatically meaningless nor automatically self-instantiating.

Two branches remain open:

- **Rooted constitution:** justify a real existential root and its nature.
- **Globally determining constitution:** justify a complete constraint structure, its modal authority, and its concrete realization without an arbitrary extra selection.

A rootless account should be tested for global determination, not rejected by slogan. A uniquely determined structure should be tested for actual realization, not proclaimed real by slogan.

---

# Step 3 — Recover parts from more than a bare state

Version 1's local-marginal example assumed a choice of subsystems. This round makes that assumption explicit and supplies a conditional route to recovering subsystems.

## 3.1 The same abstract quantum state supports different factorizations

Let:

\[
|\Phi^+\rangle=(|00\rangle+|11\rangle)/\sqrt2.
\]

Relative to the usual two-qubit observable algebras, its individual marginals are I₂/2.

Define:

\[
U=\operatorname{CNOT}(H\otimes I),
\]

where H is the Hadamard matrix. Then:

\[
U|00\rangle=|\Phi^+\rangle.
\]

Choose new subsystem algebras by conjugating the old ones with U, while keeping the abstract state fixed. In coordinates adapted to those new algebras:

\[
U^\dagger|\Phi^+\rangle\langle\Phi^+|U
=|00\rangle\langle00|.
\]

The state is product relative to the new factors. Each new individual marginal is pure.

This is **not** the claim that a passive coordinate change removes entanglement from a fixed physical bipartition. A passive change transforms both the state and the already specified subsystem observables together, preserving the physical entanglement. Here the subsystem algebras themselves are changed relative to the fixed state.

Using the usual Pauli matrices X and Z, the new algebras can be generated by:

\[
\mathcal A_{\rm new}:\quad Z\otimes I,\;X\otimes X,
\]

\[
\mathcal B_{\rm new}:\quad I\otimes X,\;Z\otimes Z.
\]

The script verifies their cross-commutation and that their products span the full 16-dimensional operator algebra.

**Consequence:** neither purity nor entanglement of a state alone specifies a uniquely preferred division into physical systems. We need physically distinguished observables, interactions, or other constitutive structure.

This is a developed issue in the observable-induced tensor-product literature, not an original discovery of this notebook. [5](https://arxiv.org/html/quant-ph/0308043)

## 3.2 A positive algebra-to-subsystems bridge

In a finite-dimensional Hilbert space, suppose two distinguished unital *-algebras A and B:

1. are full matrix factors;
2. commute with one another;
3. together generate the whole operator algebra.

Then there is a tensor-product representation:

\[
\mathcal H\cong\mathcal H_A\otimes\mathcal H_B,
\]

with:

\[
\mathcal A\cong\operatorname{End}(\mathcal H_A)\otimes I,
\qquad
\mathcal B\cong I\otimes\operatorname{End}(\mathcal H_B).
\]

**Proof sketch:** a representation of a full matrix algebra M_d on a finite-dimensional space is a direct sum of equivalent d-dimensional irreducible representations. Thus the space is Cᵈ ⊗ Cᵐ, and A acts as M_d ⊗ I. Operators commuting with A act on the multiplicity factor. Because A and B jointly generate the full operator algebra, B must fill that commutant, I ⊗ M_m. This gives the factorization. ∎

The factorization is fixed by the given algebras up to the corresponding unitary identifications and factor-coordinate freedoms. It is not selected by the bare state space. This is the finite-factor form of the observable-induced subsystem result. [5](https://arxiv.org/html/quant-ph/0308043)

## 3.3 How to avoid making an external observer the selector

For whole-reality ontology, “experimentally accessible” cannot mean “brought into being by an observer outside reality.” The relevant distinction would have to be grounded in internally realized interaction channels, locality, control structures, stable records, or other concrete organization.

That is a construction requirement, not a proof that any Hamiltonian uniquely supplies the relevant algebras. No universal uniqueness claim from state plus Hamiltonian is being made.

The dependency is now explicit:

\[
\boxed{\text{justified distinguished algebras}
\Longrightarrow\text{quantum subsystems}.}
\]

The unpaid question is why those algebras are physically distinguished. In quantum field theory, superselection and gauge-constrained settings, simple finite tensor factorizations can also require modification. This notebook does not assume that its finite theorem automatically covers all reality.

---

# Step 4 — Construct stable local organization without disconnection

Even with basic parts given, why should larger systems have boundaries? Complete causal isolation would be too strong: interacting systems would cease to count as distinct whenever they exchanged anything.

A more promising structural resource is **timescale separation**: strong internal organization and slower cross-boundary exchange. Near-decomposability is an established systems idea; the following is an explicit calculation rather than an appeal to that label. [3](https://www.cs.brandeis.edu/~cs146a/handouts/papers/simon-complexity.pdf)

## 4.1 The model

Consider four physically distinguished components in an effective description. Components 1 and 2 interact at rate 1; components 3 and 4 interact at rate 1. Each cross-pair interaction has rate ε > 0.

Let x contain their scalar populations, concentrations, or another diffusing quantity:

\[
\dot x=-Lx,
\]

where:

\[
L=\begin{pmatrix}
1+2\varepsilon&-1&-\varepsilon&-\varepsilon\\
-1&1+2\varepsilon&-\varepsilon&-\varepsilon\\
-\varepsilon&-\varepsilon&1+2\varepsilon&-1\\
-\varepsilon&-\varepsilon&-1&1+2\varepsilon
\end{pmatrix}.
\]

This is a connected system when ε > 0. No pair is absolutely isolated.

**Scope:** these are effective classical dynamics with a time parameter. They do not derive fundamental time, the basic components, diffusion, or the actual laws of our universe.

## 4.2 Derive its natural modes

The four independent modes and decay rates are:

| Mode | Vector | Decay rate |
|---|---|---:|
| Overall conserved quantity | (1,1,1,1) | 0 |
| Contrast between the pairs | (1,1,−1,−1) | 4ε |
| Contrast inside pair 1 | (1,−1,0,0) | 2 + 2ε |
| Contrast inside pair 2 | (0,0,1,−1) | 2 + 2ε |

These follow by multiplying L by each vector; the symbolic script verifies all four identities.

For 0 < ε ≪ 1:

\[
\tau_{\rm within}=\frac1{2+2\varepsilon},
\qquad
\tau_{\rm between}=\frac1{4\varepsilon}.
\]

There is an intermediate window:

\[
\tau_{\rm within}\ll t\ll\tau_{\rm between}
\]

in which internal contrasts have mostly relaxed while the distinction between the two modules persists.

## 4.3 What makes this partition nonarbitrary?

For 0 < ε < 1, the slowest nonconstant mode is one-dimensional. Its sign pattern singles out {1,2} and {3,4}, up to exchanging the module names. The separation becomes dynamically strong when ε is small.

This is not a theorem that every network has a unique natural partition. It is a demonstration that **a physically supplied interaction structure can distinguish a macroscopic partition without an external act of grouping**.

All 24 relabellings of the four given components were checked. The extracted partition relabels accordingly. The sign of the eigenvector only exchanges names; it is not an additional physical choice.

At ε = 1, all edges have equal weight and all three nonconstant modes have the same rate. The pair partition loses its spectral privilege. Thus the model itself says when the proposed individuation ceases to be supported.

Crucially, the basic mechanistic variables were given. Arbitrary transformations mixing those variables can turn component coordinates into global modes. Justifying the physically relevant basic decomposition remains the earlier algebra/interaction problem; this calculation does not erase it.

## 4.4 A worked example

Set ε = 0.01 and use the interaction-rate unit in which the internal rate is 1. Then:

| Quantity | Value |
|---|---:|
| Internal relaxation time | 0.49505 |
| Cross-module relaxation time | 25 |
| Timescale ratio | 50.5 |

Starting with one unit entirely in component 1, at t = 2 the state is approximately:

\[
x(2)=(0.489578,\;0.471980,\;0.019221,\;0.019221).
\]

The initial module still contains about **96.16%** of the quantity. Its internal contrast retains only **1.76%** of its initial value, while the contrast between modules retains **92.31%**.

Thus local mixing and inter-module persistence coexist in a completely connected system. These figures are properties of the illustrative model, not measured brain data.

---

# Step 5 — Derive the macro level, rather than attach a description to it

The model yields more than a visually plausible grouping.

Define the aggregate quantities:

\[
S_A=x_1+x_2,\qquad S_B=x_3+x_4.
\]

Equivalently, S = Px, with:

\[
P=\begin{pmatrix}1&1&0&0\\0&0&1&1\end{pmatrix}.
\]

Adding the microscopic equations gives:

\[
\dot S_A=2\varepsilon(S_B-S_A),
\qquad
\dot S_B=2\varepsilon(S_A-S_B).
\]

Hence:

\[
\dot S=-L_MS,
\qquad
L_M=\begin{pmatrix}2\varepsilon&-2\varepsilon\\-2\varepsilon&2\varepsilon\end{pmatrix}.
\]

## 5.1 Exact autonomous coarse-graining

Direct calculation gives:

\[
\boxed{PL=L_MP.}
\]

It follows that:

\[
\boxed{P e^{-Lt}=e^{-L_Mt}P.}
\]

The result holds for **every microscopic initial state**, not just the trajectory used in the worked example.

Consequently, any two microscopic states with the same pair totals have the same future pair totals. The aggregate state has well-defined dynamics without specifying every internal microscopic difference.

This is an actual reduction of degrees of freedom and an exact micro-to-macro correspondence. It supplies the structural commutation condition requested by the version-1 implementation discussion, rather than retrospectively mapping one convenient history to a desired pattern.

It is not by itself a complete theory of computation, semantics, or representation. P need not be a symbol literally stored in the system; it is the mathematically justified relation between descriptions of its dynamics.

### An important distinction

The **joint aggregate description** is exactly autonomous. Each module separately is only approximately independent on the intermediate timescale because its total still exchanges with the other module.

At ε = 1, some aggregate maps still close exactly, but none of these pairings has the same slow-mode privilege. Exact closure alone is therefore not sufficient for preferred individuation. Here both dynamical closure and timescale structure do work.

## 5.2 Robustness beyond the perfectly symmetric model

An exact construction is less useful if any small imperfection destroys it. Increase a single cross-pair edge by δ > 0, giving L′.

Keep the original aggregate dynamics as an approximation and define its residual:

\[
D=PL'-L_MP.
\]

For this perturbation:

\[
\|D\|_2=2\delta.
\]

A direct semigroup identity gives:

\[
P e^{-L't}-e^{-L_Mt}P
=-\int_0^t e^{-L_M(t-s)}D e^{-L's}\,ds.
\]

Because L′ and L_M are symmetric positive semidefinite, their exponential propagators have Euclidean operator norm at most 1. Therefore, for t ≥ 0:

\[
\boxed{\|P e^{-L't}-e^{-L_Mt}P\|_2\le t\|D\|_2=2\delta t.}
\]

For ε = 0.01, δ = 0.001, t = 2:

- rigorous aggregate-operator error bound: **0.004**;
- computed aggregate-operator error: **0.00268608**.

For an initial microscopic vector of norm at most 1, the same 0.004 bounds the aggregate-state error in Euclidean norm. This is not a bound for arbitrary nonlinear or nonsymmetric dynamics; the stated assumptions matter.

**Gap narrowed:** stable, approximately autonomous higher-level organization need not be an arbitrary observer-imposed partition or a perfectly isolated subsystem. In this class of models, it follows from the interactions with explicit approximation control.

---

# Step 6 — State precisely what remains before modules become subjects

The preceding construction establishes:

- a dynamically distinguished partition at a given mechanistic grain;
- different rates of internal and external change;
- retention of an inter-module contrast;
- exact aggregate dynamics in the ideal case;
- a quantitative approximation under a specified perturbation.

It does **not** establish:

- that either module experiences;
- that there is one subject per module;
- that qualitative character is a population, eigenmode, or decay rate;
- that a spectral gap supplies phenomenal unity;
- that the basic components are experiential atoms;
- that the whole is a cosmic subject.

## 6.1 Why this is nevertheless progress on the consciousness project

Version 1 had an unspecified subject-selection map. We now have a specific structural candidate generator whose strengths and limitations can be investigated. That reduces arbitrariness in the physical side of a future bridge.

It also gives a meaningful stress test:

> If a proposed theory equates subject boundaries with dynamical modules, what does it predict as ε increases, the timescale gap closes, and the preferred partition disappears?

A defensible answer might involve graded integration, discrete transitions, additional physical structure, or the conclusion that this module measure is not a subject criterion. What it cannot do is silently switch criteria when the model becomes inconvenient.

## 6.2 The required bridge is constitutive, not merely a label

An adequate completion must specify and defend at least:

1. **Existence of experience:** why the relevant organization is experiential rather than merely described as a candidate.
2. **Qualitative specificity:** why this concrete organization has this character.
3. **Unity:** why its contents belong to a single episode.
4. **Boundary and grain:** which organization and interval constitute that episode.
5. **Empirical dependence:** why relevant interventions change or abolish experience.

Within a formal model that contains only the diffusion variables and equations, several added phenomenal assignments are syntactically compatible: none, one subject, two subjects, or other assignments. That is a fact about what this stipulated model says. It is **not** proof that all such expansions are metaphysically possible or a refutation of physicalism.

A defended identity theory could exclude the alternative assignments. An experience-inclusive ontology could supply a constitutive relation not contained in this public toy model. Either route needs an argument; formal silence is not itself a theory of consciousness.

## 6.3 A more precise public architecture

For an effective physical description, the public side of C can now be represented more informatively as:

\[
C_{\rm public}=(\mathcal A,\omega,\text{dynamics},\mathcal I),
\]

where:

- **A** is an observable algebra;
- **ω** is the state;
- **dynamics** specifies evolution or admissible transformations;
- **I** specifies the physically distinguished interaction/locality organization.

Under the relevant conditions, distinguished algebras yield subsystems; interactions and dynamics then yield particular robust coarse-grainings. The phenomenal constitution remains an additional required derivation or defended identity, not a freely assignable decoration.

This is an effective architecture, not the final foundation: fundamental time, the choice of observables and interactions, and their actual realization still need accounting for. No claim is made that a bare state, an arbitrary Hamiltonian, or an information measure alone universally determines all of them.

---

# Step 7 — Consolidate the construction without hiding the remaining foundations

## 7.1 The revised dependency structure

```text
Actual experience / other existential datum
    |
    +--> existential-support architecture
    |       |
    |       +--> backing + rooting --> necessary concrete nonemptiness
    |       |                         [premises still need justification]
    |       |
    |       +--> rootless global determination
    |                                 [uniqueness and realization separated]
    |
Justified concrete constitution
    |
    +--> distinguished observable / interaction structure
    |       |
    |       +--> suitable commuting algebras --> quantum subsystems
    |       |
    |       +--> dynamics + scale separation --> privileged macro organization
    |                                           |
    |                                           +--> exact or bounded-error macro laws
    |
    +--> phenomenal constitution / identity
            |
            +--> experience, quality, unity, subjecthood
                 [not supplied by the structural results alone]
```

## 7.2 What the examples cannot choose for us

Nothing in the existential-support theorem selects the four-node model or ε = 0.01. Nothing in the algebraic factorization theorem proves that the universe's actual interactions are those of any particular theory. Nothing in the macro derivation determines a qualitative palette.

Those are not harmless details when the goal is zero residue. A final theory must derive or adequately account for them, not import the observed world as a giant “essential nature” axiom.

Likewise, explaining support nodes does not automatically explain the facts about which support relations obtain. Meta-grounding and actual link selection remain part of whole-reality scope. A necessary foundation can coexist with unexplained contingent link facts unless the account explicitly handles them.

## 7.3 Closure ledger after round 2

| Obligation | Current status |
|---|---|
| Does backing plus an existential root imply necessary nonemptiness? | **Yes, conditionally proved.** No S5 needed. |
| Are backing and rooting unavoidable truths? | **Open.** Backing follows under the explicit full-sufficiency and domain-closure conditions in §1.8; their applicability and rooting still need defense. |
| Can actual contingency, full necessitating closure, and strict well-foundedness coexist? | **No, under the specified ground-domain assumptions.** The incompatibility is proved in §1.9. |
| Must rootlessness mean mathematical underdetermination? | **No.** A bounded infinite recurrence provides a counterexample. |
| Does unique mathematical determination establish concrete instantiation? | **Not established.** The needed bridge is still missing. |
| Does a bare quantum state fix its physical subsystems? | **No, not in general.** Explicit alternative algebras were constructed. |
| Can suitable distinguished algebras recover subsystems? | **Yes, conditionally.** The finite-factor bridge is supplied. |
| Can a connected system have objectively supported macro modules? | **Yes, in the specified dynamical model and grain.** |
| Can their joint aggregate dynamics be derived for all initial states? | **Yes, exactly in the ideal model.** |
| Can approximation error be bounded after a specified perturbation? | **Yes.** A general semigroup bound and worked numerical check are supplied. |
| Does this derive consciousness or subject boundaries? | **No.** It constructs a structural resource for a future constitutive bridge. |
| Why this total constitution and these laws? | **Open.** No parameter is declared explained merely because it appears in an example. |
| Fully intelligible zero-residue account of the whole? | **Not yet established.** The ambition is retained. |

---

# Step 8 — The next work with the highest leverage

The project should now work on the exposed premises and constitutive identities, not repeat the generic request for “more explanation.”

## A. Test existential backing

Develop the strongest account of an abstract or essential ground yielding concrete existence. Ask whether its existential conclusion genuinely follows, whether it assumes a concrete instance, and whether its explanatory force necessitates that conclusion.

- If it succeeds, integrate the bridge rather than dogmatically require a prior concrete supporter.
- If it fails for a principled reason, that gives independent support for an appropriately formulated backing principle.

Section 1.8 already derives semantic existential commitment from full necessitating sufficiency, where the ground representation is legitimate. The remaining task is not to outlaw abstract grounds; it is to justify the explanation and its sufficient connection to actual existence.

A finite collection of failed proposals is not a universal impossibility proof.

## B. Justify rooting, or replace it with globally adequate constitution

R is weaker than global well-foundedness, but still needs an argument. Compare a rooted essential account with globally determining constitutive accounts that do not fit a downward genealogy.

For a rootless candidate, require:

1. existence and consistency of the complete structure;
2. sufficient determination or justified plurality;
3. a defense of the actual realization claim;
4. explanation of the rule and its parameters;
5. a non-question-begging account of why its constraint relations explain.

This is where “self-grounding” must become an actual explanatory construction or be abandoned as a label.

## C. Replace the toy's given components with a physically defended interaction structure

The algebraic bridge supplies the mathematical target. A serious physical account must identify the relevant algebras and explain why their operational/locality status is intrinsic to the concrete organization rather than an arbitrary basis choice.

Test nonuniqueness explicitly; do not assume one Hamiltonian always chooses one decomposition. Extend the treatment carefully to field-theoretic and constrained settings.

## D. Develop a phenomenal constitution proposal with discriminating consequences

A bare equation “subject = module” is insufficient. Specify the additional constitutive claim and test it against gap-closing, overlapping, nested, unconscious-processing, temporal-grain, and neural-intervention cases.

The standard is not merely a useful correlational score. It is a justified identification or constitution account that explains why the relevant facts are experiential and why these are their boundaries and qualities.

## E. Return the successful bridges to the whole-reality account

Once a candidate handles existence and phenomenal constitution, connect it to the version-1 spacetime and quantum reconstruction routes. The same foundation must justify their premises and compatibility, not leave physics and experience as separately stipulated branches.

### Consolidated result

> We can now construct, rather than merely invoke, a route from specified interactions to stable macroscopic organization and exact aggregate laws. We can also state a cleaner conditional route from existential support to necessary nonemptiness, without the previous S5 shortcut, and prove the incompatibility of actual existential contingency, full necessitating closure, and strict well-foundedness. The decisive foundations remain the justification of the explanatory architecture, the actual nature of the constitution, and the constitutive bridge to experience.

This is a real improvement in the construction. It is not the same as reaching absolute closure.

---

# Reproducibility and source boundaries

**New script:** `zero_residue_research/round2_checks.py`  
**Saved results:** `zero_residue_research/round2_results.json`  
**Run:** `python zero_residue_research/round2_checks.py`  
**Dependencies:** Python 3, SymPy, NumPy.

The script actually ran successfully. It checks finite existential-support models and the strengthened well-founded/necessitating result; fixed-point solution counts; all four symbolic diffusion modes; the exact macro identity; the perturbation residual; numerical propagation and its error bound; all 24 component relabellings; and the alternative quantum subsystem algebras. In the script, EB retains the older descriptive label `ENB`; its mathematical condition is the backing condition discussed above.

The infinite recurrence and the general existence/support theorem are justified by the arguments in the text, not by finite numerical simulation. Numerical checks are not empirical measurements, demonstrations of metaphysical possibility, or consciousness tests.

**Sources used for specific context and established results:**

- Stanford Encyclopedia of Philosophy, *Metaphysical Grounding*: distinctions among full/partial grounding, necessity, and foundational assumptions. [1](https://plato.stanford.edu/entries/grounding/)
- Ross Cameron, SEP supplement on metaphysical foundationalism and well-foundedness: the difference between strict well-foundedness and weaker foundational conditions. The complete supplement was consulted. [2](https://plato.stanford.edu/entries/infinite-regress/supplement.html)
- Zanardi, Lidar, and Lloyd, *Quantum Tensor Product Structures are Observable Induced* (2004): observable-induced subsystem structure. The opening examples and framework/proposition were consulted; the whole paper has not been independently rederived. [5](https://arxiv.org/html/quant-ph/0308043)
- Herbert Simon, *The Architecture of Complexity* (1962): near-decomposability as an established systems idea. The model and numerical examples here are our explicit illustration, not new discoveries of near-decomposability. [3](https://www.cs.brandeis.edu/~cs146a/handouts/papers/simon-complexity.pdf)

The new contribution is the focused synthesis, premise separation, explicit derivations, worked model, error analysis, and revised research dependencies—not a claim to have discovered foundational graph theory, algebraic factorization, or the final ontology of reality.
